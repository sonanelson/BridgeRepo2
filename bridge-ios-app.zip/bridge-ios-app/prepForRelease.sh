#!/usr/bin/env bash

#  prepForRelease.sh
#  Bridge iOS
#
#  Created by Shoemake,Andrew on 4/11/19.
#  Copyright (c) 2019 Cerner Corporation. All rights reserved.


script_version="0.1.0"

# shellcheck disable=SC1091
source releaseInfo.sh

# Prints out the "help" info
printInfo()
{
    echo
    echo "$( basename "${BASH_SOURCE[0]}" ) - Prepares the application to be built for a release"
    printVersion
    echo
    echo " -?           Prints this info"
    echo
    echo
    echo "Example Usage:"
    echo " prepForRelease.sh"
    echo
}

# Prints out the version of the script
printVersion()
{
    echo "$( basename "${BASH_SOURCE[0]}" ) v.$script_version"
}

#
# Exits this script with an error of '1', and displays the specified value as a failed option
#
# @param 1 The option that was not understood, and caused the exit
exitWithUnknownOption()
{
    echo "unknown option: -${1}"
    exit 1
}


#
# Modifies the default build scheme to be the new scheme, instead of the old. Sets the gobal variable SchemeFile
modifyBuildScheme()
{
    SchemeFile="$XcodeProject/xcshareddata/xcschemes/${ProjectName}.xcscheme"

    modifyBuildSchemeForSetting "LaunchAction" "Debug"

    modifyBuildSchemeForSetting "ArchiveAction" "Release"
}


#
# Modifies the build scheme for the specified action {1} from the specified configuration {2}
# to {PROD_BUILD_SCHEME} on the {SchemeFile}
modifyBuildSchemeForSetting()
{
    echo "  >Changing ${1} Scheme from ${2} to $PROD_BUILD_SCHEME"

    local ActionBeginResult=""
    ActionBeginResult=$( grep -n "<${1}" "$SchemeFile" )

    IFS=":"
    read -r -a lines <<< "${ActionBeginResult}"
    local ActionBeginLine="${lines[0]}"

    local replaceString="buildConfiguration = \"${2}\""
    sed -i '' -e "${ActionBeginLine},/${replaceString}/s/${replaceString}/buildConfiguration = \"$PROD_BUILD_SCHEME\"/g" "$SchemeFile"
}


#
# Determines the name of the project and sets the global variables - XcodeProject, ProjectName & XcodeProjectPbxprojPath
determineProjectName()
{
    echo "  >Determining Project Name"

    local XcodeProjects=( "$( ls -d -- *.xcodeproj )" )

    XcodeProject=${XcodeProjects[0]}

    local XcodeProjectFilename=""
    XcodeProjectFilename=$(basename "$XcodeProject")

    ProjectName="${XcodeProjectFilename%.*}"

    XcodeProjectPbxprojPath="$XcodeProject/project.pbxproj"
}


#
# Determines the path to the Info.plist, and sets the global variable - InfoPlist
# to the proper value
determineInfoPlistPath()
{
    echo "  >Determining location of Info.plist"
    local InfoPlistsResult=""
    InfoPlistsResult=$( ls -- "$ProjectName/SupportingFiles"/*-Info.plist )
    local InfoPlists=("$InfoPlistsResult")

    InfoPlist=${InfoPlists[0]}
}

buildType="prod"

NewBuild="Production"
OldBuild="Dev"

while getopts ":p:u:a:e:v?h" opt; do
    if [ "$opt" == "v" ]; then
        printVersion
        exit 1
    elif [ "$opt" == "?" ] || [ "$opt" == "h" ]; then
        printInfo
        exit 1
    else
        exitWithUnknownOption "$opt$OPTARG"
    fi
done

echo
echo " -- iOS Application preparing for release --"

printVersion
echo

determineProjectName
determineInfoPlistPath

echo

echo "   Project:       $ProjectName"
echo "   Info.plist:    $InfoPlist"
echo "   Type:          $buildType"
echo "   Scheme:        $PROD_BUILD_SCHEME"

echo

modifyBuildScheme

echo
echo " -- iOS Application prepared for $buildType / $NewBuild release --"
echo
