### JIRA

<!--- link to the JIRA --->
https://jira2.cerner.com/browse/BRDGSPC-

### Code Review

<!--- link to code review or comment "This PR" --->


### Dependencies

<!--- link to any dependent pull requests with a bulleted list or none --->

### Change type
- [ ] Defect Fix
- [ ] Enhancement
- [ ] Configuration Change
- [ ] Version Change

### Checklist

- [ ] JIRA in commit title with `[ ]`'s
- [ ] Link to JIRA in Pull Request
- [ ] Link to Code Review
- [ ] Links to dependent pull requests
- [ ] Successful build
- [ ] JIRA has link to Code Review & this Pull Request
- [ ] Fix version(s) on the JIRA
- [ ] Component(s) on the JIRA
- [ ] Design documented on JIRA
- [ ] Story JIRA has epic link

### Comments

<!--- additional notes pertinent to this change --->