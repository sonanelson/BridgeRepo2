//
//  MainMenuControllerTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 12/6/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

#import "ApplicationsController.h"
#import "NSUserDefaults+BridgeAdditions.h"

@interface ApplicationsController ()
@property (nonatomic, retain) NSMutableArray *applicationsList;
@property (nonatomic, retain) NSMutableDictionary *availableApplicationIndexes;

- (NSArray *)defaultTitleKeysArray;
- (NSDictionary *)getDefaultTitleKeysFromApplicationKeys;
- (NSDictionary *)getDefaultTitleFromTitleKeys;
- (BOOL)checkIfDefaultIsEnabledForKey:(NSString *)key;
- (NSString *)getApplicationTitleForKey:(NSString *)key;
@end

@interface ApplicationsControllerTest : XCTestCase
@property (nonatomic, strong) ApplicationsController *mainMenuVC;
@end

@implementation ApplicationsControllerTest

- (void)setUp {
    [super setUp];

    self.mainMenuVC = [ApplicationsController createMainMenuViewController];
    [self.mainMenuVC loadView];
}

- (void)tearDown {
    [super tearDown];

    self.mainMenuVC = nil;

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"lastSelectedApp"];
}

- (void)testCreateMainMenuViewController {
    UIViewController *controller = [ApplicationsController createMainMenuViewController];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller isKindOfClass:[ApplicationsController class]]);
}

- (void)testDefaultTitleKeysArray {
    NSArray *array = [self.mainMenuVC defaultTitleKeysArray];

    XCTAssertTrue(array);
    XCTAssertEqual(array.count, 6);
}

- (void)testKeyAndDefaultTitleMap {
    NSDictionary *dictionary = [self.mainMenuVC getDefaultTitleFromTitleKeys];

    XCTAssertNotNil(dictionary);
    XCTAssertEqual(dictionary.allKeys.count, 6);
    XCTAssertEqual(dictionary.allValues.count, 6);
}

- (void)testApplicationAndTitleKeysMap {
    NSDictionary *dictionary = [self.mainMenuVC getDefaultTitleKeysFromApplicationKeys];

    XCTAssertNotNil(dictionary);
    XCTAssertEqual(dictionary.allKeys.count, 6);
    XCTAssertEqual(dictionary.allValues.count, 6);
}

- (void)testViewDidLoad {
    NSArray *defaultsKeysArray = @[@"defaultKey1", @"defaultKey2"];

    OCMockObject *mockUserDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockUserDefaults expect] andReturn:defaultsKeysArray] arrayForBridgeApplicationKeys];

    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"defaultKey1"];
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"defaultKey2"];

    NSDictionary *dictionary       = @{@"defaultKey1": @"TestTitleKey"};
    NSDictionary *secondDictionary = @{@"TestTitleKey": @"TestTitle"};
    OCMockObject *mockSelf         = [OCMockObject partialMockForObject:self.mainMenuVC];
    [[[mockSelf expect] andReturn:dictionary] getDefaultTitleKeysFromApplicationKeys];
    [[[mockSelf expect] andReturn:secondDictionary] getDefaultTitleFromTitleKeys];

    XCTAssertTrue(self.mainMenuVC.applicationsList == NULL);

    [self.mainMenuVC viewDidLoad];

    XCTAssertNotNil(self.mainMenuVC.applicationsList);
    XCTAssertEqual(self.mainMenuVC.applicationsList.count, 1);
    XCTAssertEqual([self.mainMenuVC.applicationsList firstObject], @"TestTitle");

    CernerOCMockVerify(mockUserDefaults);
    CernerOCMockVerify(mockSelf);

    [mockUserDefaults stopMocking];
    [mockSelf stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"defaultKey1"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"defaultKey2"];
}

- (void)testNumberOfSectionsInTableView {
    NSInteger retVal = [self.mainMenuVC numberOfSectionsInTableView:self.mainMenuVC.tableView];

    XCTAssertEqual(retVal, 1);
}

- (void)testNumberOfRowsInSection {
    self.mainMenuVC.applicationsList = [NSMutableArray arrayWithArray:@[@"menu1", @"menu2"]];

    NSInteger retVal = [self.mainMenuVC tableView:self.mainMenuVC.tableView numberOfRowsInSection:0];

    XCTAssertEqual(retVal, 2);
}

- (void)testCellForRowAtIndexPath {
    self.mainMenuVC.applicationsList = [NSMutableArray arrayWithArray:@[@"menu1", @"menu2"]];

    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:1 inSection:0];
    UITableViewCell *cell  = [self.mainMenuVC tableView:self.mainMenuVC.tableView cellForRowAtIndexPath:indexpath];

    XCTAssertNotNil(cell);
    XCTAssertTrue([cell.textLabel.text isEqualToString:@"menu2"]);
}

- (void)testCellForRowAtIndexPath_DequeueCellNil {
    self.mainMenuVC.applicationsList = [NSMutableArray arrayWithArray:@[@"menu1", @"menu2"]];

    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:1 inSection:0];

    OCMockObject *mockTableview = [OCMockObject partialMockForObject:self.mainMenuVC.tableView];
    [[[mockTableview expect] andReturn:NULL] dequeueReusableCellWithIdentifier:OCMOCK_ANY forIndexPath:indexpath];

    UITableViewCell *cell = [self.mainMenuVC tableView:self.mainMenuVC.tableView cellForRowAtIndexPath:indexpath];

    XCTAssertNotNil(cell);
    XCTAssertTrue([cell.textLabel.text isEqualToString:@"menu2"]);
    CernerOCMockVerify(mockTableview);

    [mockTableview stopMocking];
}

- (void)testDidSelectRowAtIndexPath {
    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:0 inSection:0];
    XCTAssertTrue([[NSUserDefaults standardUserDefaults] objectForKey:@"lastSelectedApp"] == NULL);

    NSString *title                             = @"title";
    self.mainMenuVC.applicationsList            = [NSMutableArray arrayWithArray:@[title, @"menu2"]];
    self.mainMenuVC.availableApplicationIndexes = [NSMutableDictionary dictionaryWithDictionary:@{title: [NSNumber numberWithInteger:4]}];

    [self.mainMenuVC tableView:self.mainMenuVC.tableView didSelectRowAtIndexPath:indexpath];

    XCTAssertEqual([[[NSUserDefaults standardUserDefaults] objectForKey:@"lastSelectedApp"] integerValue], 4);
}

@end
