//
//  UIButton+AdditionalAttributesTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIButton+AdditionalAttributes.h"
#import "UIColor+BridgeColors.h"
#import <XCTest/XCTest.h>

@interface UIButton_AdditionalAttributesTest : XCTestCase

@end

@implementation UIButton_AdditionalAttributesTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testTitleColorForMainBottomBar {
    UIButton *button = [UIButton new];
    button.enabled   = false;

    // inactiveTextColor
    UIColor *color = NULL;
    CGFloat red, green, blue, alpha;

    color = [button titleColorForMainBottomBar];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.60f);
    XCTAssertEqual(alpha, 1.0f);

    // defaultTextColor
    button.enabled = true;

    color = [button titleColorForMainBottomBar];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.04f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.52f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.74f);
    XCTAssertEqual(alpha, 1.0f);
}

- (void)testTitleColorForSecondaryBottomBar {
    UIButton *button = [UIButton new];
    button.enabled   = false;

    // inactiveTextColor
    UIColor *color = NULL;
    CGFloat red, green, blue, alpha;
    color = [button titleColorForSecondaryBottomBar:true];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.60f);
    XCTAssertEqual(alpha, 1.0f);

    // inactiveTextColor
    button.enabled = true;

    color = [button titleColorForSecondaryBottomBar:true];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.60f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.60f);
    XCTAssertEqual(alpha, 1.0f);

    //defaultTextColor
    button.enabled = true;

    color = [button titleColorForSecondaryBottomBar:false];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.04f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.52f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.74f);
    XCTAssertEqual(alpha, 1.0f);
}

- (void)testCenterContentWithImageOnTopOfSizeTitleAndFont {
    UIButton *button       = [UIButton new];
    button.imageEdgeInsets = UIEdgeInsetsZero;
    button.titleEdgeInsets = UIEdgeInsetsZero;
    UIImage *image         = [UIImage imageNamed:@"cancelIcon"];

    [button centerContentWithImageOnTopOfSize:image.size title:@"Test" andFont:[UIFont systemFontOfSize:12.0f]];

    XCTAssertTrue(button.imageEdgeInsets.top != 0.0f);
    XCTAssertTrue(button.titleEdgeInsets.top != 0.0f);
}
@end
