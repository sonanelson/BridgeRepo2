//
//  NSMutableDictionary+AlertViewHelperTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/15/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "NSMutableDictionary+AlertViewHelper.h"
#import <XCTest/XCTest.h>

@interface NSMutableDictionary_AlertViewHelperTest : XCTestCase

@end

@implementation NSMutableDictionary_AlertViewHelperTest

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testGetAlertButtonTitlesAndMessageFromTextForConfirmAlert_OneButton {
    NSString *text = @"btn:FirstButtonTitle";

    NSString *message = @"";

    NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithCapacity:3];
    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:NO];

    XCTAssertTrue(dictionary.allKeys.count == 1);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
}

- (void)testGetAlertButtonTitlesAndMessageFromTextForConfirmAlert_TwoButtons {
    NSString *text = @"btn:FirstButtonTitle";

    NSString *message = @"";

    NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithCapacity:3];
    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:YES];

    XCTAssertTrue(dictionary.allKeys.count == 1);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
    XCTAssertNil(dictionary[kKey_Alert_ButtonCancel]);

    text = @"btn2:SecondButtonTitle";

    message = @"";
    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:YES];

    XCTAssertTrue(dictionary.allKeys.count == 2);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonCancel] isEqualToString:@"SecondButtonTitle"]);
}

- (void)testGetAlertButtonTitlesAndMessageFromTextForConfirmAlert_TwoButtonsAndMessage {
    NSString *text = @"btn:FirstButtonTitle";

    NSString *message = @"";

    NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithCapacity:3];
    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:YES];

    XCTAssertTrue(dictionary.allKeys.count == 1);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
    XCTAssertNil(dictionary[kKey_Alert_ButtonCancel]);

    text    = @"btn2:SecondButtonTitle";
    message = @"";

    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:YES];

    XCTAssertTrue(dictionary.allKeys.count == 2);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonCancel] isEqualToString:@"SecondButtonTitle"]);

    text    = @"This is a test message.";
    message = @"";

    [dictionary getAlertButtonTitlesFromText:text appendToMessage:message forConfirmAlert:YES];

    XCTAssertTrue(dictionary.allKeys.count == 3);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonOK] isEqualToString:@"FirstButtonTitle"]);
    XCTAssertTrue([dictionary[kKey_Alert_ButtonCancel] isEqualToString:@"SecondButtonTitle"]);
    NSString *finalMessage = [NSString stringWithFormat:@"\n%@", text];
    XCTAssertTrue([dictionary[kKey_Alert_Message] isEqualToString:finalMessage]);
}

- (void)testExtractAlertDetailsfromHTMLElements {
    //javascript:alert(\"Title<br>btn:buttonTitle<br>message\")

    NSString *text           = @"javascript:alert(\"Title<br>btn:buttonTitle<br>message\")";
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_backbtn", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:text];

    NSDictionary *dictionary = nil;
    dictionary               = [NSMutableDictionary extractAlertDetailsfromHTMLElements:@[element]];

    XCTAssertNotNil(dictionary);
    XCTAssertEqual(dictionary.allKeys.count, 2);
    XCTAssertNotNil(dictionary[kKey_Alert_ButtonTitle]);
    XCTAssertNotNil(dictionary[kKey_Alert_Details]);
}

- (void)testCreateForServerErrorWithCancelResponseAndOkResponse_ServerError {
    NSString *cancelResponse = @"Test cancel Response";
    NSString *okResponse     = @"Test OK Response";

    NSDictionary *dictionary = nil;
    dictionary               = [NSMutableDictionary createWithServerError:YES cancelResponse:cancelResponse andOkResponse:okResponse];

    XCTAssertNotNil(dictionary);
    XCTAssertEqual(dictionary.allKeys.count, 1);
    XCTAssertTrue(dictionary[kKey_Response_ServerError]);
    XCTAssertNil(dictionary[kKey_Alert_ButtonTitle]);
    XCTAssertNil(dictionary[kKey_Alert_Details]);
}

- (void)testCreateForServerErrorWithCancelResponseAndOkResponse_NotaServerError {
    NSString *cancelResponse = @"Test cancel Response";
    NSString *okResponse     = @"Test OK Response";

    NSDictionary *dictionary = nil;
    dictionary               = [NSMutableDictionary createWithServerError:NO cancelResponse:cancelResponse andOkResponse:okResponse];

    XCTAssertNotNil(dictionary);
    XCTAssertEqual(dictionary.allKeys.count, 3);
    XCTAssertTrue(dictionary[kKey_Response_ServerError]);
    XCTAssertTrue([dictionary[kKey_Response_Cancel] isEqualToString:cancelResponse]);
    XCTAssertTrue([dictionary[kKey_Response_OK] isEqualToString:okResponse]);
}

@end
