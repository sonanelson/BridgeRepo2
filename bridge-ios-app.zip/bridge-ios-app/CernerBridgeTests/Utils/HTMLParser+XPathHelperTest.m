//
//  HTMLParser+XPathHelperTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/8/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "HTMLParser+XPathHelper.h"

@interface HTMLParser_XPathHelperTest : XCTestCase

@end

@implementation HTMLParser_XPathHelperTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testParseTitleFromHTML {

    NSString *testHTML   = @"<title>TestTitle</title>";
    HTMLElement *element = [HTMLParser parseTitleFromHTML:testHTML];
    XCTAssertNotNil(element);
    XCTAssertTrue([element.elementType isEqualToString:@"title"]);
    XCTAssertTrue([element.text isEqualToString:@"TestTitle"]);
}

- (void)testGetBottomBarElementsFromHTML_MainBar {
    NSString *testHTML = @"<input type=\"submit\" name=\"lnkChangePatient\" value=\"Test_Patients\" id=\"test_lnkChangePatient_ID\"> "
                         @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\"> "
                         @"<input type=\"submit\" name=\"lnkhome\" value=\"Test_Menu\" id=\"test_lnkhome_ID\">";

    NSArray<HTMLElement *> *elements = [HTMLParser getBottomBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    HTMLElement *patientElement = elements[0];
    XCTAssertTrue([patientElement.elementID isEqualToString:@"test_lnkChangePatient_ID"]);

    HTMLElement *menuElement = elements[1];
    XCTAssertTrue([menuElement.elementID isEqualToString:@"test_lnkhome_ID"]);

    HTMLElement *scanElement = elements[2];
    XCTAssertTrue([scanElement.elementID isEqualToString:@"test_scan_ID"]);
}

- (void)testGetBottomBarElementsFromHTML_ExitBar {

    // Cancel / Scan / Continue
    NSString *testHTML = @"<input type=\"submit\" name=\"cancel\" value=\"Test_Cancel\" id=\"test_cancel_ID\">"
                         @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\">"
                         @"<input type=\"submit\" name=\"continue\" value=\"Test_Continue\" id=\"test_continue_ID\">";
    NSArray<HTMLElement *> *elements = [HTMLParser getBottomBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    HTMLElement *scanElement = elements[0];
    XCTAssertTrue([scanElement.elementID isEqualToString:@"test_scan_ID"]);

    HTMLElement *yesElement = elements[1];
    XCTAssertTrue([yesElement.elementID isEqualToString:@"test_continue_ID"]);

    HTMLElement *noElement = elements[2];
    XCTAssertTrue([noElement.elementID isEqualToString:@"test_cancel_ID"]);

    // No / Scan/ Yes
    elements = nil;
    testHTML = @"<input type=\"submit\" name=\"cmdno\" value=\"Test_No\" id=\"test_cmdno_ID\">"
               @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\">"
               @"<input type=\"submit\" name=\"yes\" value=\"Test_yes\" id=\"test_cmdyes_ID\">";
    elements = [HTMLParser getBottomBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    scanElement = elements[0];
    XCTAssertTrue([scanElement.elementID isEqualToString:@"test_scan_ID"]);

    yesElement = elements[1];
    XCTAssertTrue([yesElement.elementID isEqualToString:@"test_cmdyes_ID"]);

    noElement = elements[2];
    XCTAssertTrue([noElement.elementID isEqualToString:@"test_cmdno_ID"]);

    // No / Scan/ OK
    elements = nil;
    testHTML = @"<input type=\"submit\" name=\"cmdno\" value=\"Test_No\" id=\"test_cmdno_ID\">"
               @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\"> "
               @"<input type=\"submit\" name=\"ok\" value=\"Test_ok\" id=\"test_ok_ID\">";
    elements = [HTMLParser getBottomBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    scanElement = elements[0];
    XCTAssertTrue([scanElement.elementID isEqualToString:@"test_scan_ID"]);

    yesElement = elements[1];
    XCTAssertTrue([yesElement.elementID isEqualToString:@"test_ok_ID"]);

    noElement = elements[2];
    XCTAssertTrue([noElement.elementID isEqualToString:@"test_cmdno_ID"]);
}

/**
 * Verify the ok option will take precedence over a continue option
 */
- (void)testGetBottomBarElementsFromHTML_OkTakesPrecedence {
    // Cancel / Scan / Continue
    NSString *testHTML = @"<input type=\"submit\" name=\"cancel\" value=\"Test_Cancel\" id=\"test_cancel_ID\">"
                         @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\">"
                         @"<input type=\"submit\" name=\"continue\" value=\"Test_Continue\" id=\"test_continue_ID\">"
                         @"<input type=\"submit\" name=\"ok\" value=\"Print\" id=\"test_ok_ID\">";
    NSArray<HTMLElement *> *elements = [HTMLParser getBottomBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    HTMLElement *scanElement = elements[0];
    XCTAssertTrue([scanElement.elementID isEqualToString:@"test_scan_ID"]);

    HTMLElement *yesElement = elements[1];
    XCTAssertTrue([yesElement.elementID isEqualToString:@"test_ok_ID"]);

    HTMLElement *noElement = elements[2];
    XCTAssertTrue([noElement.elementID isEqualToString:@"test_cancel_ID"]);
}

- (void)testGetLeftBarButtonNavigationBarElementsFromHTML {
    NSString *testHTML = @"<input type=\"submit\" name=\"btnAddPoc\" value=\"Test_Filter\" id=\"test_btnAddPoc_ID\">"
                         @"<input=\"submit\" name=\"backbtn\" value=\"Test_Back\" id=\"test_backbtn_ID\">"
                         @"<input type=\"submit\" name=\"lnkhome\" value=\"Test_Home\" id=\"test_lnkhome_ID\">";
    NSArray<HTMLElement *> *elements = [HTMLParser getLeftBarButtonNavigationBarElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 3);

    HTMLElement *backElement = elements[0];
    XCTAssertTrue([backElement.elementID isEqualToString:@"test_backbtn_ID"]);

    HTMLElement *filterElement = elements[1];
    XCTAssertTrue([filterElement.elementID isEqualToString:@"test_btnAddPoc_ID"]);

    HTMLElement *homeElement = elements[2];
    XCTAssertTrue([homeElement.elementID isEqualToString:@"test_lnkhome_ID"]);
}

- (void)testGetDropDownMenuElementsFromHTML {
    NSString *testHTML = @"<a href=\"javascript:alert('Title<br>btn:button<br>Message');\" id=\"Test_lnkInfo_ID\" text=\"TestTextInfo\"></a>"
                         @"<input type=\"submit\" name=\"lnkLogout\" value=\"Test_Logout\" id=\"Test_lnkLogout_ID\">";
    NSArray<HTMLElement *> *elements = [HTMLParser getDropDownMenuElementsFromHTML:testHTML];
    XCTAssertTrue(elements.count == 2);

    HTMLElement *helpElement = elements[0];
    XCTAssertTrue([helpElement.elementID isEqualToString:@"Test_lnkInfo_ID"]);

    HTMLElement *logoutElement = elements[1];
    XCTAssertTrue([logoutElement.elementID isEqualToString:@"Test_lnkLogout_ID"]);
}

- (void)testgetErrorAlertInfoFromHTML {
    NSString *testHTML = @"<a class=\"errorText\" href='javascript:alert(\"Alert<br>btn:buttonTitle<br>Message.\");'></a>";

    NSArray<HTMLElement *> *elements = [HTMLParser getErrorAlertInfoFromHTML:testHTML];
    XCTAssertTrue(elements.count == 1);

    HTMLElement *element = elements[0];
    XCTAssertTrue([element.text isEqualToString:@"javascript:alert(\"Alert<br>btn:buttonTitle<br>Message.\");"]);
}

- (void)testGetAutoLogoutTimeFromHTML {
    NSString *testHTML = @" <input name=\"autoLogTime\" value=\"^30\" id=\"autoLogTime\">";

    HTMLElement *element = [HTMLParser getAutoLogoutTimeFromHTML:testHTML];
    XCTAssertNotNil(element);

    NSInteger logoutTime = [[element.text substringFromIndex:1] intValue];
    XCTAssertEqual(logoutTime, 30);
}

- (void)testGetAvailableSolutionsFromHTML {
    NSString *testHTML = @"<input name=\"availableSolutions\" value=\"Trans\" id=\"availableSolutions\">";

    HTMLElement *element = [HTMLParser getAvailableSolutionsFromHTML:testHTML];
    XCTAssertNotNil(element);

    NSString *solutionName = element.text;
    XCTAssertFalse([solutionName isEqualToString:@""]);
    XCTAssertTrue([solutionName isEqualToString:@"Trans"]);
}

@end
