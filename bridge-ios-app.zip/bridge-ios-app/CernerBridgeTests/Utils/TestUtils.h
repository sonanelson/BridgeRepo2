//
//  TestUtils.h
//  CernerBridgeTests
//
//  Created by Shoemake,Andrew on 4/19/19.
//  Copyright © 2019 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestUtils : NSObject

/**
 * Add an artificial delay to your test
 */
+ (void)wait:(NSInteger)timeout;

/**
 * Wait for the default amount of time
 */
+ (void)wait;

@end
