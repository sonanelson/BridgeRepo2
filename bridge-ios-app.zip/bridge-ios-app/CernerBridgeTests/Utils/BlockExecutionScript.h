//
//  BlockExecutionScript.h
//  CernerBridge
//
//  Created by Gore,Divya on 12/7/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#ifndef BlockExecutionScript_h
#define BlockExecutionScript_h

#define CernerOCMockSafeBlockExecute(blockReference, blockToExecute) \
    if (blockReference) {                                            \
        CernerOCMockSafeExecute(blockToExecute);                     \
    } else {                                                         \
        XCTAssertNotNil(blockReference);                             \
    }

#endif /* BlockExecutionScript_h */
