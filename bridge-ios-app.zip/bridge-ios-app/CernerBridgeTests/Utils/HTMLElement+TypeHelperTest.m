//
//  HTMLElement+TypeHelperTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement+TypeHelper.h"
#import <XCTest/XCTest.h>

@interface HTMLElement_TypeHelperTest : XCTestCase

@end

@implementation HTMLElement_TypeHelperTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testIsOfTypePatient {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_lnkchangepatient", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypePatient]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_LNKchangePATIENT", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypePatient]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_patient", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypePatient]);
}

- (void)testIsOfTypeCancel {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_cancel", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeCancel]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_CANCEL", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeCancel]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeCancel]);
}

- (void)testIsOfTypeCancel_No {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_cmdno", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeCancel]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_CMDNO", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeCancel]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeCancel]);
}

- (void)testIsOfTypeHome {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_lnkhome", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeHome]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_LNKHOME", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeHome]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeHome]);
}

- (void)testIsOfTypeContinue_Continue {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_continue", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_CONTINUE", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeContinue]);
}

- (void)testIsOfTypeContinue_OK {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_ok", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_OK", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeContinue]);
}

- (void)testIsOfTypeContinue_cmdyes {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_cmdyes", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_CMDYES", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeContinue]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeContinue]);
}

- (void)testIsOfTypeLogout {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_lnkLogout", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeLogout]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_LNKLOGOUT", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeLogout]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeLogout]);
}

- (void)testIsOfTypeBack {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_backbtn", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeBack]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_BACKBTN", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeBack]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeBack]);
}

- (void)testIsOfTypeFilter {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_btnAddPoc", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeFilter]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_BTNADDPOC", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeFilter]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeFilter]);
}

- (void)testIsOfTypeScan {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID_for_scan", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeScan]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_SCAN", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertTrue([element isOfTypeScan]);

    properties = @{@"value": @"Value", @"id": @"test_ID_for_cannotFindWord", @"name": @"name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    XCTAssertFalse([element isOfTypeScan]);
}

@end
