//
//  AlertViewUtilsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/15/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

#import "AlertViewUtils.h"
#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSString+Additions.h"

@interface AlertViewUtilsTest : XCTestCase

@end

@implementation AlertViewUtilsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testAlertWithErrorTypeAndMessage_ErrorTypeServer {
    NSString *errorMsg            = @"Error Message";
    UIAlertController *controller = [AlertViewUtils alertWithErrorType:kErrorAlertType_Server andMessage:errorMsg];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller.title isEqualToString:@"Web Error Received"]);
    XCTAssertTrue([controller.message containsString:@"Verify Web Server Name and Web Site Name in Settings->Cerner Bridge and contact system administrator."]);
    XCTAssertFalse([controller.message containsString:@"Click OK to Retry."]);
}

- (void)testAlertWithErrorTypeAndMessage_ErrorTypeGeneral {
    NSString *errorMsg            = @"Error Message";
    UIAlertController *controller = [AlertViewUtils alertWithErrorType:kErrorAlertType_General andMessage:errorMsg];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller.title isEqualToString:@"Web Error Received"]);
    XCTAssertFalse([controller.message containsString:@"Verify Web Server Name and Web Site Name in Settings->Cerner Bridge and contact system administrator."]);
    XCTAssertTrue([controller.message containsString:@"Click OK to Retry."]);
}

- (void)testAlertWithErrorTypeAndMessage_ErrorTypePageTimeout {
    NSString *errorMsg            = @"Error Message";
    UIAlertController *controller = [AlertViewUtils alertWithErrorType:kErrorAlertType_PageTimeoutError andMessage:errorMsg];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller.title isEqualToString:@"Page Load Timeout"]);
}

- (void)testAlertWithErrorTypeAndMessage_InvalidBarcode {
    UIAlertController *controller = [AlertViewUtils alertWithErrorType:kErrorAlertType_InvalidBarcode andMessage:NULL];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller.title isEqualToString:@"Invalid Barcode Scan"]);
}

- (void)testAlertWithTitleAndMessage {
    NSString *title               = @"Alert title";
    NSString *msg                 = @"Alert message";
    UIAlertController *controller = [AlertViewUtils alertWithTitle:title andMessage:msg];

    XCTAssertTrue([controller.title isEqualToString:title]);
    XCTAssertTrue([controller.message isEqualToString:msg]);
}

- (void)testAlertFromHTMLElements {
    NSDictionary *properties         = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element             = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    NSArray<HTMLElement *> *elements = @[element];

    NSArray *details             = @[@"Title", @"Message"];
    NSDictionary *detailsInfo    = @{kKey_Alert_Details: details};
    OCMockObject *mockDictionary = [OCMockObject mockForClass:[NSMutableDictionary class]];
    [[[mockDictionary expect] andReturn:detailsInfo] extractAlertDetailsfromHTMLElements:elements];

    UIAlertController *controller = [AlertViewUtils alertFromHTMLElements:elements];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller.title isEqualToString:details.firstObject]);
    XCTAssertTrue([controller.message isEqualToString:details.lastObject]);
}

- (void)testAlertButtonTitlesFromElements {
    NSDictionary *properties         = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element             = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    NSArray<HTMLElement *> *elements = @[element];

    NSArray *details             = @[@"Title", @"Message"];
    NSArray *buttons             = @[@"OK", @"Cancel"];
    NSDictionary *detailsInfo    = @{kKey_Alert_Details: details, kKey_Alert_ButtonTitle: buttons};
    OCMockObject *mockDictionary = [OCMockObject mockForClass:[NSMutableDictionary class]];
    [[[mockDictionary expect] andReturn:detailsInfo] extractAlertDetailsfromHTMLElements:elements];

    NSArray<NSString *> *alertButtons = nil;
    alertButtons                      = [AlertViewUtils alertButtonTitlesFromElements:elements];

    XCTAssertTrue(alertButtons.count == 2);
    XCTAssertTrue([alertButtons.firstObject isEqualToString:@"OK"]);
    XCTAssertTrue([alertButtons.lastObject isEqualToString:@"Cancel"]);
}

- (void)testAlertButtonTitlesWithLogout_ContainsLogout {
    NSArray *buttons = [AlertViewUtils alertButtonTitlesWithLogout:YES];

    XCTAssertEqual(buttons.count, 2);
}

- (void)testAlertButtonTitlesWithLogout_DoesNotContainLogout {
    NSArray *buttons = [AlertViewUtils alertButtonTitlesWithLogout:NO];

    XCTAssertEqual(buttons.count, 1);
}

- (void)testAlertForWebSettingAlertTypeWithErrorDescription {
    // Empty fields
    UIAlertController *alertController = [AlertViewUtils alertForWebSettingAlertType:kWebSettingAlertType_EmptyField withErrorDescription:@"Empty Fields"];

    XCTAssertNotNil(alertController);
    XCTAssertFalse([NSString isStringEmpty:alertController.title]);
    XCTAssertFalse([NSString isStringEmpty:alertController.message]);
    XCTAssertEqual(alertController.actions.count, 1);
    XCTAssertTrue([alertController.actions[0].title isEqualToString:@"OK"]);

    // Invalid URL
    alertController = nil;
    alertController = [AlertViewUtils alertForWebSettingAlertType:kWebSettingAlertType_InvalidURL withErrorDescription:@"Invalid URL"];

    XCTAssertNotNil(alertController);
    XCTAssertFalse([NSString isStringEmpty:alertController.title]);
    XCTAssertFalse([NSString isStringEmpty:alertController.message]);
    XCTAssertEqual(alertController.actions.count, 1);
    XCTAssertTrue([alertController.actions[0].title isEqualToString:@"OK"]);

    // Invalid Response
    alertController = nil;
    alertController = [AlertViewUtils alertForWebSettingAlertType:kWebSettingAlertType_InvalidResponse withErrorDescription:@"Invalid Response"];

    XCTAssertNotNil(alertController);
    XCTAssertFalse([NSString isStringEmpty:alertController.title]);
    XCTAssertFalse([NSString isStringEmpty:alertController.message]);
    XCTAssertEqual(alertController.actions.count, 1);
    XCTAssertTrue([alertController.actions[0].title isEqualToString:@"OK"]);

    // Error
    alertController = nil;
    alertController = [AlertViewUtils alertForWebSettingAlertType:kWebSettingAlertType_Error withErrorDescription:@"Error"];

    XCTAssertNotNil(alertController);
    XCTAssertFalse([NSString isStringEmpty:alertController.title]);
    XCTAssertFalse([NSString isStringEmpty:alertController.message]);
    XCTAssertEqual(alertController.actions.count, 1);
    XCTAssertTrue([alertController.actions[0].title isEqualToString:@"OK"]);
}

- (void)testDefaultAlertButtonTitlesWithCancel_NoCancel {
    NSArray *defaultButtons = [AlertViewUtils defaultAlertButtonTitlesWithCancel:NO];
    XCTAssertEqual(defaultButtons.count, 1);
}

- (void)testDefaultAlertButtonTitlesWithCancel_YesCancel {
    NSArray *defaultButtons = [AlertViewUtils defaultAlertButtonTitlesWithCancel:YES];
    XCTAssertEqual(defaultButtons.count, 2);
}

/**
 * Verify correct verbiage
 */
- (void)testAlertForBarcodeScannerConnectionError_LicenseInvalid {
    UIAlertController *controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseInvalid];

    XCTAssertEqualObjects(controller.title, @"Failure to Initialize Barcode Scanner");
    XCTAssertEqualObjects(controller.message, @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (100)");
}

/**
 * Verify correct verbiage
 */
- (void)testAlertForBarcodeScannerConnectionError_NetworkUnavailable {
    UIAlertController *controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_NetworkUnavailable];

    XCTAssertEqualObjects(controller.title, @"Network Unavailable");
    XCTAssertEqualObjects(controller.message, @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (101)");
}

/**
 * Verify correct verbiage
 */
- (void)testAlertForBarcodeScannerConnectionError_LicenseServerUnavailable {
    UIAlertController *controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseServerUnavailable];

    XCTAssertEqualObjects(controller.title, @"License Server Unavailable");
    XCTAssertEqualObjects(controller.message, @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (102)");
}

/**
 * Verify correct verbiage
 */
- (void)testAlertForBarcodeScannerConnectionError_LicenseExpired {
    UIAlertController *controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseExpired];

    XCTAssertEqualObjects(controller.title, @"Scanner License Expired");
    XCTAssertEqualObjects(controller.message, @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (103)");
}

/**
 * Verify correct verbiage
 */
- (void)testAlertForBarcodeScannerConnectionError_GeneralError {
    UIAlertController *controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_GeneralError];

    XCTAssertEqualObjects(controller.title, @"General Error");
    XCTAssertEqualObjects(controller.message, @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (104)");
}

@end
