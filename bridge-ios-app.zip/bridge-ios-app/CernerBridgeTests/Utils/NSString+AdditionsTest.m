//
//  NSString+AdditionsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 10/12/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "NSString+Additions.h"
#import <XCTest/XCTest.h>

@interface NSString_AdditionsTest : XCTestCase

@end

@implementation NSString_AdditionsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testGetIndexOfText {
    NSString *testString  = @"Test + String";
    NSInteger indexOfPlus = [testString getIndexOfText:@"+"];
    XCTAssertTrue(indexOfPlus != -1);
    XCTAssertEqual(indexOfPlus, 5);

    NSInteger indexOfEqual = [testString getIndexOfText:@"="];
    XCTAssertEqual(indexOfEqual, -1);
}

- (void)testIsStringEmpty {
    NSString *aString = @"Test";
    XCTAssertFalse([NSString isStringEmpty:aString]);

    aString = @"";
    XCTAssertTrue([NSString isStringEmpty:aString]);

    aString = @"         ";
    XCTAssertTrue([NSString isStringEmpty:aString]);

    aString = nil;
    XCTAssertTrue([NSString isStringEmpty:aString]);

    aString = NULL;
    XCTAssertTrue([NSString isStringEmpty:aString]);
}

- (void)testCaseInsensitiveSearchForText {
    NSString *text = @"TeSt";
    XCTAssertTrue([@"this is a test string." caseInsensitiveSearchForText:text]);

    text = @"test";
    XCTAssertTrue([@"this is a test string." caseInsensitiveSearchForText:text]);

    text = @"test1";
    XCTAssertFalse([@"this is a test string." caseInsensitiveSearchForText:text]);
}

- (void)testGetLoginURLForApplicationWithServerAndSite {
    NSString *testString = [NSString getLoginURLForApplication:NULL withServer:@"testServer" andSite:@"testSite"];

    XCTAssertFalse([NSString isStringEmpty:testString]);

    NSString *timezone       = [NSTimeZone localTimeZone].name;
    NSString *timezoneString = [NSString stringWithFormat:@"TimeZone=%@", timezone];
    NSRange range            = [testString rangeOfString:@":"];
    NSString *protocol       = [testString substringToIndex:range.location];
    XCTAssertTrue([protocol isEqualToString:@"http"]);
    XCTAssertTrue([testString containsString:@"testServer"]);
    XCTAssertTrue([testString containsString:@"testSite"]);
    XCTAssertTrue([testString containsString:timezoneString]);
}

- (void)testGetLoginURLForApplicationWithServerAndSite_Secure {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"enableSSL"];

    NSString *testString = [NSString getLoginURLForApplication:NULL withServer:@"testServer" andSite:@"testSite"];
    XCTAssertFalse([NSString isStringEmpty:testString]);

    NSString *timezone       = [NSTimeZone localTimeZone].name;
    NSRange range            = [testString rangeOfString:@":"];
    NSString *protocol       = [testString substringToIndex:range.location];
    NSString *timezoneString = [NSString stringWithFormat:@"TimeZone=%@", timezone];
    XCTAssertTrue([protocol isEqualToString:@"http"]);
    XCTAssertTrue([testString containsString:@"testServer"]);
    XCTAssertTrue([testString containsString:@"testSite"]);
    XCTAssertTrue([testString containsString:timezoneString]);

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableSSL"];
}

@end
