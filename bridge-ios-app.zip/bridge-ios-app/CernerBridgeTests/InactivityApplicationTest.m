//
//  InactivityApplicationTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 12/17/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "BridgeCommonConstants.h"
#import "InactivityApplication.h"

@interface InactivityApplication ()
@property (nonatomic, strong) NSTimer *idleTimer;
@property (nonatomic, assign) BOOL isTimeoutEnabled;

- (void)resetIdleTimer;
- (void)idleTimerExceeded;
@end

@interface InactivityApplicationTest : XCTestCase
@property (nonatomic, strong) InactivityApplication *inactivityApplication;
@end

@implementation InactivityApplicationTest

- (void)setUp {
    self.inactivityApplication = (InactivityApplication *)[UIApplication sharedApplication];
}

- (void)tearDown {
    self.inactivityApplication.idleTimer = nil;
    self.inactivityApplication           = nil;
}

- (void)testSendEvent_TimerAlreadySet {
    self.inactivityApplication.idleTimer = [NSTimer timerWithTimeInterval:60
                                                                  repeats:NO
                                                                    block:^(NSTimer *_Nonnull timer){

                                                                    }];

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication reject] resetIdleTimer];

    UIEvent *event          = [UIEvent new];
    OCMockObject *mockEvent = [OCMockObject partialMockForObject:event];
    [[mockEvent reject] allTouches];

    [self.inactivityApplication sendEvent:event];

    CernerOCMockVerify(mockApplication);
    CernerOCMockVerify(mockEvent);

    [mockApplication stopMocking];
    [mockEvent stopMocking];
}

- (void)testSendEvent_NoTouches {
    self.inactivityApplication.idleTimer = nil;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication reject] resetIdleTimer];

    UIEvent *event          = [UIEvent new];
    OCMockObject *mockEvent = [OCMockObject partialMockForObject:event];
    [[[mockEvent expect] andReturn:NULL] allTouches];

    [self.inactivityApplication sendEvent:event];

    CernerOCMockVerify(mockApplication);
    CernerOCMockVerify(mockEvent);

    [mockApplication stopMocking];
    [mockEvent stopMocking];
}

- (void)testSendEvent_TouchButPhaseNotStarted {
    self.inactivityApplication.idleTimer = nil;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication reject] resetIdleTimer];

    id mockTouch = [OCMockObject niceMockForClass:[UITouch class]];
    [[[mockTouch stub] andReturnValue:OCMOCK_VALUE(UITouchPhaseMoved)] phase];

    NSSet *touchSet = [[NSSet alloc] initWithArray:@[mockTouch]];

    UIEvent *event = [UIEvent new];
    id mockEvent   = [OCMockObject partialMockForObject:event];
    [[[mockEvent stub] andReturn:touchSet] allTouches];

    [self.inactivityApplication sendEvent:event];

    CernerOCMockVerify(mockApplication);
    CernerOCMockVerify(mockEvent);
    CernerOCMockVerify(mockTouch);

    [mockApplication stopMocking];
    [mockEvent stopMocking];
    [mockTouch stopMocking];
}

- (void)testSendEvent_ResetTimer {
    self.inactivityApplication.idleTimer = nil;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication expect] resetIdleTimer];

    id mockTouch = [OCMockObject niceMockForClass:[UITouch class]];
    [[[mockTouch stub] andReturnValue:OCMOCK_VALUE(UITouchPhaseBegan)] phase];

    NSSet *touchSet = [[NSSet alloc] initWithArray:@[mockTouch]];

    UIEvent *event = [UIEvent new];
    id mockEvent   = [OCMockObject partialMockForObject:event];
    [[[mockEvent stub] andReturn:touchSet] allTouches];

    [self.inactivityApplication sendEvent:event];

    CernerOCMockVerify(mockApplication);
    CernerOCMockVerify(mockEvent);
    CernerOCMockVerify(mockTouch);

    [mockApplication stopMocking];
    [mockEvent stopMocking];
    [mockTouch stopMocking];
}

- (void)testSetApplicationTimeout {
    self.inactivityApplication.applicationTimeout = 0;

    [self.inactivityApplication setApplicationTimeout:50];

    XCTAssertEqual(self.inactivityApplication.applicationTimeout, 50);
}

- (void)testResetIdleTimer_TimerExistsAndTimeoutNotEnabled {
    self.inactivityApplication.isTimeoutEnabled = false;
    OCMockObject *mockTimer                     = [OCMockObject mockForClass:[NSTimer class]];
    [[mockTimer expect] invalidate];
    self.inactivityApplication.idleTimer = (NSTimer *)mockTimer;

    [self.inactivityApplication resetIdleTimer];

    XCTAssertNil(self.inactivityApplication.idleTimer);
}

- (void)testResetIdleTimer {
    self.inactivityApplication.isTimeoutEnabled   = true;
    self.inactivityApplication.applicationTimeout = 10;
    self.inactivityApplication.idleTimer          = nil;

    [self.inactivityApplication resetIdleTimer];

    XCTAssertNotNil(self.inactivityApplication.idleTimer);
}

- (void)testEnableIdleTimer {
    self.inactivityApplication.isTimeoutEnabled   = false;
    self.inactivityApplication.applicationTimeout = 10;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication expect] resetIdleTimer];

    [self.inactivityApplication enableIdleTimer];

    XCTAssertTrue(self.inactivityApplication.isTimeoutEnabled);

    CernerOCMockVerify(mockApplication);
    [mockApplication stopMocking];
}

- (void)testDisableIdleTimer_timeoutNotEnabled {
    self.inactivityApplication.isTimeoutEnabled = false;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication reject] resetIdleTimer];

    [self.inactivityApplication disableIdleTimer];

    CernerOCMockVerify(mockApplication);
    [mockApplication stopMocking];
}

- (void)testDisableIdleTimer_timeoutEnabled {
    self.inactivityApplication.isTimeoutEnabled = true;

    OCMockObject *mockApplication = [OCMockObject partialMockForObject:self.inactivityApplication];
    [[mockApplication expect] resetIdleTimer];

    [self.inactivityApplication disableIdleTimer];

    CernerOCMockVerify(mockApplication);
    [mockApplication stopMocking];
}

- (void)testIdleTimerExceeded_timeoutNotEnabled {
    self.inactivityApplication.isTimeoutEnabled = false;

    OCMockObject *mockNotification = [OCMockObject partialMockForObject:[NSNotificationCenter defaultCenter]];
    [[mockNotification reject] postNotificationName:OCMOCK_ANY object:nil];

    [self.inactivityApplication idleTimerExceeded];

    CernerOCMockVerify(mockNotification);

    [mockNotification stopMocking];
}

- (void)testIdleTimerExceeded_timeoutEnabled {
    self.inactivityApplication.isTimeoutEnabled = true;

    OCMockObject *mockNotification = [OCMockObject partialMockForObject:[NSNotificationCenter defaultCenter]];
    [[mockNotification expect] postNotificationName:kNotification_ApplicationDidTimeout object:nil];

    [self.inactivityApplication idleTimerExceeded];

    CernerOCMockVerify(mockNotification);

    [mockNotification stopMocking];
}

@end
