//
//  MainNavigationBarTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/5/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "HTMLParser+XPathHelper.h"
#import "MainNavigationBar.h"
#import "NavigationBarDropDownMenuDelegate.h"
#import "WebActionResponderDelegate.h"
#import "WebViewNavigationBarDelegate.h"

@interface MainNavigationBar () <WebViewNavigationBarDelegate>
@property (nonatomic, strong) NSString *leftButtonID;
@property (nonatomic, strong) NSString *leftButtonText;
@property (nonatomic, assign) BOOL isFilterButton;
@property (nonatomic, assign) BOOL shouldHideAppMenuButton;
- (void)resetToDefaults;
- (void)setButtonAttributesFromHTML:(HTMLElement *)element;
- (void)navigationBarButtonClicked:(UIBarButtonItem *)sender;
- (void)setUIAttributesForNavigationBarWithTitle:(NSString *)pageTitle;
- (UIBarButtonItem *)createBarButtonWithTag:(NavigationBarButtonTag)tag withTitle:(NSString *)title andImage:(UIImage *)image;
@end

@interface MainNavigationBarTest : XCTestCase
@property (nonatomic, strong) MainNavigationBar *mainNavigationBar;
@end

@implementation MainNavigationBarTest

- (void)setUp {
    [super setUp];

    self.mainNavigationBar = [[MainNavigationBar alloc] init];
}

- (void)tearDown {
    [super tearDown];

    self.mainNavigationBar = nil;
}

- (void)testAwakeFromNib {
    self.mainNavigationBar.shouldHideAppMenuButton = false;

    [self.mainNavigationBar awakeFromNib];

    XCTAssertTrue(self.mainNavigationBar.shouldHideAppMenuButton);
    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@""]);
}

- (void)testResetToDefaults {
    self.mainNavigationBar.leftButtonID   = @"TestID";
    self.mainNavigationBar.leftButtonText = @"TestText";
    self.mainNavigationBar.isFilterButton = true;

    [self.mainNavigationBar resetToDefaults];

    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@""]);
    XCTAssertTrue([self.mainNavigationBar.leftButtonText isEqualToString:@""]);
    XCTAssertFalse(self.mainNavigationBar.isFilterButton);
    XCTAssertNil(self.mainNavigationBar.topItem.leftBarButtonItem);
    XCTAssertNil(self.mainNavigationBar.topItem.rightBarButtonItem);
}

- (void)testSetAttributesForNavigationBarButtonsFromHTML_BackButton {
    self.mainNavigationBar.leftButtonText = @"TestText";
    self.mainNavigationBar.leftButtonID   = @"TestID";

    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_Backbtn", @"type": @"submit", @"name": @"test_Name"};

    HTMLElement *element = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"BackButtonText"];

    [self.mainNavigationBar setButtonAttributesFromHTML:element];

    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@"test_Backbtn"]);
    XCTAssertTrue([self.mainNavigationBar.leftButtonText isEqualToString:@"BackButtonText"]);
}

- (void)testSetAttributesForNavigationBarButtonsFromHTML_FilterButton {
    self.mainNavigationBar.isFilterButton = false;
    self.mainNavigationBar.leftButtonText = @"TestText";
    self.mainNavigationBar.leftButtonID   = @"TestID";

    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_btnAddPoc", @"type": @"submit", @"name": @"test_Name"};

    HTMLElement *element = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"FilterButtonText"];

    [self.mainNavigationBar setButtonAttributesFromHTML:element];

    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@"test_btnAddPoc"]);
    XCTAssertTrue([self.mainNavigationBar.leftButtonText isEqualToString:@""]);
    XCTAssertTrue(self.mainNavigationBar.isFilterButton);
}

- (void)testSetAttributesForNavigationBarButtonsFromHTML_BackButtonWithText {
    self.mainNavigationBar.leftButtonText = @"TestText";
    self.mainNavigationBar.leftButtonID   = @"TestID";

    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_lnkhome", @"type": @"submit", @"name": @"test_Name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"BackButtonText"];

    [self.mainNavigationBar setButtonAttributesFromHTML:element];

    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@"test_lnkhome"]);
    XCTAssertTrue([self.mainNavigationBar.leftButtonText isEqualToString:@"BackButtonText"]);

    self.mainNavigationBar.leftButtonText = @"Back";
    self.mainNavigationBar.leftButtonID   = @"TestID";

    [self.mainNavigationBar setButtonAttributesFromHTML:element];

    XCTAssertFalse([self.mainNavigationBar.leftButtonID isEqualToString:@"test_lnkhome"]);
    XCTAssertFalse([self.mainNavigationBar.leftButtonText isEqualToString:@"BackButtonText"]);
}

- (void)testParseItemsWithTitleFromHTML {

    NSDictionary *properties  = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element      = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];
    HTMLElement *titleElement = [[HTMLElement alloc] initWithElementType:@"title" properties:properties text:@"Test_Title"];

    NSString *testHTML = @"<input type=\"submit\" name=\"btnAddPoc\" value=\"Test_Filter\" id=\"test_btnAddPoc_ID\">"
                         @"<input=\"submit\" name=\"backbtn\" value=\"Test_Back\" id=\"test_backbtn_ID\">"
                         @"<input type=\"submit\" name=\"lnkhome\" value=\"Test_Home\" id=\"test_lnkhome_ID\">";

    NSString *title                 = @"Test_Title";
    OCMockObject *mockNavigationBar = [OCMockObject partialMockForObject:self.mainNavigationBar];
    [[mockNavigationBar expect] resetToDefaults];
    [[mockNavigationBar expect] setButtonAttributesFromHTML:element];
    [[mockNavigationBar expect] setUIAttributesForNavigationBarWithTitle:title];

    OCMockObject *mockParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockParser stub] andReturn:@[element]] getLeftBarButtonNavigationBarElementsFromHTML:testHTML];
    [[[mockParser stub] andReturn:titleElement] parseTitleFromHTML:testHTML];

    [self.mainNavigationBar parseItemsWithTitle:title fromHTML:testHTML];

    CernerOCMockVerify(mockNavigationBar);

    [mockParser stopMocking];
    [mockNavigationBar stopMocking];
}

- (void)testParseItemsWithTitleFromHTML_NoElements {

    NSDictionary *properties  = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *titleElement = [[HTMLElement alloc] initWithElementType:@"title" properties:properties text:@"Test_Title"];

    self.mainNavigationBar.shouldHideAppMenuButton = false;
    self.mainNavigationBar.leftButtonID            = @"";
    self.mainNavigationBar.leftButtonText          = @"";

    NSString *testHTML = @"<input type=\"submit\" name=\"btnAddPoc\" value=\"Test_Filter\" id=\"test_btnAddPoc_ID\">"
                         @"<input=\"submit\" name=\"backbtn\" value=\"Test_Back\" id=\"test_backbtn_ID\">"
                         @"<input type=\"submit\" name=\"lnkhome\" value=\"Test_Home\" id=\"test_lnkhome_ID\">";

    NSString *title                 = @"Test_Title";
    OCMockObject *mockNavigationBar = [OCMockObject partialMockForObject:self.mainNavigationBar];
    [[mockNavigationBar expect] resetToDefaults];
    [[mockNavigationBar expect] setUIAttributesForNavigationBarWithTitle:title];
    [[mockNavigationBar reject] setButtonAttributesFromHTML:OCMOCK_ANY];

    OCMockObject *mockParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockParser stub] andReturn:@[]] getLeftBarButtonNavigationBarElementsFromHTML:testHTML];
    [[[mockParser stub] andReturn:titleElement] parseTitleFromHTML:testHTML];

    [self.mainNavigationBar parseItemsWithTitle:title fromHTML:testHTML];

    CernerOCMockVerify(mockNavigationBar);
    XCTAssertTrue([self.mainNavigationBar.leftButtonID isEqualToString:@"AppMenu"]);
    XCTAssertTrue([self.mainNavigationBar.leftButtonText isEqualToString:@"Applications"]);

    [mockParser stopMocking];
    [mockNavigationBar stopMocking];
}

- (void)testInitializeButtonsWithPageTitle_RightAndNull {
    self.mainNavigationBar.leftButtonID            = @"";
    self.mainNavigationBar.leftButtonText          = @"TestText";
    self.mainNavigationBar.shouldHideAppMenuButton = false;
    self.mainNavigationBar.isFilterButton          = false;

    OCMockObject *mockMainNavBar = [OCMockObject partialMockForObject:self.mainNavigationBar];
    [[mockMainNavBar expect] createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:OCMOCK_ANY];
    [[mockMainNavBar reject] createBarButtonWithTag:kNavBarButton_Menu withTitle:OCMOCK_ANY andImage:OCMOCK_ANY];
    [[mockMainNavBar reject] createBarButtonWithTag:kNavBarButton_Left withTitle:OCMOCK_ANY andImage:OCMOCK_ANY];

    CernerOCMockSafeExecute([self.mainNavigationBar setUIAttributesForNavigationBarWithTitle:@"PageTitle"]);
    CernerOCMockVerify(mockMainNavBar);
}

- (void)testInitializeButtonsWithPageTitle_RightAndMenu {
    self.mainNavigationBar.leftButtonID            = @"TestID";
    self.mainNavigationBar.leftButtonText          = @"TestText";
    self.mainNavigationBar.shouldHideAppMenuButton = false;
    self.mainNavigationBar.isFilterButton          = false;

    OCMockObject *mockMainNavBar = [OCMockObject partialMockForObject:self.mainNavigationBar];
    [[mockMainNavBar expect] createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:OCMOCK_ANY];
    [[mockMainNavBar expect] createBarButtonWithTag:kNavBarButton_Menu withTitle:@"TestText" andImage:NULL];

    NSString *expectedValue               = [NSString stringWithFormat:@"javascript:document.getElementById('%@').style.visibility = 'hidden';", self.mainNavigationBar.leftButtonID];
    id mockActionDelegate                 = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.mainNavigationBar.actionDelegate = mockActionDelegate;
    [[mockActionDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                                   XCTAssertTrue([value isEqualToString:expectedValue]);
                               }]];

    CernerOCMockSafeExecute([self.mainNavigationBar setUIAttributesForNavigationBarWithTitle:@"PageTitle"]);
    CernerOCMockVerify(mockMainNavBar);
}

- (void)testInitializeButtonsWithPageTitle_FilterButton {
    self.mainNavigationBar.leftButtonID            = @"TestID";
    self.mainNavigationBar.leftButtonText          = @"TestText";
    self.mainNavigationBar.shouldHideAppMenuButton = true;
    self.mainNavigationBar.isFilterButton          = true;

    OCMockObject *mockMainNavBar = [OCMockObject partialMockForObject:self.mainNavigationBar];
    [[mockMainNavBar expect] createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:OCMOCK_ANY];
    [[mockMainNavBar expect] createBarButtonWithTag:kNavBarButton_Left withTitle:@"TestText" andImage:OCMOCK_ANY];

    NSString *expectedValue               = [NSString stringWithFormat:@"javascript:document.getElementById('%@').style.visibility = 'hidden';", self.mainNavigationBar.leftButtonID];
    id mockActionDelegate                 = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.mainNavigationBar.actionDelegate = mockActionDelegate;
    [[mockActionDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                                   XCTAssertTrue([value isEqualToString:expectedValue]);
                               }]];

    CernerOCMockSafeExecute([self.mainNavigationBar setUIAttributesForNavigationBarWithTitle:@"PageTitle"]);
    CernerOCMockVerify(mockMainNavBar);
}

- (void)testCreateNavBarButtonWithTagWithTitleAndImage {

    UIBarButtonItem *barButton = [self.mainNavigationBar createBarButtonWithTag:kNavBarButton_Left withTitle:@"TestTitle" andImage:NULL];

    XCTAssertNotNil(barButton);

    UIButton *button = barButton.customView;
    XCTAssertNotNil(button);
    XCTAssertTrue([button.titleLabel.text isEqualToString:@"TestTitle"]);
    XCTAssertEqual(button.tag, kNavBarButton_Left);
    XCTAssertNil(button.imageView.image);

    UIImage *image = [UIImage imageNamed:@"leftArrowIcon"];
    barButton      = nil;
    barButton      = [self.mainNavigationBar createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:image];

    XCTAssertNotNil(barButton);

    button = (UIButton *)barButton.customView;
    XCTAssertNotNil(button);
    XCTAssertNil(button.titleLabel.text);
    XCTAssertEqual(button.tag, kNavBarButton_Right);
    XCTAssertNotNil(button.imageView.image);

    barButton = nil;
    barButton = [self.mainNavigationBar createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:NULL];

    XCTAssertNil(barButton);
}

- (void)testNavigationBarButtonClicked_MenuButton {
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] init];
    barButton.tag              = kNavBarButton_Menu;

    id mockDropDownMenuDelegate                 = [OCMockObject niceMockForProtocol:@protocol(NavigationBarDropDownMenuDelegate)];
    self.mainNavigationBar.dropDownMenuDelegate = mockDropDownMenuDelegate;
    [[mockDropDownMenuDelegate expect] performActionBasedOnNavigationBarButtonClick:barButton.tag];

    id mainMenuDelegate                   = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.mainNavigationBar.actionDelegate = mainMenuDelegate;
    [[mainMenuDelegate expect] performShowAppMenuAction];

    CernerOCMockSafeExecute([self.mainNavigationBar navigationBarButtonClicked:barButton]);
    CernerOCMockVerify(mockDropDownMenuDelegate);
    CernerOCMockVerify(mainMenuDelegate);
}

- (void)testNavigationBarButtonClicked_LeftButton {
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] init];
    barButton.tag              = kNavBarButton_Left;

    id mockDropDownMenuDelegate                 = [OCMockObject niceMockForProtocol:@protocol(NavigationBarDropDownMenuDelegate)];
    self.mainNavigationBar.dropDownMenuDelegate = mockDropDownMenuDelegate;
    [[mockDropDownMenuDelegate expect] performActionBasedOnNavigationBarButtonClick:barButton.tag];

    NSString *expectedValue               = [NSString stringWithFormat:@"document.getElementById('%@').click();", self.mainNavigationBar.leftButtonID];
    id mockActionDelegate                 = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.mainNavigationBar.actionDelegate = mockActionDelegate;
    [[mockActionDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                                   XCTAssertTrue([value isEqualToString:expectedValue]);
                               }]];

    CernerOCMockSafeExecute([self.mainNavigationBar navigationBarButtonClicked:barButton]);
    CernerOCMockVerify(mockDropDownMenuDelegate);
}

- (void)testNavigationBarButtonClicked_RightButton {
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] init];
    barButton.tag              = kNavBarButton_Right;

    id mockDropDownMenuDelegate                 = [OCMockObject niceMockForProtocol:@protocol(NavigationBarDropDownMenuDelegate)];
    self.mainNavigationBar.dropDownMenuDelegate = mockDropDownMenuDelegate;
    [[mockDropDownMenuDelegate expect] performActionBasedOnNavigationBarButtonClick:barButton.tag];

    CernerOCMockSafeExecute([self.mainNavigationBar navigationBarButtonClicked:barButton]);
    CernerOCMockVerify(mockDropDownMenuDelegate);
}

- (void)testAdjustVisibilityOfAppMenuIcon {
    self.mainNavigationBar.shouldHideAppMenuButton = true;
    [self.mainNavigationBar adjustVisibilityOfAppMenuIcon:false];
    XCTAssertFalse(self.mainNavigationBar.shouldHideAppMenuButton);
}

@end
