//
//  WebServerSiteViewControllerTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 12/7/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "TestUtils.h"
#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

#import "AlertViewUtils.h"
#import "BlockExecutionScript.h"
#import "BridgeCommonConstants.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "UIViewController+TopmostPresentedViewController.h"
#import "WebServerSiteViewController.h"
#import "WebServerSiteViewControllerDelegate.h"

@interface WebServerSiteViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textWebServerName;
@property (weak, nonatomic) IBOutlet UITextField *textWebSiteName;
@property (nonatomic, strong) UIActivityIndicatorView *loadingActivityIndicator;
@property (nonatomic, strong) NSURLSessionDataTask *doneSessionTask;

- (NSURL *)setUpLoginURL;
- (void)addActivityIndicator;
- (BOOL)checkIfFieldsAreEmpty;
- (void)handleSuccess;
- (void)handleError:(NSError *)error;
- (void)showAlertForWebSettingAlertType:(WebSettingAlertType)type withErrorDescription:(NSString *)errorDescription;
- (void)setUpSessionWithURL:(NSURL *)url;
- (IBAction)done:(id)sender;
- (IBAction)textFieldDidChange:(id)sender;
@end

@interface WebServerSiteViewControllerTest : XCTestCase
@property (nonatomic, strong) WebServerSiteViewController *webServerSiteVC;
@end

@implementation WebServerSiteViewControllerTest

- (void)setUp {
    [super setUp];

    UINavigationController *navigationController = (UINavigationController *)[WebServerSiteViewController createContainingNavigationController];

    self.webServerSiteVC = (WebServerSiteViewController *)[navigationController topViewController];
    [self.webServerSiteVC loadView];
}

- (void)tearDown {
    [super tearDown];
    self.webServerSiteVC = nil;
}

- (void)testCreateContainingNavigationController {
    UIViewController *controller = [WebServerSiteViewController createContainingNavigationController];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller isKindOfClass:[UINavigationController class]]);
}

- (void)testAddActivityIndicator {
    XCTAssertNil(self.webServerSiteVC.navigationItem.rightBarButtonItem.customView);

    [self.webServerSiteVC addActivityIndicator];

    XCTAssertNotNil(self.webServerSiteVC.navigationItem.rightBarButtonItem.customView);
    XCTAssertTrue([self.webServerSiteVC.navigationItem.rightBarButtonItem.customView isKindOfClass:[UIActivityIndicatorView class]]);
}

- (void)testSetUpLoginURL {
    self.webServerSiteVC.textWebSiteName.text   = @"TestWebSite";
    self.webServerSiteVC.textWebServerName.text = @"TestWebServer";

    NSURL *testURL = [self.webServerSiteVC setUpLoginURL];

    XCTAssertNotNil(testURL);
    XCTAssertTrue([testURL.absoluteString containsString:self.webServerSiteVC.textWebSiteName.text]);
    XCTAssertTrue([testURL.absoluteString containsString:self.webServerSiteVC.textWebServerName.text]);
}

- (void)testViewDidLoad_DefaultsSet {
    self.webServerSiteVC.textWebSiteName.text   = @"";
    self.webServerSiteVC.textWebServerName.text = @"";

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:@NO] areWebServerDefaultsAlreadySet];

    [self.webServerSiteVC viewDidLoad];

    XCTAssertTrue([self.webServerSiteVC.textWebServerName.text isEqualToString:@""]);
    XCTAssertTrue([self.webServerSiteVC.textWebSiteName.text isEqualToString:@""]);

    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
}

- (void)testViewDidLoad_DefaultsNotSet {
    self.webServerSiteVC.textWebSiteName.text   = @"";
    self.webServerSiteVC.textWebServerName.text = @"";

    [[NSUserDefaults standardUserDefaults] setObject:@"TestWebSite" forKey:kDefaultsKey_WebSiteName];
    [[NSUserDefaults standardUserDefaults] setObject:@"TestWebServer" forKey:kDefaultsKey_WebServerName];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:@YES] areWebServerDefaultsAlreadySet];

    [self.webServerSiteVC viewDidLoad];

    XCTAssertTrue([self.webServerSiteVC.textWebServerName.text isEqualToString:@"TestWebServer"]);
    XCTAssertTrue([self.webServerSiteVC.textWebSiteName.text isEqualToString:@"TestWebSite"]);

    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebSiteName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebServerName];
}

- (void)testCheckIfFieldsAreEmpty_ContainText {
    self.webServerSiteVC.textWebServerName.text = @"test";
    self.webServerSiteVC.textWebSiteName.text   = @"test";

    BOOL isEmpty = [self.webServerSiteVC checkIfFieldsAreEmpty];

    XCTAssertFalse(isEmpty);
}

- (void)testCheckIfFieldsAreEmpty_isEmpty {
    self.webServerSiteVC.textWebServerName.text = @"   ";
    self.webServerSiteVC.textWebSiteName.text   = @"   ";

    BOOL isEmpty = [self.webServerSiteVC checkIfFieldsAreEmpty];

    XCTAssertTrue(isEmpty);
}

- (void)testShowAlertForWebSettingAlertTypeWithErrorDescription {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"title" message:@"MESSAGE" preferredStyle:UIAlertControllerStyleAlert];
    UINavigationController *navCon     = [UINavigationController new];

    OCMockObject *mockAlertUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[[mockAlertUtils expect] andReturn:alertController] alertForWebSettingAlertType:kWebSettingAlertType_EmptyField withErrorDescription:@"Error"];

    OCMockObject *mockViewController = [OCMockObject niceMockForClass:[UIViewController class]];
    [[[mockViewController expect] andReturn:navCon] topmostViewController];

    OCMockObject *mockNavCon = [OCMockObject partialMockForObject:navCon];
    [[mockNavCon expect] presentViewController:alertController animated:YES completion:nil];

    [self.webServerSiteVC showAlertForWebSettingAlertType:kWebSettingAlertType_EmptyField withErrorDescription:@"Error"];

    CernerOCMockVerify(mockAlertUtils);
    CernerOCMockVerify(mockViewController);
    CernerOCMockVerify(mockNavCon);

    [mockAlertUtils stopMocking];
    [mockViewController stopMocking];
    [mockNavCon stopMocking];
}

- (void)testHandleError {
    NSError *error = [NSError errorWithDomain:NSPOSIXErrorDomain code:3034 userInfo:@{NSLocalizedDescriptionKey: @"Description"}];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];
    [[mockSelf expect] showAlertForWebSettingAlertType:kWebSettingAlertType_Error withErrorDescription:@"Description"];

    [self.webServerSiteVC handleError:error];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testHandleSuccess {
    NSString *webserver = @"TestWebServerName";
    NSString *website   = @"TestWebSite";

    self.webServerSiteVC.textWebSiteName.text   = website;
    self.webServerSiteVC.textWebServerName.text = webserver;

    XCTAssertFalse([[[NSUserDefaults standardUserDefaults] stringForKey:kDefaultsKey_WebServerName] isEqualToString:webserver]);
    XCTAssertFalse([[[NSUserDefaults standardUserDefaults] stringForKey:kDefaultsKey_WebSiteName] isEqualToString:website]);

    id mockDelegate = [OCMockObject niceMockForProtocol:@protocol(WebServerSiteViewControllerDelegate)];

    self.webServerSiteVC.delegate = mockDelegate;
    [[mockDelegate expect] loadLoginPageBasedOnWebSettings];

    [self.webServerSiteVC handleSuccess];

    XCTAssertTrue([[[NSUserDefaults standardUserDefaults] stringForKey:kDefaultsKey_WebServerName] isEqualToString:webserver]);
    XCTAssertTrue([[[NSUserDefaults standardUserDefaults] stringForKey:kDefaultsKey_WebSiteName] isEqualToString:website]);
    CernerOCMockVerify(mockDelegate);

    [mockDelegate stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebSiteName];
}

- (void)testSetUpSessionWithURL_StatusCodePass {
    NSString *websiteName   = @"WebsiteName";
    NSString *webserverName = @"WebserverName";
    NSString *urlString     = [NSString stringWithFormat:@"http://%@/%@/Page.aspx", webserverName, websiteName];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];
    [[mockSelf expect] addActivityIndicator];
    [[mockSelf expect] handleSuccess];

    NSInteger pagetimeout      = 5;
    OCMockObject *mockDefaults = [OCMockObject niceMockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(pagetimeout)] getPageTimeoutFromUserDefaults];

    OCMockObject *mockDataTask = [OCMockObject mockForClass:[NSURLSessionDataTask class]];
    [[mockDataTask expect] resume];

    OCMockObject *mockURLResponse = [OCMockObject mockForClass:[NSHTTPURLResponse class]];
    [[[mockURLResponse stub] andReturnValue:@(200)] statusCode];

    __block void (^completion)(NSData *data, NSURLResponse *response, NSError *error);
    OCMockObject *mockURLSession = [OCMockObject partialMockForObject:[NSURLSession sharedSession]];
    [(NSURLSession *)[[mockURLSession expect] andReturn:mockDataTask]
        dataTaskWithRequest:OCMOCK_ANY
          completionHandler:[OCMArg checkWithBlock:^BOOL(void (^block)(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error)) {
              completion = block;

              return YES;
          }]];

    NSURL *url = [NSURL URLWithString:urlString];
    [self.webServerSiteVC setUpSessionWithURL:url];

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion(nil, (NSHTTPURLResponse *)mockURLResponse, nil));

    CernerOCMockVerify(mockDefaults);

    [mockSelf stopMocking];
    [mockDefaults stopMocking];
}

- (void)testSetUpSessionWithURL_Error_Cancelled {
    NSError *error          = [NSError errorWithDomain:NSPOSIXErrorDomain code:-999 userInfo:NULL];
    NSString *websiteName   = @"WebsiteName";
    NSString *webserverName = @"WebserverName";
    NSString *urlString     = [NSString stringWithFormat:@"http://%@/%@/Page.aspx", webserverName, websiteName];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];
    [[mockSelf expect] addActivityIndicator];
    [[mockSelf reject] handleSuccess];
    [[mockSelf reject] handleError:error];

    NSInteger pagetimeout      = 5;
    OCMockObject *mockDefaults = [OCMockObject niceMockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(pagetimeout)] getPageTimeoutFromUserDefaults];

    OCMockObject *mockDataTask = [OCMockObject mockForClass:[NSURLSessionDataTask class]];
    [[mockDataTask expect] resume];

    __block void (^completion)(NSData *_Nullable, NSURLResponse *_Nullable, NSError *_Nullable);
    OCMockObject *mockURLSession = [OCMockObject partialMockForObject:[NSURLSession sharedSession]];
    [(NSURLSession *)[[mockURLSession expect] andReturn:mockDataTask]
        dataTaskWithRequest:OCMOCK_ANY
          completionHandler:[OCMArg checkWithBlock:^BOOL(void (^block)(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error)) {
              completion = block;
              return YES;
          }]];

    NSURL *url = [NSURL URLWithString:urlString];
    [self.webServerSiteVC setUpSessionWithURL:url];

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion(nil, nil, error));

    CernerOCMockVerify(mockDefaults);
    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
    [mockDefaults stopMocking];
}

- (void)testSetUpSessionWithURL_Error {
    NSError *error          = [NSError errorWithDomain:NSPOSIXErrorDomain code:1009 userInfo:NULL];
    NSString *websiteName   = @"WebsiteName";
    NSString *webserverName = @"WebserverName";
    NSString *urlString     = [NSString stringWithFormat:@"http://%@/%@/Page.aspx", webserverName, websiteName];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];
    [[mockSelf expect] addActivityIndicator];
    [[mockSelf reject] handleSuccess];
    [[mockSelf expect] handleError:OCMOCK_ANY];

    NSInteger pagetimeout      = 5;
    OCMockObject *mockDefaults = [OCMockObject niceMockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(pagetimeout)] getPageTimeoutFromUserDefaults];

    OCMockObject *mockDataTask = [OCMockObject mockForClass:[NSURLSessionDataTask class]];
    [[mockDataTask expect] resume];

    __block void (^completion)(NSData *_Nullable, NSURLResponse *_Nullable, NSError *_Nullable);
    OCMockObject *mockURLSession = [OCMockObject partialMockForObject:[NSURLSession sharedSession]];
    [(NSURLSession *)[[mockURLSession expect] andReturn:mockDataTask]
        dataTaskWithRequest:OCMOCK_ANY
          completionHandler:[OCMArg checkWithBlock:^BOOL(void (^block)(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error)) {
              completion = block;

              return YES;
          }]];

    NSURL *url = [NSURL URLWithString:urlString];
    [self.webServerSiteVC setUpSessionWithURL:url];

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion(nil, nil, error));

    CernerOCMockVerify(mockDefaults);

    [mockSelf stopMocking];
    [mockDefaults stopMocking];
}

- (void)testSetUpSessionWithURL_InvalidResponse {
    self.webServerSiteVC.loadingActivityIndicator = [UIActivityIndicatorView new];
    [self.webServerSiteVC.loadingActivityIndicator startAnimating];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];

    [[mockSelf expect] addActivityIndicator];
    [[mockSelf expect] showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidResponse withErrorDescription:OCMOCK_ANY];
    [[mockSelf reject] handleSuccess];
    [[mockSelf reject] handleError:OCMOCK_ANY];

    NSInteger pagetimeout = 5;

    OCMockObject *mockDefaults = [OCMockObject niceMockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(pagetimeout)] getPageTimeoutFromUserDefaults];

    OCMockObject *mockDataTask = [OCMockObject mockForClass:[NSURLSessionDataTask class]];
    [[mockDataTask expect] resume];

    OCMockObject *mockURLResponse = [OCMockObject mockForClass:[NSHTTPURLResponse class]];
    [[[mockURLResponse stub] andReturnValue:@(500)] statusCode];

    __block void (^completion)(NSData *_Nullable, NSURLResponse *_Nullable, NSError *_Nullable);
    OCMockObject *mockURLSession = [OCMockObject partialMockForObject:[NSURLSession sharedSession]];
    [(NSURLSession *)[[mockURLSession expect] andReturn:mockDataTask]
        dataTaskWithRequest:OCMOCK_ANY
          completionHandler:[OCMArg checkWithBlock:^BOOL(void (^block)(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error)) {
              completion = block;
              return YES;
          }]];

    NSString *websiteName   = @"WebsiteName";
    NSString *webserverName = @"WebserverName";
    NSString *urlString     = [NSString stringWithFormat:@"http://%@/%@/Page.aspx", webserverName, websiteName];

    NSURL *url = [NSURL URLWithString:urlString];
    [self.webServerSiteVC setUpSessionWithURL:url];

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion(nil, (NSHTTPURLResponse *)mockURLResponse, nil));

    CernerOCMockVerify(mockDefaults);

    [mockSelf stopMocking];
    [mockDefaults stopMocking];
}

- (void)testDone_EmptyFields {
    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];

    [[[mockSelf expect] andReturnValue:@YES] checkIfFieldsAreEmpty];
    [[mockSelf reject] setUpLoginURL];
    [[mockSelf reject] setUpSessionWithURL:OCMOCK_ANY];

    [self.webServerSiteVC done:[UIBarButtonItem new]];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testDone_InvalidUrl {
    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];

    [[[mockSelf expect] andReturnValue:@NO] checkIfFieldsAreEmpty];
    [[[mockSelf expect] andReturn:NULL] setUpLoginURL];
    [[mockSelf expect] showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidURL withErrorDescription:NULL];
    [[mockSelf reject] setUpSessionWithURL:OCMOCK_ANY];

    [self.webServerSiteVC done:[UIBarButtonItem new]];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testDone {
    NSURL *testUrl = [NSURL URLWithString:@"http://testURL/page.aspx"];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.webServerSiteVC];

    [[[mockSelf expect] andReturnValue:@NO] checkIfFieldsAreEmpty];
    [[[mockSelf expect] andReturn:testUrl] setUpLoginURL];
    [[mockSelf reject] showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidURL withErrorDescription:NULL];
    [[mockSelf expect] setUpSessionWithURL:testUrl];

    [self.webServerSiteVC done:[UIBarButtonItem new]];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testTextFieldDidChange_isAnimating {
    self.webServerSiteVC.loadingActivityIndicator = [UIActivityIndicatorView new];
    [self.webServerSiteVC.loadingActivityIndicator startAnimating];
    self.webServerSiteVC.doneSessionTask = [NSURLSessionDataTask new];

    OCMockObject *mockTask = [OCMockObject partialMockForObject:self.webServerSiteVC.doneSessionTask];
    [[mockTask expect] cancel];

    [self.webServerSiteVC textFieldDidChange:NULL];

    CernerOCMockVerify(mockTask);

    [mockTask stopMocking];
}

- (void)testTextFieldDidChange_NotAnimating {
    self.webServerSiteVC.loadingActivityIndicator = [UIActivityIndicatorView new];

    OCMockObject *mockURLSession = [OCMockObject partialMockForObject:[NSURLSession sharedSession]];

    [(NSURLSession *)[mockURLSession reject] getAllTasksWithCompletionHandler:[OCMArg checkWithBlock:OCMOCK_ANY]];

    [self.webServerSiteVC textFieldDidChange:NULL];

    CernerOCMockVerify(mockURLSession);
    [mockURLSession stopMocking];
}

@end
