//
//  AppDelegateTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 12/17/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import <CernScanningLibrary/CernBarcode.h>
#import <NewRelic/NewRelic.h>

#import "AppDelegate.h"
#import "MainViewController.h"

@interface AppDelegate ()
@property (strong, nonatomic) MainViewController *mainViewController;

- (void)registerNewRelic;
- (void)didScanBarcode:(NSNotification *)note;
- (void)applicationDidTimeout:(NSNotification *)notif;
@end

@interface AppDelegateTest : XCTestCase
@property (nonatomic, retain) AppDelegate *appDelegate;
@end

@implementation AppDelegateTest

- (void)setUp {
    self.appDelegate = [[AppDelegate alloc] init];
}

- (void)tearDown {
    self.appDelegate = nil;
}

- (void)testRegisterNewRelic {
    OCMockObject *mockNewRelicAgent = [OCMockObject niceMockForClass:[NewRelicAgent class]];
    [[mockNewRelicAgent expect] startWithApplicationToken:OCMOCK_ANY];

    [self.appDelegate registerNewRelic];

    CernerOCMockVerify(mockNewRelicAgent);

    [mockNewRelicAgent stopMocking];
}

- (void)testApplicationDidTimeout {
    self.appDelegate.mainViewController = [[MainViewController alloc] init];

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.appDelegate.mainViewController];
    [[mockMainVC expect] autoLogout];

    [self.appDelegate applicationDidTimeout:NULL];

    CernerOCMockVerify(mockMainVC);

    [mockMainVC stopMocking];
}

@end
