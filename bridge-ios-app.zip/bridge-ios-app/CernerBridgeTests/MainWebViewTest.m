//
//  MainWebViewTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/14/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

#import "AlertViewUtils.h"
#import "BridgeCommonConstants.h"
#import "HTMLParser+XPathHelper.h"
#import "InactivityApplication.h"
#import "MainViewUtils.h"
#import "MainWebView.h"
#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "UIApplication+TypeAdditions.h"
#import "WebViewMainViewDelegate.h"
#import "WebViewNavigationBarDelegate.h"

@interface MainWebView () <WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) NSString *lastURL;
@property (nonatomic, assign) NSInteger pageTimeoutVal;
@property (nonatomic, strong) NSTimer *pageTimer;
- (void)setApplicationTimeoutForPage:(NSString *)HTML;
- (void)parseAlertDetailsBasedOnHTML:(NSString *)HTML;
- (void)handleErrorPage:(NSString *)error url:(NSString *)currentURL;
- (void)pageTimerExceeded;
- (void)fixWebFormValidation;
@end

@interface MainWebViewTest : XCTestCase
@property (nonatomic, strong) MainWebView *webView;
@end

@implementation MainWebViewTest

- (void)setUp {
    [super setUp];

    self.webView = [[MainWebView alloc] init];
}

- (void)tearDown {
    [super tearDown];

    self.webView = nil;
}

- (void)testAwakeFromNib {
    self.webView.pageTimeoutVal     = 0;
    self.webView.navigationDelegate = nil;

    [self.webView awakeFromNib];

    XCTAssertNotNil(self.webView.navigationDelegate);
    XCTAssertNotEqual(self.webView.pageTimeoutVal, 0);
}

- (void)testInitialize {
    self.webView.pageTimeoutVal     = 0;
    self.webView.navigationDelegate = nil;

    [self.webView initialize];

    XCTAssertNotNil(self.webView.navigationDelegate);
    XCTAssertNotEqual(self.webView.pageTimeoutVal, 0);
}

- (void)testUnload_IsLoading {

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView stub] andReturnValue:@YES] isLoading];
    [[mockWebView expect] stopLoading];

    [self.webView unload];

    XCTAssertNil(self.webView.navigationDelegate);
    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testUnload_NotLoading {

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView stub] andReturnValue:@NO] isLoading];
    [[mockWebView reject] stopLoading];

    [self.webView unload];

    XCTAssertNil(self.webView.navigationDelegate);
    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testLoadURLShouldSetLastURL_NO {

    self.webView.lastURL        = @"";
    self.webView.applicationURL = @"";
    NSString *urlString         = @"http://test:8080/path";
    NSURL *url                  = [NSURL URLWithString:urlString];
    NSURLRequest *request       = [NSURLRequest requestWithURL:url];

    OCMockObject *mockURLRequest = [OCMockObject mockForClass:[NSURLRequest class]];
    [[[mockURLRequest stub] andReturn:request] requestWithURL:url];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [(WKWebView *)[mockWebView expect] loadRequest:request];

    [self.webView loadURL:url shouldSetLastURL:NO];

    XCTAssertTrue([self.webView.lastURL isEqualToString:@""]);
    CernerOCMockVerify(mockWebView);
}

- (void)testLoadURLShouldSetLastURL_YES {

    NSString *urlString         = @"http://test:8080/path";
    self.webView.lastURL        = @"";
    self.webView.applicationURL = urlString;
    NSURL *url                  = [NSURL URLWithString:urlString];
    NSURLRequest *request       = [NSURLRequest requestWithURL:url];

    OCMockObject *mockURLRequest = [OCMockObject mockForClass:[NSURLRequest class]];
    [[[mockURLRequest stub] andReturn:request] requestWithURL:url];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [(WKWebView *)[mockWebView expect] loadRequest:request];

    [self.webView loadURL:url shouldSetLastURL:YES];

    XCTAssertTrue([self.webView.lastURL isEqualToString:urlString]);
    CernerOCMockVerify(mockWebView);

    [mockURLRequest stopMocking];
    [mockWebView stopMocking];
}

/**
 * Verify https is used when using ssl mode
 */
- (void)testLoadURLShouldSetLastURL_Secure {

    OCMockObject *mockUserDefaults = [OCMockObject partialMockForObject:[NSUserDefaults standardUserDefaults]];
    [[[mockUserDefaults stub] andReturnValue:@YES] boolForKey:kDefaultsKey_EnableSSL];

    NSString *expectedUrlString = @"https://test:8080/path";

    NSString *urlString         = @"http://test:8080/path";
    self.webView.lastURL        = @"";
    self.webView.applicationURL = urlString;

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [(WKWebView *)[mockWebView expect] loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:expectedUrlString]]];

    [self.webView loadURL:[NSURL URLWithString:urlString] shouldSetLastURL:YES];

    XCTAssertTrue([self.webView.lastURL isEqualToString:expectedUrlString]);
    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
    [mockUserDefaults stopMocking];
}

- (void)testSetApplicationTimeoutForPageWithURL {
    NSString *testHTML = @"<input name=\"autoLogTime\" type=\"text\" value=\"^60\" maxlength=\"10\" id=\"_ctl0_autoLogTime\">";

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] setApplicationTimeout:60];

    [self.webView setApplicationTimeoutForPage:testHTML];

    CernerOCMockVerify(mockSharedApplication);

    [mockSharedApplication stopMocking];
}

- (void)testSetApplicationTimeoutForPageWithURL_Empty {
    NSString *testHTML = @"";

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] setApplicationTimeout:60];

    [self.webView setApplicationTimeoutForPage:testHTML];

    CernerOCMockVerify(mockSharedApplication);
    [mockSharedApplication stopMocking];
}

- (void)testSetApplicationTimeoutForPageWithURL_NotALogoutHTML {
    NSString *testHTML = @"<input name=\"TestName\" type=\"text\" value=\"^60\" maxlength=\"10\" id=\"TestID\">";

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] setApplicationTimeout:60];

    [self.webView setApplicationTimeoutForPage:testHTML];

    CernerOCMockVerify(mockSharedApplication);
    [mockSharedApplication stopMocking];
}

- (void)testSetApplicationTimeoutForPageWithURL_NotInRange {
    NSString *testHTML = @"<input name=\"autoLogTime\" type=\"text\" value=\"60\" maxlength=\"10\" id=\"_ctl0_autoLogTime\">";

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] setApplicationTimeout:60];

    [self.webView setApplicationTimeoutForPage:testHTML];

    CernerOCMockVerify(mockSharedApplication);
    [mockSharedApplication stopMocking];
}

- (void)testSetApplicationTimeoutForPageWithURL_ElementNil {
    NSString *testHTML = @"<input name=\"autoLogTime\" type=\"text\" value=\"60\" maxlength=\"10\" id=\"TestID\">";

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] setApplicationTimeout:60];

    [self.webView setApplicationTimeoutForPage:testHTML];

    CernerOCMockVerify(mockSharedApplication);
    [mockSharedApplication stopMocking];
}

- (void)testParseAlertDetailsBasedOnHTML_Empty {
    NSString *testHTML = @"";

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils reject] alertFromHTMLElements:OCMOCK_ANY];

    [self.webView parseAlertDetailsBasedOnHTML:testHTML];

    CernerOCMockVerify(mockAlertViewUtils);
    [mockAlertViewUtils stopMocking];
}

- (void)testParseAlertDetailsBasedOnHTML_NotInRange {
    NSString *testHTML = @"<input name=\"TestName\" type=\"text\" value=\"60\" maxlength=\"10\" id=\"TestID\">";

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils reject] alertFromHTMLElements:OCMOCK_ANY];

    [self.webView parseAlertDetailsBasedOnHTML:testHTML];

    CernerOCMockVerify(mockAlertViewUtils);
    [mockAlertViewUtils stopMocking];
}

- (void)testParseAlertDetailsBasedOnHTML_ElementsEmpty {
    NSString *testHTML = @"<a id=\"alertbox\" class=\"errorText\" href='javascript:alert(\"Alert<br>btn:OK<br>Error Text.\");'></a>";

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils reject] alertFromHTMLElements:OCMOCK_ANY];

    OCMockObject *mockHTMLParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockHTMLParser expect] andReturn:NULL] getErrorAlertInfoFromHTML:testHTML];

    [self.webView parseAlertDetailsBasedOnHTML:testHTML];

    CernerOCMockVerify(mockAlertViewUtils);
    CernerOCMockVerify(mockHTMLParser);

    [mockAlertViewUtils stopMocking];
    [mockHTMLParser stopMocking];
}

- (void)testParseAlertDetailsBasedOnHTML {
    NSString *testHTML       = @"<a id=\"alertbox\" class=\"errorText\" href='javascript:alert(\"Alert<br>btn:OK<br>Error Text.\");'></a>";
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"a" properties:properties text:@"javascript:alert(\"Alert<br>btn:OK<br>Error Text.\");"];
    NSArray *elements        = @[element];

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils expect] alertFromHTMLElements:elements];

    OCMockObject *mockHTMLParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockHTMLParser expect] andReturn:elements] getErrorAlertInfoFromHTML:testHTML];

    [self.webView parseAlertDetailsBasedOnHTML:testHTML];

    CernerOCMockVerify(mockAlertViewUtils);
    CernerOCMockVerify(mockHTMLParser);

    [mockAlertViewUtils stopMocking];
    [mockHTMLParser stopMocking];
}

- (void)testCheckWebSettingsExist_defaultsAlreadySet {
    OCMockObject *mockUserDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockUserDefaults expect] andReturnValue:@YES] areWebServerDefaultsAlreadySet];

    BOOL settingsExist = [self.webView checkWebSettingsExist];

    XCTAssertTrue(settingsExist);
    CernerOCMockVerify(mockUserDefaults);

    [mockUserDefaults stopMocking];
}

- (void)testCheckWebSettingsExist_defaultsNotSet {
    OCMockObject *mockUserDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockUserDefaults expect] andReturnValue:@NO] areWebServerDefaultsAlreadySet];

    id mockWebMainViewDelegate           = [OCMockObject niceMockForProtocol:@protocol(WebViewMainViewDelegate)];
    self.webView.webViewMainViewDelegate = mockWebMainViewDelegate;
    [[mockWebMainViewDelegate expect] displayWebSettingsErrorPage];

    BOOL settingsExist = YES;
    settingsExist      = [self.webView checkWebSettingsExist];

    XCTAssertFalse(settingsExist);
    CernerOCMockVerify(mockUserDefaults);
    CernerOCMockVerify(mockWebMainViewDelegate);

    [mockUserDefaults stopMocking];
}

- (void)testHandleErrorPageUrl_StartPage {

    NSString *error     = @"Error message";
    NSString *urlString = @"http://test:port/environment/Login.aspx";

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:false];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView expect] andReturnValue:@YES] checkWebSettingsExist];

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils expect] alertWithErrorType:kErrorAlertType_Server andMessage:error];
    [[mockAlertViewUtils reject] alertButtonTitlesWithLogout:YES];

    self.webView.applicationURL = urlString;
    [self.webView handleErrorPage:error url:urlString];

    CernerOCMockVerify(mockWebViewNavigationBarDelegate);
    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockAlertViewUtils);

    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebView stopMocking];
    [mockAlertViewUtils stopMocking];
}

- (void)testHandleErrorPageUrl_NotAStartPage {
    NSString *error     = @"Error message";
    NSString *urlString = @"http://test:port/environment/Main.aspx";

    self.webView.applicationURL = urlString;
    self.webView.lastURL        = urlString;

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:false];

    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[mockAlertViewUtils expect] alertWithErrorType:kErrorAlertType_General andMessage:error];
    [[mockAlertViewUtils expect] alertButtonTitlesWithLogout:YES];

    OCMockObject *mockDictionary = [OCMockObject mockForClass:[NSMutableDictionary class]];
    [[mockDictionary expect] createWithServerError:NO cancelResponse:urlString andOkResponse:self.webView.lastURL];

    [self.webView handleErrorPage:error url:urlString];

    CernerOCMockVerify(mockWebViewNavigationBarDelegate);
    CernerOCMockVerify(mockAlertViewUtils);
    CernerOCMockVerify(mockDictionary);

    [mockWebViewNavigationBarDelegate stopMocking];
    [mockAlertViewUtils stopMocking];
    [mockDictionary stopMocking];
}

- (void)testPageTimerExceeded_NotLoading {

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView expect] andReturnValue:@NO] isLoading];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate reject] adjustVisibilityOfAppMenuIcon:false];

    [self.webView pageTimerExceeded];

    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockWebViewNavigationBarDelegate);

    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebView stopMocking];
}

- (void)testPageTimerExceeded_Loading {
    NSString *urlString = @"http://test:port/environment/Main.aspx";

    self.webView.applicationURL = urlString;
    self.webView.lastURL        = urlString;

    OCMockObject *mockMainViewUtils  = [OCMockObject mockForClass:[MainViewUtils class]];
    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    OCMockObject *mockDictionary     = [OCMockObject mockForClass:[NSMutableDictionary class]];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;

    [[[mockMainViewUtils expect] andReturnValue:@NO] isPageTimedOut:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@NO] containsServerError:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@NO] isErrorPage:OCMOCK_ANY];

    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:false];
    [[mockAlertViewUtils expect] alertWithErrorType:kErrorAlertType_PageTimeoutError andMessage:@"An error occurred:"];
    [[mockAlertViewUtils expect] alertButtonTitlesWithLogout:NO];

    [[mockDictionary expect] createWithServerError:NO cancelResponse:urlString andOkResponse:self.webView.lastURL];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView expect] andReturnValue:@YES] isLoading];

    [[mockWebView expect] evaluateJavaScript:kDocumentOuterHTML
                           completionHandler:[OCMArg checkWithBlock:^BOOL(void (^completionBlock)(id _Nullable result, NSError *_Nullable error)) {
                               completionBlock(nil, nil);
                               CernerOCMockVerify(mockMainViewUtils);
                               CernerOCMockVerify(mockWebViewNavigationBarDelegate);
                               CernerOCMockVerify(mockAlertViewUtils);
                               CernerOCMockVerify(mockDictionary);

                               return YES;
                           }]];

    [self.webView pageTimerExceeded];

    CernerOCMockVerify(mockWebView);

    [mockDictionary stopMocking];
    [mockAlertViewUtils stopMocking];
    [mockMainViewUtils stopMocking];
    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebView stopMocking];
}

- (void)testPageTimerExceeded_ErrorPage {
    NSString *urlString = @"http://test:port/environment/Main.aspx";

    self.webView.applicationURL = urlString;
    self.webView.lastURL        = urlString;

    OCMockObject *mockMainViewUtils  = [OCMockObject mockForClass:[MainViewUtils class]];
    OCMockObject *mockAlertViewUtils = [OCMockObject mockForClass:[AlertViewUtils class]];
    OCMockObject *mockDictionary     = [OCMockObject mockForClass:[NSMutableDictionary class]];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;

    [[[mockMainViewUtils expect] andReturnValue:@NO] isPageTimedOut:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@NO] containsServerError:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@YES] isErrorPage:OCMOCK_ANY];

    [[mockWebViewNavigationBarDelegate reject] adjustVisibilityOfAppMenuIcon:false];

    [[mockAlertViewUtils reject] alertWithErrorType:kErrorAlertType_PageTimeoutError andMessage:NULL];
    [[mockAlertViewUtils reject] alertButtonTitlesWithLogout:YES];

    [[mockDictionary reject] createWithServerError:NO cancelResponse:urlString andOkResponse:self.webView.lastURL];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[[mockWebView expect] andReturnValue:@YES] isLoading];

    [[mockWebView expect] evaluateJavaScript:kDocumentOuterHTML
                           completionHandler:[OCMArg checkWithBlock:^BOOL(void (^completionBlock)(id _Nullable result, NSError *_Nullable error)) {
                               completionBlock(nil, nil);
                               CernerOCMockVerify(mockMainViewUtils);
                               CernerOCMockVerify(mockWebViewNavigationBarDelegate);
                               CernerOCMockVerify(mockAlertViewUtils);
                               CernerOCMockVerify(mockDictionary);

                               return YES;
                           }]];

    [self.webView pageTimerExceeded];

    CernerOCMockVerify(mockWebView);

    [mockDictionary stopMocking];
    [mockAlertViewUtils stopMocking];
    [mockMainViewUtils stopMocking];
    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebView stopMocking];
}

- (void)testWebViewDidCommitNavigation {

    self.webView.userInteractionEnabled = YES;
    self.webView.pageTimeoutVal         = 45;
    self.webView.pageTimer              = nil;

    WKUserContentController *controller = self.webView.configuration.userContentController;
    OCMockObject *mockController        = [OCMockObject partialMockForObject:controller];
    [[mockController expect] addUserScript:OCMOCK_ANY];

    [self.webView webView:self.webView didCommitNavigation:nil];

    CernerOCMockVerify(mockController);

    XCTAssertNotNil(self.webView.pageTimer);
    XCTAssertFalse(self.webView.userInteractionEnabled);

    [mockController stopMocking];
}

- (void)testWebViewDidFinishNavigation_ContainsServerError {

    OCMockObject *mockMainViewUtils = [OCMockObject mockForClass:[MainViewUtils class]];
    [[[mockMainViewUtils expect] andReturnValue:@YES] containsServerError:OCMOCK_ANY];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:false];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[mockWebView expect] handleErrorPage:@"Server Error" url:OCMOCK_ANY];
    [[mockWebView expect] fixWebFormValidation];

    [[mockWebView expect] evaluateJavaScript:kDocumentOuterHTML
                           completionHandler:[OCMArg checkWithBlock:^BOOL(void (^completionBlock)(id _Nullable result, NSError *_Nullable error)) {
                               completionBlock(nil, nil);

                               CernerOCMockVerify(mockMainViewUtils);
                               CernerOCMockVerify(mockWebViewNavigationBarDelegate);
                               return YES;
                           }]];

    [self.webView webView:self.webView didFinishNavigation:nil];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
    [mockMainViewUtils stopMocking];
    [mockWebViewNavigationBarDelegate stopMocking];
}

- (void)testWebViewDidFinishNavigation_StartPage {

    OCMockObject *mockMainViewUtils = [OCMockObject mockForClass:[MainViewUtils class]];
    [[[mockMainViewUtils expect] andReturnValue:@NO] containsServerError:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@YES] isStartPage:OCMOCK_ANY];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:false];

    id mockWebViewMainViewDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewMainViewDelegate)];
    self.webView.webViewMainViewDelegate = mockWebViewMainViewDelegate;
    [[mockWebViewMainViewDelegate expect] updateUIForPage:OCMOCK_ANY withURL:OCMOCK_ANY];

    OCMockObject *mockUserDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockUserDefaults expect] andReturnValue:@5] setBridgeUserDefaultsBasedOnHTML:OCMOCK_ANY];

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] disableIdleTimer];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[mockWebView expect] setApplicationTimeoutForPage:OCMOCK_ANY];
    [[mockWebView expect] parseAlertDetailsBasedOnHTML:OCMOCK_ANY];
    [[mockWebView expect] fixWebFormValidation];
    [[mockWebView expect] evaluateJavaScript:kDocumentOuterHTML
                           completionHandler:[OCMArg checkWithBlock:^BOOL(void (^completionBlock)(id _Nullable result, NSError *_Nullable error)) {
                               completionBlock(nil, nil);

                               CernerOCMockVerify(mockMainViewUtils);
                               CernerOCMockVerify(mockUserDefaults);
                               CernerOCMockVerify(mockWebViewNavigationBarDelegate);
                               CernerOCMockVerify(mockWebViewMainViewDelegate);
                               CernerOCMockVerify(mockSharedApplication);
                               return YES;
                           }]];

    [self.webView webView:self.webView didFinishNavigation:nil];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
    [mockMainViewUtils stopMocking];
    [mockUserDefaults stopMocking];
    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebViewMainViewDelegate stopMocking];
    [mockSharedApplication stopMocking];
}

- (void)testWebViewDidFinishNavigation_OtherPages {

    OCMockObject *mockMainViewUtils = [OCMockObject mockForClass:[MainViewUtils class]];
    [[[mockMainViewUtils expect] andReturnValue:@NO] containsServerError:OCMOCK_ANY];
    [[[mockMainViewUtils expect] andReturnValue:@NO] isStartPage:OCMOCK_ANY];

    id mockWebViewNavigationBarDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewNavigationBarDelegate)];
    self.webView.webViewNavigationBarDelegate = mockWebViewNavigationBarDelegate;
    [[mockWebViewNavigationBarDelegate expect] adjustVisibilityOfAppMenuIcon:true];

    id mockWebViewMainViewDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewMainViewDelegate)];
    self.webView.webViewMainViewDelegate = mockWebViewMainViewDelegate;
    [[mockWebViewMainViewDelegate expect] updateUIForPage:OCMOCK_ANY withURL:OCMOCK_ANY];

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] enableIdleTimer];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[mockWebView expect] parseAlertDetailsBasedOnHTML:OCMOCK_ANY];
    [[mockWebView expect] fixWebFormValidation];
    [[mockWebView expect] evaluateJavaScript:kDocumentOuterHTML
                           completionHandler:[OCMArg checkWithBlock:^BOOL(void (^completionBlock)(id _Nullable result, NSError *_Nullable error)) {
                               completionBlock(nil, nil);

                               CernerOCMockVerify(mockMainViewUtils);
                               CernerOCMockVerify(mockWebViewNavigationBarDelegate);
                               CernerOCMockVerify(mockWebViewMainViewDelegate);
                               CernerOCMockVerify(mockSharedApplication);
                               return YES;
                           }]];

    [self.webView webView:self.webView didFinishNavigation:nil];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
    [mockMainViewUtils stopMocking];
    [mockWebViewNavigationBarDelegate stopMocking];
    [mockWebViewMainViewDelegate stopMocking];
    [mockSharedApplication stopMocking];
}

- (void)testWebViewDecidePolicyForNavigationActionDecisionHandler_NotAction {
    NSString *urlString                  = @"http://test:port/environment/Main.aspx";
    WKNavigationAction *navigationAction = [[WKNavigationAction alloc] init];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    id mockNavigationAction = [OCMockObject partialMockForObject:navigationAction];
    [[[mockNavigationAction expect] andReturn:request] request];

    [self.webView webView:self.webView
        decidePolicyForNavigationAction:navigationAction
                        decisionHandler:^(WKNavigationActionPolicy policy) {
                            XCTAssertEqual(policy, WKNavigationActionPolicyAllow);
                        }];

    CernerOCMockVerify(mockNavigationAction);
    [mockNavigationAction stopMocking];
}

- (void)testWebViewDecidePolicyForNavigationActionDecisionHandler_NotAlert {
    NSString *urlString = @"http://action/environment/Main.aspx";

    WKNavigationAction *navigationAction = [[WKNavigationAction alloc] init];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    id mockNavigationAction = [OCMockObject partialMockForObject:navigationAction];
    [[[mockNavigationAction expect] andReturn:request] request];

    [self.webView webView:self.webView
        decidePolicyForNavigationAction:navigationAction
                        decisionHandler:^(WKNavigationActionPolicy policy) {
                            XCTAssertEqual(policy, WKNavigationActionPolicyAllow);
                        }];

    CernerOCMockVerify(mockNavigationAction);
    [mockNavigationAction stopMocking];
}

- (void)testWebViewDecidePolicyForNavigationActionDecisionHandler_AlertButNoMessage {
    NSString *urlString = @"http://action/alert";

    WKNavigationAction *navigationAction = [[WKNavigationAction alloc] init];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    id mockNavigationAction = [OCMockObject partialMockForObject:navigationAction];
    [[[mockNavigationAction expect] andReturn:request] request];

    [self.webView webView:self.webView
        decidePolicyForNavigationAction:navigationAction
                        decisionHandler:^(WKNavigationActionPolicy policy) {
                            XCTAssertEqual(policy, WKNavigationActionPolicyAllow);
                        }];

    CernerOCMockVerify(mockNavigationAction);
    [mockNavigationAction stopMocking];
}

- (void)testWebViewDecidePolicyForNavigationActionDecisionHandler_AlertWithMessage {
    NSString *urlString = @"http://action/alert?message=TestMessage%3Cbr%3Ebtn:OK";

    WKNavigationAction *navigationAction = [[WKNavigationAction alloc] init];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    id mockNavigationAction = [OCMockObject partialMockForObject:navigationAction];
    [[[mockNavigationAction expect] andReturn:request] request];

    OCMockObject *mockDictionary = [OCMockObject mockForClass:[NSMutableDictionary class]];
    [[mockDictionary expect] createWithServerError:NO cancelResponse:@"" andOkResponse:@""];

    id mockWebViewMainViewDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewMainViewDelegate)];
    self.webView.webViewMainViewDelegate = mockWebViewMainViewDelegate;
    [[mockWebViewMainViewDelegate expect] presentAlertController:OCMOCK_ANY withActionTitles:OCMOCK_ANY andInfo:OCMOCK_ANY];

    [self.webView webView:self.webView
        decidePolicyForNavigationAction:navigationAction
                        decisionHandler:^(WKNavigationActionPolicy policy) {
                            XCTAssertEqual(policy, WKNavigationActionPolicyCancel);
                        }];

    CernerOCMockVerify(mockNavigationAction);
    CernerOCMockVerify(mockWebViewMainViewDelegate);
    CernerOCMockVerify(mockDictionary);

    [mockNavigationAction stopMocking];
    [mockWebViewMainViewDelegate stopMocking];
    [mockDictionary stopMocking];
}

- (void)testWebViewDecidePolicyForNavigationActionDecisionHandler_AlertWithMessageAndConfirm {
    NSString *urlString = @"http://action/confirm?message=http://host/enovrinment/page/page.aspx%3Cbr%3Edocument.getElementById(%27exitScriptId%27).innerHTML%20=%20%27%27%3Cbr%3EExit%20Start%20Transfusion%3Cbr%3Ebtn:OK%3Cbr%3Ebtn2:Cancel%3Cbr%3ESure?";

    WKNavigationAction *navigationAction = [[WKNavigationAction alloc] init];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    id mockNavigationAction = [OCMockObject partialMockForObject:navigationAction];
    [[[mockNavigationAction expect] andReturn:request] request];

    OCMockObject *mockDictionary = [OCMockObject mockForClass:[NSMutableDictionary class]];
    [[mockDictionary expect] createWithServerError:NO cancelResponse:@"document.getElementById('exitScriptId').innerHTML = ''" andOkResponse:@"http://host/enovrinment/page/page.aspx"];

    id mockWebViewMainViewDelegate       = [OCMockObject niceMockForProtocol:@protocol(WebViewMainViewDelegate)];
    self.webView.webViewMainViewDelegate = mockWebViewMainViewDelegate;
    [[mockWebViewMainViewDelegate expect] presentAlertController:OCMOCK_ANY withActionTitles:OCMOCK_ANY andInfo:OCMOCK_ANY];

    [self.webView webView:self.webView
        decidePolicyForNavigationAction:navigationAction
                        decisionHandler:^(WKNavigationActionPolicy policy) {
                            XCTAssertEqual(policy, WKNavigationActionPolicyCancel);
                        }];

    CernerOCMockVerify(mockNavigationAction);
    CernerOCMockVerify(mockWebViewMainViewDelegate);
    CernerOCMockVerify(mockDictionary);

    [mockNavigationAction stopMocking];
    [mockWebViewMainViewDelegate stopMocking];
    [mockDictionary stopMocking];
}

- (void)testWebViewDidFailNavigationWithError {
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[mockWebView expect] handleErrorPage:OCMOCK_ANY url:OCMOCK_ANY];

    NSError *error = [NSError errorWithDomain:@"domain" code:NSURLErrorCancelled userInfo:nil];
    [self.webView webView:self.webView didFailNavigation:nil withError:error];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testFixWebFormValidation {
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.webView];
    [[mockWebView expect] evaluateJavaScript:OCMOCK_ANY completionHandler:nil];

    CernerOCMockSafeExecute([self.webView fixWebFormValidation]);

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

@end
