//
//  BottomBar.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement.h"
#import "ScannerInitializer.h"
#import "WebActionResponderDelegate.h"
#import <UIKit/UIKit.h>

@interface BottomBar : UIView

/**
 * The delegate associated with the web action responder protocol.
 */
@property (nonatomic, weak) id<WebActionResponderDelegate> actionDelegate;

/**
 * Reference to the device driver delegate in case the scanner needs to connect/reconnect
 */
@property (nonatomic, weak) NSObject<ScannerInitializer> *scannerInitializer;

/**
 * Parses all the required bottom bar elements from the current HTML, with or without the scan buttoon elements.
 */
- (void)parseItemsWithScan:(BOOL)shouldScan fromHTML:(NSString *)HTML;

@end
