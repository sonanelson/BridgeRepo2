//
//  NSUserDefaults+BridgeAdditions.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "BridgeCommonConstants.h"
#import "NSUserDefaults+BridgeAdditions.h"

#import "HTMLParser+XPathHelper.h"
#import "NSString+Additions.h"

// User Default Keys
static NSString *const kDefaultsKey_EnableTransfusion = @"enableTransfusion";
static NSString *const kDefaultsKey_EnableSpecimen    = @"enableSpecimen";
static NSString *const kDefaultsKey_EnableMilk        = @"enableMilk";
static NSString *const kDefaultsKey_EnableDonorMilk   = @"enableDonorMilk";
static NSString *const kDefaultsKey_EnableBabyMatch   = @"enableBabyMatch";
static NSString *const kDefaultsKey_EnableMedAdmin    = @"enableMedAdmin";
static NSString *const kDefaultsKey_PageTimeout       = @"pageTimeout";
static NSString *const kDefaultsKey_LastSelectedApp   = @"lastSelectedApp";

// User Defaults Text
static NSString *const kSolutionKey_Transfusion = @"Trans";
static NSString *const kSolutionKey_Specimen    = @"Spec";
static NSString *const kSolutionKey_Milk        = @"Milk";
static NSString *const kSolutionKey_BabyMatch   = @"Baby";

// Integers
static NSInteger const kDefault_PageTimeout = 120;

@implementation NSUserDefaults (BridgeAdditions)

+ (NSArray *)arrayForBridgeApplicationKeys {
    return @[
        kDefaultsKey_EnableTransfusion,
        kDefaultsKey_EnableSpecimen,
        kDefaultsKey_EnableMilk,
        kDefaultsKey_EnableBabyMatch,
        kDefaultsKey_EnableDonorMilk,
        kDefaultsKey_EnableMedAdmin
    ];
}

+ (NSDictionary *)solutionNameForApplicationKeyDictionary {
    return @{kDefaultsKey_EnableTransfusion: kSolutionKey_Transfusion,
             kDefaultsKey_EnableSpecimen: kSolutionKey_Specimen,
             kDefaultsKey_EnableMilk: kSolutionKey_Milk,
             kDefaultsKey_EnableBabyMatch: kSolutionKey_BabyMatch,
             kDefaultsKey_EnableDonorMilk: kSolutionKey_Milk};
}

+ (NSInteger)getPageTimeoutFromUserDefaults {
    NSInteger pageTimeout = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultsKey_PageTimeout];
    // If the page timeout user defualt is not set, return the default value.
    if (pageTimeout <= 0) {
        return kDefault_PageTimeout;
    }
    return pageTimeout;
}

+ (BOOL)areWebServerDefaultsAlreadySet {
    NSString *webServerName = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebServerName];
    NSString *webSiteName   = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebSiteName];
    if (webServerName == nil || webServerName.length == 0 || webSiteName == nil || webSiteName.length == 0) {
        return NO;
    }
    return YES;
}

+ (BOOL)areUserDefaultsAlreadySet {
    for (NSString *applicationKey in [NSUserDefaults arrayForBridgeApplicationKeys]) {
        id enableDefault = [[NSUserDefaults standardUserDefaults] objectForKey:applicationKey];
        if (enableDefault == nil) {
            return NO;
        }
    }
    return YES;
}

+ (NSInteger)setAppCount {
    NSInteger appCount = 0;
    for (NSString *applicationKey in [NSUserDefaults arrayForBridgeApplicationKeys]) {
        BOOL enableDefault = [[NSUserDefaults standardUserDefaults] boolForKey:applicationKey];
        if (enableDefault) {
            appCount = appCount + 1;
        }
    }

    return appCount;
}

+ (NSInteger)setBridgeUserDefaultsBasedOnHTML:(NSString *)HTML {
    NSInteger appCount = 0;
    if ([NSUserDefaults areUserDefaultsAlreadySet] || [NSString isStringEmpty:HTML]) {
        appCount = [NSUserDefaults setAppCount];
        return appCount;
    }

    // If settings have not previously been set, set them based on the "availableSolutions" on the Login.aspx.
    HTMLElement *element = [HTMLParser getAvailableSolutionsFromHTML:HTML];
    if (element == nil) {
        id enableTrans = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_EnableTransfusion];
        if (enableTrans == nil) {
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kDefaultsKey_EnableTransfusion];
        }
        appCount = [NSUserDefaults setAppCount];
        return appCount;
    }

    NSString *solutionName = element.text;
    if ([NSString isStringEmpty:solutionName]) {
        appCount = [NSUserDefaults setAppCount];
        return appCount;
    }

    for (NSString *applicationKey in [NSUserDefaults arrayForBridgeApplicationKeys]) {
        // Set user defaults and app count based on that.
        BOOL didEnable = [NSUserDefaults enableUserDefaultsForSolution:solutionName withDefaultsKey:applicationKey];
        appCount       = didEnable ? appCount + 1 : appCount;
    }

    return appCount;
}

+ (BOOL)enableUserDefaultsForSolution:(NSString *)solution withDefaultsKey:(NSString *)key {
    id userDefault = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    if (userDefault != nil) {
        return NO;
    }

    // Check if the key is NULL, return NO if it is.
    NSString *solutionKey = [[NSUserDefaults solutionNameForApplicationKeyDictionary] objectForKey:key];
    if (solutionKey == nil) {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:key];
        return NO;
    }

    // Set the user defualts
    BOOL isSolutionAvailable = [solution rangeOfString:solutionKey options:NSCaseInsensitiveSearch].location != NSNotFound;
    [[NSUserDefaults standardUserDefaults] setBool:isSolutionAvailable forKey:key];
    return isSolutionAvailable;
}

+ (BOOL)checkIfDefaultIsEnabledForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] boolForKey:key];
}

+ (void)setSelectedApplicationIndex:(NSInteger)index {
    [[NSUserDefaults standardUserDefaults] setInteger:index forKey:kDefaultsKey_LastSelectedApp];
}

+ (NSInteger)getSelectedApplicationIndex {
    // Get the last application stored in the defaults.
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults stringForKey:kDefaultsKey_LastSelectedApp]) {
        return [[defaults stringForKey:kDefaultsKey_LastSelectedApp] intValue];
    }

    // If nothing is set, return index for Transfusion i.e the default Application.
    return 0;
}

+ (BOOL)getSettingsDictionary {
    //NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    //if mdm settings exists overrite the app settings
    NSDictionary *mdmDictionary = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kMDMConfigurationKey];
    if (mdmDictionary != nil && mdmDictionary.count > 0) {
        NSString *serverHost  = [mdmDictionary objectForKey:kDefaultsKey_WebServerName];
        NSString *serverPort  = [mdmDictionary objectForKey:kDefaultsKey_WebSiteName];
        NSInteger timeOut     = [[mdmDictionary objectForKey:kDefaultsKey_PageTimeout] integerValue];
        NSString *codeCorpKey = [mdmDictionary objectForKey:kDefaultsKey_CodeCorpKey];
        CernLogInfo(@"MDM is configured");
        if (![NSString isStringEmpty:serverHost]) {
            [[NSUserDefaults standardUserDefaults] setObject:[serverHost stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] forKey:kDefaultsKey_WebServerName];
        }
        if (![NSString isStringEmpty:serverPort]) {
            [[NSUserDefaults standardUserDefaults] setObject:[serverPort stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] forKey:kDefaultsKey_WebSiteName];
        }
        if (![NSString isStringEmpty:codeCorpKey]) {
            [[NSUserDefaults standardUserDefaults] setObject:[codeCorpKey stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] forKey:kDefaultsKey_CodeCorpKey];
        }

        [[NSUserDefaults standardUserDefaults] setInteger:timeOut forKey:kDefaultsKey_PageTimeout];

        CernLogInfo(@"Values are %@", [[[NSUserDefaults standardUserDefaults] dictionaryRepresentation] allValues]);
        CernLogInfo(@"Keys are %@", [[[NSUserDefaults standardUserDefaults] dictionaryRepresentation] allKeys]);
        return true;
    }
    return false;
}

@end
