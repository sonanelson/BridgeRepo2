//
//  NSString+Additions.m
//  CernerBridge
//
//  Created by Gore,Divya on 10/11/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "BridgeCommonConstants.h"
#import "NSString+Additions.h"

static NSString *const kAimCodePrefix = @"]F0";
static NSString *const kCodabarPrefix = @"ABCD";

@implementation NSString (Additions)

+ (BOOL)isStringEmpty:(NSString *)string {
    if ([string isKindOfClass:[NSNull class]] || string == nil ||
        [[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]) {
        return true;
    }
    return false;
}

+ (NSString *)getLoginURLForApplication:(NSString *)application withServer:(NSString *)server andSite:(NSString *)site {
    NSString *httpString;
    // In the production build, the URL should always be secure.
    httpString = @"http";
    return [NSString stringWithFormat:kFormat_URLLogin, httpString, server, site, [NSString isStringEmpty:application] ? kLoginPage_Default : application, [NSTimeZone localTimeZone].name];
}

- (NSInteger)getIndexOfText:(NSString *)text {
    NSRange range = [self rangeOfString:text];
    return (range.length > 0) ? range.location : -1;
}

- (BOOL)caseInsensitiveSearchForText:(NSString *)text {
    NSRange range = [self rangeOfString:text options:NSCaseInsensitiveSearch];
    return (range.location == NSNotFound) ? false : true;
}

- (NSString *)processAimCodesInBarcode {
    NSRange aimCodeRange = [self rangeOfString:kAimCodePrefix];
    if (aimCodeRange.location == NSNotFound) {
        return self;
    }

    NSString *aimCode           = [self substringWithRange:aimCodeRange];
    NSString *barcodeWithoutAIM = [self substringFromIndex:aimCodeRange.length];
    if (barcodeWithoutAIM.length <= 2) {
        return self;
    }

    unichar startChar            = [barcodeWithoutAIM characterAtIndex:0];
    NSCharacterSet *codabarCodes = [NSCharacterSet characterSetWithCharactersInString:kCodabarPrefix];
    if ([codabarCodes characterIsMember:startChar]) {
        NSString *startCharLower = [[barcodeWithoutAIM substringToIndex:1] lowercaseString];
        barcodeWithoutAIM        = [barcodeWithoutAIM substringFromIndex:1];
        barcodeWithoutAIM        = [startCharLower stringByAppendingString:barcodeWithoutAIM];
    }

    unichar endChar = [barcodeWithoutAIM characterAtIndex:barcodeWithoutAIM.length - 1];
    if ([codabarCodes characterIsMember:endChar]) {
        NSString *endCharLower = [[barcodeWithoutAIM substringFromIndex:barcodeWithoutAIM.length - 1] lowercaseString];
        barcodeWithoutAIM      = [barcodeWithoutAIM substringToIndex:barcodeWithoutAIM.length - 1];
        barcodeWithoutAIM      = [barcodeWithoutAIM stringByAppendingString:endCharLower];
    }
    return [aimCode stringByAppendingString:barcodeWithoutAIM];
}

@end
