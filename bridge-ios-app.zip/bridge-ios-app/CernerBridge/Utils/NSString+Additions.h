//
//  NSString+Additions.h
//  CernerBridge
//
//  Created by Gore,Divya on 10/11/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Additions)

/**
 * A method to verify is the current string is empty or nil.
 *
 * @return true if string is empty, nil or consists only of white spaces, else false.
 */
+ (BOOL)isStringEmpty:(NSString *)string;
/**
 * Get the login URL String with the given web server, site for the current application.
 *
 * @return the URL string containing the given web server and site and correct security protocol.
 */
+ (NSString *)getLoginURLForApplication:(NSString *)application withServer:(NSString *)server andSite:(NSString *)site;
/**
 * Method to get index of text in the current string.
 *
 * @return The index location of text in the current string.
 */
- (NSInteger)getIndexOfText:(NSString *)text;
/**
 * A method to search the given text in the current string case-insensitively..
 *
 * @return true if text is found, else false.
 */
- (BOOL)caseInsensitiveSearchForText:(NSString *)text;
/**
 * Processes the aimcodes in the given barcode.
 *
 * @return the barcode with aim codes processed, if the barcode contains any.
 */
- (NSString *)processAimCodesInBarcode;

@end
