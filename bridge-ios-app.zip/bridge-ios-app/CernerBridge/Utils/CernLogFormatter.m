//
//  CernLogFormatter.m
//  CernerBridge
//
//  Created by Cn,Prashanth on 30/04/1942 Saka.
//  Copyright © 1942 Cerner Corporation. All rights reserved.
//

#import "CernLogFormatter.h"
#import "CernLog.h"
#import <Foundation/Foundation.h>

@implementation CernLogFormatter

static NSDateFormatter *__messengerDateFormatter;

/**
 * @return Shared Date Formatter
 * @Note: We are not using Platform's formatter because this is used in the extensions
 *        And the extenions cannot use OrionAppKit things - causes things to not work, e.g. logging
 */
+ (NSDateFormatter *)messengerDateFormatter {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __messengerDateFormatter                   = [[NSDateFormatter alloc] init];
        __messengerDateFormatter.formatterBehavior = NSDateFormatterBehavior10_4;
        __messengerDateFormatter.dateFormat        = @"MM-dd-yyyy HH:mm:ss:SSS";
    });

    return __messengerDateFormatter;
}

#pragma mark DDLogFormatter Delegate Methods

/**
 Returns a formatted error message based on a given DDLogMessage generated from CocoaLumberjack
 @param logMessage - a message that was produced by a call to a CocoaLumberjack log method.
 */
- (NSString *)formatLogMessage:(DDLogMessage *)logMessage {
    NSString *logLevel;
    DDLogFlag messageFlag = logMessage.flag;

    if (messageFlag & DDLogFlagError) {
        logLevel = @"ERROR  ";
    } else if (messageFlag & DDLogFlagWarning) {
        logLevel = @"WARNING";
    } else if (messageFlag & DDLogFlagInfo) {
        logLevel = @"INFO   ";
    } else if (messageFlag & DDLogFlagDebug) {
        logLevel = @"DEBUG  ";
    } else if (messageFlag & DDLogFlagVerbose) {
        logLevel = @"VERBOSE";
    } else {
        logLevel = [NSString stringWithFormat:@"Unknown %lx", (unsigned long)logMessage.flag];
    }

    NSString *dateAndTime = [CernLogFormatter.messengerDateFormatter stringFromDate:logMessage.timestamp];
    NSString *logMsg      = logMessage.message;
    NSString *func        = logMessage.function;
    long threadID         = (long)logMessage.threadID;

    if (logMessage.context & CernLogContextClassLoc) {
        return [NSString stringWithFormat:@"%@ | %@ | %lx:[%@ %@] %@", dateAndTime, logLevel, threadID, NSStringFromClass(logMessage.tag), func, logMsg];
    } else {
        return [NSString stringWithFormat:@"%@ | %@ | %lx:%@ %@", dateAndTime, logLevel, threadID, func, logMsg];
    }
}

- (void)didAddToLogger:(id<DDLogger>)logger {
    atomic_fetch_add_explicit(&atomicLoggerCount, 1, memory_order_relaxed);
    atomic_int loggerCount = atomic_load_explicit(&atomicLoggerCount, memory_order_relaxed);

    if (loggerCount > 1) {
        NSException *exception =
            [NSException exceptionWithName:NSInvalidArgumentException
                                    reason:@"CernLogFormatter added to more than one logger. For thread safety, create a separate CernLogFormatter for each logger"
                                  userInfo:nil];
        @throw exception;
    }
}

- (void)willRemoveFromLogger:(id<DDLogger>)logger {
    atomic_fetch_sub_explicit(&atomicLoggerCount, 1, memory_order_relaxed);
}

@end
