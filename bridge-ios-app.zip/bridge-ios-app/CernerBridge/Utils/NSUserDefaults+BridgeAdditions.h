//
//  NSUserDefaults+BridgeAdditions.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (BridgeAdditions)

/**
 * Verify if the user defaults are already set.
 *
 * @return BOOL YES if already set, else NO.
 */
+ (BOOL)areWebServerDefaultsAlreadySet;
/**
 * Set all the required defaults, specified in the given HTML, assosciated with Bridge.
 *
 * @return NSInteger The number of defaults set.
 */
+ (NSInteger)setBridgeUserDefaultsBasedOnHTML:(NSString *)HTML;
/**
 * Get the set user default value for a page timeout or the default page timeout value.
 *
 * @return NSInteger The page timeout value.
 */
+ (NSInteger)getPageTimeoutFromUserDefaults;
/**
 * Array containing user default keys for all Bridge applications.
 *
 * @return NSArray with all Bridge Application default keys.
 */
+ (NSArray *)arrayForBridgeApplicationKeys;
/**
 * Sets the user default for the selected application.
 */
+ (void)setSelectedApplicationIndex:(NSInteger)index;
/**
 * Get the index of the selected application.
 *
 * @return NSInteger The index of the selected application.
 */
+ (NSInteger)getSelectedApplicationIndex;
/**
 * Verify if the user default is set for the given key.
 *
 * @return BOOL true if it is set, else false.
 */
+ (BOOL)checkIfDefaultIsEnabledForKey:(NSString *)key;

/**
 * Get the configuration values from the MDM console
 *
 * @return NSInteger The page timeout value.
 */
+ (BOOL)getSettingsDictionary;

@end
