//
//  HTMLParser+XPathHelper.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/8/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "BridgeCommonConstants.h"
#import "HTMLParser+XPathHelper.h"

// XPath Scripts
static NSString *const kXPathScript_Title                      = @"//title";
static NSString *const kXPathScript_CaseInsensitiveInputSearch = @"//input/@id[contains(translate(., '%@', '%@'), '%@')]";
static NSString *const kXPathScript_InputIDSearch              = @"//input[@id='%@']";
static NSString *const kXPathScript_InputContains              = @"//*[contains(@id, '%@')]";
static NSString *const kXPathScript_AlertError                 = @"//a[@class='errorText']/@href";

@implementation HTMLParser (XPathHelper)

+ (HTMLElement *)parseTitleFromHTML:(NSString *)HTML {
    HTMLParser *parser        = [[HTMLParser alloc] init];
    HTMLElement *titleElement = [parser elementsFromHTML:HTML withXPath:kXPathScript_Title].firstObject;
    return titleElement;
}

+ (HTMLElement *)getAutoLogoutTimeFromHTML:(NSString *)HTML {
    HTMLParser *parser   = [[HTMLParser alloc] init];
    HTMLElement *element = [parser searchInInputTagInHTML:HTML forID:kAutoLogTime];
    return element;
}

+ (HTMLElement *)getAvailableSolutionsFromHTML:(NSString *)HTML {
    HTMLParser *parser   = [[HTMLParser alloc] init];
    HTMLElement *element = [parser searchInInputTagInHTML:HTML forID:kAvailableSolutions];
    return element;
}

+ (NSArray<HTMLElement *> *)getErrorAlertInfoFromHTML:(NSString *)HTML {
    HTMLParser *parser               = [[HTMLParser alloc] init];
    NSArray<HTMLElement *> *elements = [parser elementsFromHTML:HTML withXPath:kXPathScript_AlertError];
    return elements;
}

+ (NSArray<HTMLElement *> *)getBottomBarElementsFromHTML:(NSString *)HTML {
    HTMLParser *parser = [[HTMLParser alloc] init];

    // If it is the main bar it should just contain combinations of the following 3 buttons:
    // Patients, Scan and Menu.
    NSArray<HTMLElement *> *elements = [parser getMainBottomBarElementsFromHTML:HTML];
    if (elements.count > 0) {
        return elements;
    }

    // If it is NOT the main bar it should just contain combinations of the following 3 buttons:
    // Cancel, Scan and Continue.
    return [parser getSecondaryBottomBarElementsFromHTML:HTML];
}

+ (NSArray<HTMLElement *> *)getLeftBarButtonNavigationBarElementsFromHTML:(NSString *)HTML {
    HTMLParser *parser                      = [[HTMLParser alloc] init];
    NSMutableArray<HTMLElement *> *elements = [NSMutableArray arrayWithCapacity:3];

    // Should contain Back Button
    HTMLElement *element = [parser searchInInputTagInHTML:HTML forID:kBackLink];
    if (element) {
        [elements addObject:element];
    }

    // Should contain Filter Button
    element = [parser searchInInputTagInHTML:HTML forID:kFilter];
    if (element) {
        [elements addObject:element];
    }

    // Should contain Home Button
    element = [parser searchInInputTagInHTML:HTML forID:kHomeLink];
    if (element) {
        [elements addObject:element];
    }
    return [NSArray arrayWithArray:elements];
}

+ (NSArray<HTMLElement *> *)getDropDownMenuElementsFromHTML:(NSString *)HTML {
    HTMLParser *parser = [[HTMLParser alloc] init];

    NSMutableArray<HTMLElement *> *elements = [NSMutableArray arrayWithCapacity:2];

    // Should show Help cell.
    HTMLElement *element = [parser searchHTML:HTML forID:kInfo];
    if (element) {
        [elements addObject:element];
    }

    // Should show Logout cell.
    element = [parser searchHTML:HTML forID:kLogoutLink];
    if (element) {
        [elements addObject:element];
    }

    return [NSArray arrayWithArray:elements];
}

- (NSArray<HTMLElement *> *)getMainBottomBarElementsFromHTML:(NSString *)HTML {
    // The main bar should contain combinations of the following 3 buttons:
    // Patients, Scan and Menu.
    NSMutableArray<HTMLElement *> *elements = [NSMutableArray arrayWithCapacity:3];

    // If both the patient and home elements are null, it means that the bottom bar is not the main bottom bar.
    // Just one of them can be null and it can still be a bottom bar.
    HTMLElement *patientsElement = [self searchInInputTagInHTML:HTML forID:kPatientsLink];
    HTMLElement *homeElement     = [self searchInInputTagInHTML:HTML forID:kHomeLink];
    if (patientsElement == NULL && homeElement == NULL) {
        return NULL;
    }

    // Does contain Patient Button
    if (patientsElement) {
        [elements addObject:patientsElement];
    }

    // Does contain Home Button
    if (homeElement) {
        [elements addObject:homeElement];
    }

    // Scan - This button should be present in both the main bar and the exit bar.
    HTMLElement *scanElement = [self searchInInputTagInHTML:HTML forID:kScan];
    if (scanElement) {
        [elements addObject:scanElement];
    }

    return [NSArray arrayWithArray:elements];
}

- (NSArray<HTMLElement *> *)getSecondaryBottomBarElementsFromHTML:(NSString *)HTML {

    // The secondary bar i.e. NOT the main bar, should just contain combinations of the following 3 buttons:
    // Cancel, Scan and Continue.

    NSMutableArray<HTMLElement *> *elements = [NSMutableArray arrayWithCapacity:3];

    // Scan - This button should be present in both the main bar and the exit bar.
    HTMLElement *element = [self searchInInputTagInHTML:HTML forID:kScan];
    if (element) {
        [elements addObject:element];
    }

    // Should contain Continue/ Yes/ Ok button
    element = [self getPositiveButtonTitleElementsFromHTML:HTML];
    if (element) {
        [elements addObject:element];
    }

    // Should contain Cancel/ No button
    element = [self getNegativeButtonTitleElementsFromHTML:HTML];
    if (element) {
        [elements addObject:element];
    }
    return [NSArray arrayWithArray:elements];
}

- (HTMLElement *)getPositiveButtonTitleElementsFromHTML:(NSString *)HTML {
    // Does contain Ok
    HTMLElement *element = [self searchInInputTagInHTML:HTML forID:kOk];
    if (element) {
        return element;
    }

    // Does contain Yes
    element = [self searchInInputTagInHTML:HTML forID:kYes];
    if (element) {
        return element;
    }

    // Does contain Continue
    element = [self searchInInputTagInHTML:HTML forID:kContinue];
    return element;
}

- (HTMLElement *)getNegativeButtonTitleElementsFromHTML:(NSString *)HTML {
    // Does contain Cancel
    HTMLElement *element = [self searchInInputTagInHTML:HTML forID:kCancel];
    if (element) {
        return element;
    }

    // Does contain No
    element = [self searchInInputTagInHTML:HTML forID:kNo];
    return element;
}

- (HTMLElement *)searchInInputTagInHTML:(NSString *)HTML forID:(NSString *)ID {
    NSString *uppercaseID = ID.uppercaseString;
    NSString *xPathString = [NSString stringWithFormat:kXPathScript_CaseInsensitiveInputSearch, uppercaseID, ID, ID];
    HTMLElement *element  = [self elementsFromHTML:HTML withXPath:xPathString].firstObject;
    if (element == nil) {
        return NULL;
    }
    xPathString = [NSString stringWithFormat:kXPathScript_InputIDSearch, element.text];
    return [self elementsFromHTML:HTML withXPath:xPathString].firstObject;
}

- (HTMLElement *)searchHTML:(NSString *)HTML forID:(NSString *)ID {
    NSString *xPathString = [NSString stringWithFormat:kXPathScript_InputContains, ID];
    HTMLElement *element  = [self elementsFromHTML:HTML withXPath:xPathString].firstObject;
    return element;
}

@end
