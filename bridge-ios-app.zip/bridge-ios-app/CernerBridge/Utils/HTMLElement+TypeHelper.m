//
//  HTMLElement+TypeHelper.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "BridgeCommonConstants.h"
#import "HTMLElement+TypeHelper.h"
#import "NSString+Additions.h"

@implementation HTMLElement (TypeHelper)

- (BOOL)isOfTypePatient {
    if ([self.elementID caseInsensitiveSearchForText:kPatientsLink]) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeCancel {
    if (([self.elementID caseInsensitiveSearchForText:kCancel]) || ([self.elementID caseInsensitiveSearchForText:kNo])) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeContinue {
    if (([self.elementID caseInsensitiveSearchForText:kContinue]) || ([self.elementID caseInsensitiveSearchForText:kOk]) || ([self.elementID caseInsensitiveSearchForText:kYes])) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeHome {
    if ([self.elementID caseInsensitiveSearchForText:kHomeLink]) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeLogout {
    if ([self.elementID caseInsensitiveSearchForText:kLogoutLink]) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeBack {
    if ([self.elementID caseInsensitiveSearchForText:kBackLink]) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeFilter {
    if ([self.elementID caseInsensitiveSearchForText:kFilter]) {
        return true;
    }
    return false;
}

- (BOOL)isOfTypeScan {
    if ([self.elementID caseInsensitiveSearchForText:kScan]) {
        return true;
    }
    return false;
}
@end
