//
//  MainViewUtils.h
//  CernerBridge
//
//  Created by Gore,Divya on 10/16/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainViewUtils : NSObject

/**
 * A method that gets the name of the current page.
 *
 * @return The current page name.
 */
+ (NSString *)getPageNameFromURL:(NSString *)URLString;
/**
 * A method to verify if the current pgae is the start page i.e login/ logout pages.
 *
 * @return true if a start page, else false.
 */
+ (BOOL)isStartPage:(NSString *)page;
/**
 * A method to verify of the current page has timed out.
 *
 * @return true if the page has timed out, else false.
 */
+ (BOOL)isPageTimedOut:(NSString *)page;
/**
 * A method to verify if the current page is an error page.
 *
 * @return true if an error page, else false.
 */
+ (BOOL)isErrorPage:(NSString *)page;
/**
 * A method to verify if the current page consists of a server error.
 *
 * @return true if page consists of a server error, else false.
 */
+ (BOOL)containsServerError:(NSString *)page;
/**
 * A method to verify if the current page is a password page.
 *
 * @return true if page consists is a password page, else false.
 */
+ (BOOL)isPasswordPage:(NSString *)pageURL;
/**
 * A method to verify if the current page contains a form tag and page name.
 *
 * @return true if page contains a form tag, else false.
 */
+ (BOOL)doesContainFormTag:(NSString *)HTML;
@end
