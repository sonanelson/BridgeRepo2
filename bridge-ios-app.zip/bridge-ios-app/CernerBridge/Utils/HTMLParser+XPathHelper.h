//
//  HTMLParser+XPathHelper.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/8/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLParser.h"

@interface HTMLParser (XPathHelper)

/**
 * Parses the page title from the given HTML.
 *
 * @return HTMLElement an element containing the title of the current page.
 */
+ (HTMLElement *)parseTitleFromHTML:(NSString *)HTML;
/**
 * Parses all the navigation bar elements from the given HTML.
 *
 * @return NSArray an array of all the navigation bar elements for the current page.
 */
+ (NSArray<HTMLElement *> *)getLeftBarButtonNavigationBarElementsFromHTML:(NSString *)HTML;
/**
 * Parses all the DropDownMenu elements from the given HTML.
 *
 * @return NSArray an array of all the DropDownMenu elements for the current page.
 */
+ (NSArray<HTMLElement *> *)getDropDownMenuElementsFromHTML:(NSString *)HTML;
/**
 * Parses all the BottomBar elements from the given HTML.
 *
 * @return NSArray an array of all the BottomBar elements for the current page.
 */
+ (NSArray<HTMLElement *> *)getBottomBarElementsFromHTML:(NSString *)HTML;
/**
 * Parses all the alert elements from the given HTML.
 *
 * @return NSArray an array of all the alert elements for the current page.
 */
+ (NSArray<HTMLElement *> *)getErrorAlertInfoFromHTML:(NSString *)HTML;
/**
 * Parses the logout time from the given HTML.
 *
 * @return HTMLElement an element containing the logout time.
 */
+ (HTMLElement *)getAutoLogoutTimeFromHTML:(NSString *)HTML;
/**
 * Parses the available solutions from the given HTML.
 *
 * @return HTMLElement an element containing the available solutions.
 */
+ (HTMLElement *)getAvailableSolutionsFromHTML:(NSString *)HTML;

@end
