//
//  UIViewController+TopmostPresentedViewController.h
//  CernerBridge
//
//  Created by Gore,Divya on 12/3/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (TopmostPresentedViewController)

/**
 * Returns the topmost viewcontroller for the given controller.
 *
 * @returns the topmost viewcontroller
 **/
+ (UIViewController *)topmostViewController;

@end
