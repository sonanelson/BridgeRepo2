//
//  NSMutableDictionary+AlertViewHelper.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/12/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement.h"
#import <Foundation/Foundation.h>

// Keys related to alert message, actions and responses
static NSString *const kKey_Alert_Message        = @"alert_message_key";
static NSString *const kKey_Alert_ButtonOK       = @"alert_okButton_title_key";
static NSString *const kKey_Alert_ButtonCancel   = @"alert_cancelButton_title_key";
static NSString *const kKey_Alert_ButtonTitle    = @"alert_buttonTitle_key";
static NSString *const kKey_Alert_Details        = @"alert_details_key";
static NSString *const kKey_Response_Cancel      = @"alert_cancelResponse_key";
static NSString *const kKey_Response_OK          = @"alert_OkResponse_key";
static NSString *const kKey_Response_ServerError = @"alert_ServerErrorResponse_key";

@interface NSMutableDictionary (AlertViewHelper)

/**
 * Gets the alert action titles from the given text. Appends existing message with the given message for a confirm or non-confirm alert.
 */
- (void)getAlertButtonTitlesFromText:(NSString *)text appendToMessage:(NSString *)message forConfirmAlert:(BOOL)isConfirm;
/**
 * Creates a new dictionary containing keys for the server error and responses (wherever valid).
 *
 * @return NSDictionary A new dictionary containing all the required info.
 */
+ (NSDictionary *)createWithServerError:(BOOL)isServerError cancelResponse:(NSString *)cancelResponse andOkResponse:(NSString *)okResponse;
/**
 * Extracts the alert details from the array of HTMLELements and repackages it with required details in the form of key-value pairs.
 *
 * @return NSDictionary A new dictionary containing all the required info.
 */
+ (NSDictionary *)extractAlertDetailsfromHTMLElements:(NSArray<HTMLElement *> *)elements;

@end
