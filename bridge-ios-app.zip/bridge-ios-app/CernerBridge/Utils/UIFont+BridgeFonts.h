//
//  UIFont+BridgeFonts.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (BridgeFonts)
/**
 * Returns font for the bottom bar.
 */
+ (UIFont *)bottomBarFont;
/**
 * Returns the font for the drop down menu.
 */
+ (UIFont *)defaultTitleFont;

@end
