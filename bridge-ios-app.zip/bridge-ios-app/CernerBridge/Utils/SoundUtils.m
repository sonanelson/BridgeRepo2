//
//  SoundUtils.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/21/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "SoundUtils.h"
#import <AudioToolbox/AudioToolbox.h>

static NSInteger const kSystemSoundID = 1106;

@implementation SoundUtils

+ (void)playDefaultAlertSound {
    AudioServicesPlayAlertSound(kSystemSoundID);
}

@end
