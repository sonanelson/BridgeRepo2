//
//  UIColor+BridgeColors.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIColor+BridgeColors.h"

@implementation UIColor (BridgeColors)

+ (UIColor *)defaultTextColor {
    return [UIColor colorWithRed:0.047 green:0.522 blue:0.741 alpha:1.0];
}

+ (UIColor *)inactiveTextColor {
    return [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1.0];
}

+ (UIColor *)bottomBarColor {
    return [UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.0f];
}

@end
