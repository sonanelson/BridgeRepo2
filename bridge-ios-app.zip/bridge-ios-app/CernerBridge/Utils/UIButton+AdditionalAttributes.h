//
//  UIButton+AdditionalAttributes.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (AdditionalAttributes)

/**
 * Method to get the title color for the buttons on the Main Bottom bar ie. bottom bar with Patients and Menu buttons.
 */
- (UIColor *)titleColorForMainBottomBar;
/**
 * Method to get the title color for the buttons on the Secondary Bottom bar ie. bottom bar with Cancel and Continue buttons.
 */
- (UIColor *)titleColorForSecondaryBottomBar:(BOOL)isCancelButton;
/**
 * Method to set the insets to center the image and title in the button with the image on top.
 */
- (void)centerContentWithImageOnTopOfSize:(CGSize)imageSize title:(NSString *)title andFont:(UIFont *)font;

@end
