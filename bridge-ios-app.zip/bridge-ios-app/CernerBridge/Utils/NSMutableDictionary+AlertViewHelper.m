//
//  NSMutableDictionary+AlertViewHelper.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/12/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSString+Additions.h"

// Constants
static NSString *const kButton_One   = @"btn:";
static NSString *const kButton_Two   = @"btn2:";
static NSString *const kAction_Click = @".click();";

@implementation NSMutableDictionary (AlertViewHelper)

- (void)getAlertButtonTitlesFromText:(NSString *)text appendToMessage:(NSString *)message forConfirmAlert:(BOOL)isConfirm {
    // The secondButton will only be present for confirm alerts in the form of OK and Cancel buttons.
    // If it is not a confirm alert, it will just have one button: OK or Cancel.
    NSInteger firstButtonIndex  = [text getIndexOfText:kButton_One];
    NSInteger secondButtonIndex = isConfirm ? [text getIndexOfText:kButton_Two] : -1;

    if (firstButtonIndex < 0 && secondButtonIndex < 0) {
        message = [message stringByAppendingString:[NSString stringWithFormat:@"\n%@", text]];
        [self setObject:message forKey:kKey_Alert_Message];
    }

    // Set Ok button text (Format:: btn:<buttonTitle>)
    NSInteger titleIndex = firstButtonIndex >= 0 ? firstButtonIndex + 4 : -1;
    [self extractButtonTitleForKey:kKey_Alert_ButtonOK fromText:text withStartIndex:titleIndex];

    // If it is not a confirm alert, we don't need to add the cancel button.
    if (isConfirm) {
        // Set Cancel Button Text (Format:: btn2:<buttonTitle>)
        titleIndex = secondButtonIndex >= 0 ? secondButtonIndex + 5 : -1;
        [self extractButtonTitleForKey:kKey_Alert_ButtonCancel fromText:text withStartIndex:titleIndex];
    }
}

- (void)extractButtonTitleForKey:(NSString *)key fromText:(NSString *)text withStartIndex:(NSInteger)index {
    // If the index is not valid or out of range, do not set the object for the given key.
    if (index >= 0 && (index < text.length)) {
        [self setObject:[text substringFromIndex:index] forKey:key];
    }
}

+ (NSDictionary *)extractAlertDetailsfromHTMLElements:(NSArray<HTMLElement *> *)elements {
    // The alert can be a normal alert or a confirm alert.
    // Separate the alert components based on that.
    // If the componenets contain more that one element, if is a confirm alert in the form of <actionURL>;<alert>.
    // If the components just contains one element, it is a normal javascript alert.
    NSArray *alertComponents = [elements.firstObject.text componentsSeparatedByString:kAction_Click];
    if (alertComponents.count == 0) {
        return @{};
    }

    NSString *body = [alertComponents lastObject];
    if (alertComponents.count == 1) {
        // javascript:alert(\"Title<br>btn:buttonTitle<br>message\");
        NSCharacterSet *urlCharacterSet = [NSCharacterSet characterSetWithCharactersInString:@"\"\""];
        body                            = [[elements.firstObject.text componentsSeparatedByCharactersInSet:urlCharacterSet] objectAtIndex:1];
    }

    NSMutableArray *buttonTitles = [NSMutableArray arrayWithCapacity:2];
    NSArray *details             = [body componentsSeparatedByString:@"<br>"];
    NSInteger titleIndex         = -1;
    NSString *title              = @"";
    NSString *message            = @"";

    for (int i = 0; i < details.count; i++) {
        NSString *detail = details[i];

        // If the alert detail is emoty, dont do anything.
        if ([NSString isStringEmpty:detail]) {
            continue;
        }

        // Extract the button for the alert. This button will always be present.
        NSInteger firstButtonIndex = [detail getIndexOfText:kButton_One];
        if (firstButtonIndex != -1) {
            [buttonTitles addObject:[detail substringFromIndex:[detail getIndexOfText:@":"] + 1]];

            // In both alerts, the title will be before the first button.
            titleIndex = i;
            continue;
        }

        // Extract the button for the alert. This button will be present sometimes.
        NSInteger secondButtonIndex = [detail getIndexOfText:kButton_Two];
        if (secondButtonIndex != -1) {
            [buttonTitles addObject:[detail substringFromIndex:[detail getIndexOfText:@":"] + 1]];
            continue;
        }

        // Append to the title till the first button text is encountered.
        if (titleIndex == -1) {
            title = [title stringByAppendingString:detail];
            continue;
        }

        // Append to the message till all details are covered.
        message = [message stringByAppendingString:detail];
    }

    return @{kKey_Alert_Details: @[title, message], kKey_Alert_ButtonTitle: buttonTitles};
}

+ (NSDictionary *)createWithServerError:(BOOL)isServerError cancelResponse:(NSString *)cancelResponse andOkResponse:(NSString *)okResponse {
    NSMutableDictionary *dictionary = [NSMutableDictionary dictionaryWithCapacity:3];
    // Add key for server error.
    [dictionary setObject:[NSNumber numberWithBool:isServerError] forKey:kKey_Response_ServerError];

    // If it is a server error, we dont need to add any responses.
    if (isServerError) {
        return dictionary;
    }

    // Add cancel response, if present.
    if (![NSString isStringEmpty:cancelResponse]) {
        [dictionary setObject:cancelResponse forKey:kKey_Response_Cancel];
    }

    // Add ok response, if present.
    if (![NSString isStringEmpty:okResponse]) {
        [dictionary setObject:okResponse forKey:kKey_Response_OK];
    }

    return [NSDictionary dictionaryWithDictionary:dictionary];
}

@end
