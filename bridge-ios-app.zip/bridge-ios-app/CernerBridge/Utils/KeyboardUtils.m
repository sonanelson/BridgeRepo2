//
//  KeyboardUtils.m
//  CernerBridge
//
//  Created by Gore,Divya on 1/31/19.
//  Copyright © 2019 Cerner Corporation. All rights reserved.
//

#import "KeyboardUtils.h"

static NSString *const kPrefix_InputContainerView   = @"<UIInputSetContainerView";
static NSString *const kPrefix_InputBackgroundView  = @"<UIKBInputBackdropView";
static NSString *const kPrefix_WebFormAccessoryView = @"<UIWebFormAccessory";

@implementation KeyboardUtils

+ (UIWindow *)getKeyboardAccessoryWindow {
    UIWindow *keyboardWindow = nil;
    // Get the keyboard accessory window.
    // Here, we need the accessory window and not the actual main window.
    NSArray *applicationWindows = [[UIApplication sharedApplication] windows];
    for (UIWindow *window in applicationWindows) {
        if (![[window class] isEqual:[UIWindow class]]) {
            keyboardWindow = window;
            break;
        }
    }
    return keyboardWindow;
}

+ (BOOL)isInputContainerViewPresentInView:(UIView *)view {
    return [[view description] hasPrefix:kPrefix_InputContainerView];
}

+ (void)hideKeyboardAccessoryViewInViews:(NSArray *)views {
    for (UIView *accessoryView in views) {
        for (UIView *accessorySubView in accessoryView.subviews) {

            // hides the backdrop and the accessory bar
            if (([[accessorySubView description] hasPrefix:kPrefix_InputBackgroundView] && accessorySubView.frame.size.height == 44) || ([[accessorySubView description] hasPrefix:kPrefix_WebFormAccessoryView])) {
                [accessorySubView setHidden:YES];
            }
        }
    }
}

+ (BOOL)doesViewContainSubviews:(UIView *)view {
    return view.subviews.count > 0;
}

+ (void)hideWebInputAccessoryForKeyboard {
    // Get the keyboard window.
    UIWindow *keyboardWindow = [KeyboardUtils getKeyboardAccessoryWindow];

    // Locate UIWebFormView.
    for (UIView *webFormView in [keyboardWindow subviews]) {

        // Verify if the input accessory view is actually present and verify that the form has subviews.
        if ([KeyboardUtils isInputContainerViewPresentInView:webFormView] &&
            [KeyboardUtils doesViewContainSubviews:webFormView]) {
            [KeyboardUtils hideKeyboardAccessoryViewInViews:webFormView.subviews];
        }
    }
}

@end
