//
//  CernLogFormatter.h
//  CernerBridge
//
//  Created by Cn,Prashanth on 30/04/1942 Saka.
//  Copyright © 1942 Cerner Corporation. All rights reserved.
//

#ifndef CernLogFormatter_h
#define CernLogFormatter_h

#endif /* CernLogFormatter_h */
#import <CocoaLumberjack/CocoaLumberjack.h>
#import <stdatomic.h>

@interface CernLogFormatter : NSObject <DDLogFormatter> {
    /**
     The number of Loggers that this Formatter has been added to
     */
    atomic_int atomicLoggerCount;
}

@end
