//
//  AppDelegate.m
//  TabView
//
//  Created by Bechtold,Brian on 10/15/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "AppDelegate.h"
// Frameworks

#import <CernScanningLibrary/CernBarcode.h>
#import <CocoaLumberjack/DDFileLogger.h>
#import <NewRelic/NewRelic.h>
// Controllers
#import "MainNavigationViewController.h"
#import "MainViewController.h"
// Helpers and Views
#import "BridgeCommonConstants.h"
#import "CernLogFormatter.h"
#import "InactivityApplication.h"
#import <ConnectCareTeam/CernLog.h>

@interface AppDelegate ()
/**
 * File logger that outputs log statements.
 */
@property (nonatomic, strong) DDFileLogger *fileLogger;
/**
 * An instance of the MainViewController.
 */
@property (strong, nonatomic) MainViewController *mainViewController;
@end

static NSTimeInterval const LOG_ROLL_FREQUENCY    = 86400; // 24 hours in seconds.
static NSUInteger const MAX_LOG_FILES             = 25;
static const unsigned long long MAX_LOG_FILE_SIZE = 5242880; // 5Mb in bytes.

@implementation AppDelegate

#pragma mark - Initialization

- (instancetype)init {
    if ((self = [super init])) {
        NSString *logsDirectory                            = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject] stringByAppendingPathComponent:@"Logs"];
        _fileLogger                                        = [[DDFileLogger alloc] initWithLogFileManager:[[DDLogFileManagerDefault alloc] initWithLogsDirectory:logsDirectory]];
        _fileLogger.rollingFrequency                       = LOG_ROLL_FREQUENCY;
        _fileLogger.logFileManager.maximumNumberOfLogFiles = MAX_LOG_FILES;
        _fileLogger.maximumFileSize                        = MAX_LOG_FILE_SIZE;
        [_fileLogger setLogFormatter:[CernLogFormatter new]];
        [DDLog addLogger:_fileLogger];
    }
    return self;
}

- (void)registerNewRelic {
    [NewRelic enableFeatures:NRFeatureFlag_NetworkRequestEvents];
    [NewRelic enableFeatures:NRFeatureFlag_CrashReporting];
    [NewRelicAgent startWithApplicationToken:[[NSBundle mainBundle] objectForInfoDictionaryKey:NEW_RELIC_TOKEN_KEY]];
}

#pragma mark - Application Lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
#if !(TARGET_IPHONE_SIMULATOR)
    [self registerNewRelic];
#endif

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationDidTimeout:)
                                                 name:kNotification_ApplicationDidTimeout
                                               object:nil];

    // Set the root view controller and main window.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    MainNavigationViewController *navigationController = [MainViewController createContainingNavigationController];

    self.mainViewController = (MainViewController *)[navigationController topViewController];

    self.window.rootViewController = navigationController;

    [self.window makeKeyAndVisible];

    return YES;
}

#pragma mark - Notification Listeners

- (void)applicationDidTimeout:(NSNotification *)notif {
    [self.mainViewController autoLogout];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    if ([application applicationState] == UIApplicationStateActive) {
        [self.mainViewController reloadURLFromDefaults];
    }
}

@end
