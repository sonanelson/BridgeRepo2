//
//  MainViewController.m
//  TabView
//
//  Created by Bechtold,Brian on 10/15/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "MainViewController.h"
#import "InactivityApplication.h"
#import "WebServerSiteViewController.h"
// Utils
#import "BridgeCommonConstants.h"
#import "HTMLElement.h"
#import "HTMLParser.h"
#import "InactivityApplication.h"
#include <WebKit/WebKit.h>
// Views
#import "BottomBar.h"
#import "DropDownMenu.h"
#import "MainNavigationBar.h"
#import "MainWebView.h"
// Delegates
#import "WebViewMainViewDelegate.h"
// Helpers
#import "AlertViewUtils.h"
#import "HTMLParser+XPathHelper.h"
#import "MainViewUtils.h"
#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSString+Additions.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "ScannerInitializer.h"
#import "UIApplication+TypeAdditions.h"
#import "UIViewController+TopmostPresentedViewController.h"
// Scanner
#import <CernScanningLibrary/CEABarcodeScannerConfig.h>
#import <CernScanningLibrary/CEABarcodeScannerDelegate.h>
#import <CernScanningLibrary/CEACodeCorpDriver.h>
#import <CernScanningLibrary/CEADeviceDriverDelegate.h>
#import <CernScanningLibrary/CEADeviceDriverErrors.h>
#import <CernScanningLibrary/CEAScannerFactory.h>
#import <CernScanningLibrary/CernBarcode.h>

static NSString *const kBarcode        = @"barcode=";
static NSString *const kCodeCorpKeyKey = @"CodeCorpActivationKey";

@interface MainViewController () <MainMenuControllerDelegate,
                                  WebServerSiteViewControllerDelegate,
                                  WebActionResponderDelegate,
                                  WebViewMainViewDelegate,
                                  ScannerInitializer,
                                  CEADeviceDriverDelegate,
                                  CEABarcodeScannerDelegate,
                                  CEAScannerViewPresenter>
/**
 * IBOutlet for the bottom tool bar.
 **/
@property (nonatomic, strong) IBOutlet BottomBar *bottomBar;
/**
 * IBOutlet for the drop down menu table.
 **/
@property (nonatomic, strong) IBOutlet DropDownMenu *dropDownMenu;
/**
 * A variable to access the Navigation Bar from the Navigation Controller.
 */
@property (nonatomic, strong) MainNavigationBar *navigationBar;
/**
 * IBOutlet for the web view.
 **/
@property (nonatomic, strong) IBOutlet MainWebView *webView;
/**
 * Array containing an instance of all the queued up alerts.
 */
@property (nonatomic, strong) NSMutableArray *queuedAlerts;

/**
 * Used to hold on to a strong reference to the scanner
 */
@property (nonatomic, strong) id<CEABarcodeScanner> barcodeScanner;

@end

// The height for the UIWebFormAccessory is always constant at 44.0f (for all phone sizes).
static CGFloat const kWebInputFormAccessoryHeight = 44.0f;
static NSString *const kDefaultsKey_PageTimeout   = @"pageTimeout";

@implementation MainViewController

#pragma mark - Storyboard Methods

+ (MainNavigationViewController *)createContainingNavigationController {
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MainNavigationViewController *navigationController =
        (MainNavigationViewController *)[mainStoryBoard instantiateViewControllerWithIdentifier:@"MainNavigationViewController"];
    return navigationController;
}

+ (instancetype)createMainViewController {
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    return [mainStoryBoard instantiateViewControllerWithIdentifier:@"MainViewController"];
}

#pragma mark - Keyboard notifications

- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    // Get all required information from notification.
    NSDictionary *notificationInfo    = notification.userInfo;
    CGFloat duration                  = [notificationInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGRect keyboardEnd                = [notificationInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    UIViewAnimationCurve keyAnimation = [notificationInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];

    // Adjust frames
    UIStatusBarManager *statusBarManager = [[[UIApplication sharedApplication] delegate] window].windowScene.statusBarManager;
    CGFloat statusBarHt                  = statusBarManager.statusBarFrame.size.height;
    CGRect convertedEnd                  = [self.webView convertRect:keyboardEnd fromView:nil];
    CGRect bottomBarframe                = self.bottomBar.frame;

    if (self.view.bounds.size.height - convertedEnd.origin.y == 0) {
        // keyboard is hidden.
        bottomBarframe.origin.y = self.view.bounds.size.height - bottomBarframe.size.height;
    } else {
        // keyboard is up.
        CGFloat yOrigin         = keyboardEnd.origin.y - kWebInputFormAccessoryHeight;
        bottomBarframe.origin.y = yOrigin - bottomBarframe.size.height - statusBarHt;
    }

    // Animate with UIAnimation option, otherwise,
    // there is a delay in the bottombar animations and the keyboard resigning.
    __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:duration
                          delay:0.0
                        options:keyAnimation << 16 // convert the UIViewAnimationCurve to UIAnimation option
                     animations:^{
                         weakSelf.bottomBar.frame = bottomBarframe;
                     }
                     completion:nil];
}

#pragma mark - Lifecycle Methods

- (void)viewDidLoad {
    [super viewDidLoad];

    self.queuedAlerts = [NSMutableArray arrayWithCapacity:2];
    // Notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:NULL];

    // Initialize views.
    [self setUpNavigationBar];
    [self setUpWebView];

    self.bottomBar.actionDelegate     = self;
    self.bottomBar.scannerInitializer = self;
    self.dropDownMenu.actionDelegate  = self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    if (self.dropDownMenu.actionDelegate == nil) {
        self.dropDownMenu.actionDelegate = self;
    }

    if (self.bottomBar.actionDelegate == nil) {
        self.bottomBar.actionDelegate = self;
    }

    [self setUpNavigationBar];
    [self setUpWebView];

    //ONly use during development...
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    [[NSURLCache sharedURLCache] setDiskCapacity:0];
    [[NSURLCache sharedURLCache] setMemoryCapacity:0];
}

- (void)setupScanning {
    // If there is already a scanner there is nothing to do
    if ([[CEAScannerFactory getSharedInstance] getInstalledBarcodeScanner] != nil) {
        return;
    }
    NSString *activationKey = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_CodeCorpKey];
    if (activationKey == nil || activationKey.length == 0) {
        activationKey = [[NSBundle mainBundle] objectForInfoDictionaryKey:kCodeCorpKeyKey];
    }

    [CEACodeCorpDriver setActivationKey:activationKey];

    CEABarcodeScannerConfig *scannerConfig = [CEABarcodeScannerConfig makeWithBuilder:^(CEABarcodeScannerConfigBuilder *builder) {
        builder.scannerMode    = CEAScannerModeTarget;
        builder.continuousMode = NO;
        builder.fullScreen     = YES;
        builder.cameraType     = CEACameraBackFacking;
    }];

    Class<CEABarcodeScanner> barcodeScannerClass = [[CEAScannerFactory getSharedInstance] getBarcodeScannerDriver];
    // assign this so there is a strong reference while scanner activates
    self.barcodeScanner = [barcodeScannerClass connectWithConfiguration:scannerConfig withDriverDelegate:self];
}

- (void)reLoadScanning {
    NSString *activationKey = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_CodeCorpKey];
    if (activationKey == nil || activationKey.length == 0) {
        activationKey = [[NSBundle mainBundle] objectForInfoDictionaryKey:kCodeCorpKeyKey];
    }

    [CEACodeCorpDriver setActivationKey:activationKey];

    CEABarcodeScannerConfig *scannerConfig = [CEABarcodeScannerConfig makeWithBuilder:^(CEABarcodeScannerConfigBuilder *builder) {
        builder.scannerMode    = CEAScannerModeTarget;
        builder.continuousMode = NO;
        builder.fullScreen     = YES;
        builder.cameraType     = CEACameraBackFacking;
    }];

    Class<CEABarcodeScanner> barcodeScannerClass = [[CEAScannerFactory getSharedInstance] getBarcodeScannerDriver];
    // assign this so there is a strong reference while scanner activates
    self.barcodeScanner = [barcodeScannerClass connectWithConfiguration:scannerConfig withDriverDelegate:self];
}

#pragma mark - Initialization Methods

- (void)setUpNavigationBar {
    // If the navigationBar is already set, no need to initialize again.
    if (self.navigationBar != NULL) {
        return;
    }
    self.navigationBar                      = (MainNavigationBar *)self.navigationController.navigationBar;
    self.navigationBar.actionDelegate       = self;
    self.navigationBar.dropDownMenuDelegate = self.dropDownMenu;
}

- (void)setUpWebView {
    // If the delegates are already set, no need to initialize again.
    if (self.webView.navigationDelegate != NULL && self.webView.webViewMainViewDelegate != NULL && self.webView.webViewNavigationBarDelegate != NULL) {
        return;
    }

    [self.webView initialize];
    self.webView.webViewMainViewDelegate      = self;
    self.webView.webViewNavigationBarDelegate = self.navigationBar;

    // If the web server settings are not set, display the web server setting page first.
    if (![self.webView checkWebSettingsExist]) {
        return;
    }
    [self.webView loadURL:[NSURL URLWithString:self.applicationURL] shouldSetLastURL:YES];
}

- (void)loadWebViewWhenViewIsActive {
    // If the web server settings are not set, display the web server setting page first.
    if (![self.webView checkWebSettingsExist]) {
        return;
    }
    NSString *oldLicValue = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_CodeCorpKey];
    if ([NSUserDefaults getSettingsDictionary]) {
        NSString *newLicValue = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_CodeCorpKey];
        if (![oldLicValue isEqualToString:newLicValue]) {
            [self reLoadScanning];
        }
        [self.webView loadURL:[NSURL URLWithString:self.applicationURL] shouldSetLastURL:YES];
    }
}

#pragma mark - WebServerSiteViewControllerDelegate Methods

- (void)loadLoginPageBasedOnWebSettings {
    [self.webView loadURL:[NSURL URLWithString:self.applicationURL] shouldSetLastURL:YES];
}

#pragma mark - General Methods

- (NSString *)applicationURL {
    // If the web settings are not set, do nothing.
    if (![self.webView checkWebSettingsExist]) {
        return @"";
    }

    // The login page name for Transfusion, Specimen, Milk and MedAdmin are the same.
    NSString *loginPage        = kLoginPage_Default;
    NSInteger selectedAppIndex = [NSUserDefaults getSelectedApplicationIndex];
    if (selectedAppIndex == BABYMATCH) {
        loginPage = kLoginPage_BabyMatch;
    } else if (selectedAppIndex == DONORMILK) {
        loginPage = kLoginPage_DonorMilk;
    }

    // Get the login URL for the selected applicaton.
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *URL            = [NSString getLoginURLForApplication:loginPage
                                             withServer:[defaults objectForKey:kDefaultsKey_WebServerName]
                                                andSite:[defaults objectForKey:kDefaultsKey_WebSiteName]];

    self.webView.applicationURL = URL;
    return URL;
}

- (NSString *)autoLogoutURL {
    NSInteger selectedAppIndex = [NSUserDefaults getSelectedApplicationIndex];
    BOOL isMedAdmin            = (selectedAppIndex == MEDADMIN);
    NSString *loginPage        = isMedAdmin ? kLoginPage_MedAdmin : kLoginPage_Default;
    NSString *logoutPage       = isMedAdmin ? kLogoutPage_MedAdmin : kLogoutPage_Default;
    NSString *url              = self.webView.applicationURL;

    // Get the login page for the current application.
    NSRange loginRange = [url rangeOfString:loginPage options:NSCaseInsensitiveSearch];
    if (loginRange.location == NSNotFound) {
        return url;
    }

    // Replace the login page with the logout page.
    loginPage = [url substringWithRange:loginRange];
    return [url stringByReplacingOccurrencesOfString:loginPage withString:logoutPage];
}

- (void)showInvalidBarcodeScanAlert {
    UIAlertController *alertController = [AlertViewUtils alertWithErrorType:kErrorAlertType_InvalidBarcode andMessage:NULL];
    [self presentAlertController:alertController withActionTitles:[AlertViewUtils defaultAlertButtonTitlesWithCancel:NO] andInfo:nil];
}

- (void)processBarcode:(CernBarcode *)barcode {
    NSString *barcodeString = barcode.barcodeString;

    // Get the selected Application
    NSInteger selectedAppIndex = [NSUserDefaults getSelectedApplicationIndex];
    if (selectedAppIndex == MEDADMIN) {
        [self performActionBasedOnJavascript:[NSString stringWithFormat:
                                                           @"document.all._bcText.value = \"%@\"; document.all.ScanButton.click();", barcodeString]];
        return;
    }

    NSMutableCharacterSet *set = [NSMutableCharacterSet characterSetWithCharactersInString:@"!*'();:@&=+$,/?%#[]<>"];
    // Adding whitespace character set for correct 2D barcode processing
    [set formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
    barcodeString = [barcodeString stringByAddingPercentEncodingWithAllowedCharacters:[set invertedSet]];

    // Verify if any parameters are present in the current URL.
    NSString *currentURL = self.webView.URL.absoluteString;
    NSRange paramRange   = [currentURL rangeOfString:@"?"];
    if (paramRange.location == NSNotFound) {
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?%@%@", currentURL, kBarcode, barcodeString]];
        (url == NULL) ? [self showInvalidBarcodeScanAlert] : [self.webView loadURL:url shouldSetLastURL:FALSE];
        return;
    }

    // Verify if the parameters in the currnt URL contain any barcode parameter.
    NSString *params     = [currentURL substringFromIndex:NSMaxRange(paramRange)];
    NSRange barcodeRange = [params rangeOfString:kBarcode];
    if (barcodeRange.location == NSNotFound) {
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@&%@%@", currentURL, kBarcode, barcodeString]];
        (url == NULL) ? [self showInvalidBarcodeScanAlert] : [self.webView loadURL:url shouldSetLastURL:FALSE];
        return;
    }

    NSString *barcodeParam        = [params substringFromIndex:NSMaxRange(barcodeRange)];
    NSRange barcodeNextParamRange = [barcodeParam rangeOfString:@"&"];
    if (barcodeNextParamRange.location != NSNotFound) {
        barcodeParam = [barcodeParam substringToIndex:NSMaxRange(barcodeNextParamRange)];
    }
    currentURL = [currentURL stringByReplacingOccurrencesOfString:barcodeParam withString:barcodeString];
    [self.webView loadURL:[NSURL URLWithString:currentURL] shouldSetLastURL:FALSE];
}

- (void)autoLogout {
    [[UIApplication inactivityApplication] disableIdleTimer];
    [self.webView loadURL:[NSURL URLWithString:self.autoLogoutURL] shouldSetLastURL:YES];
}

- (void)reloadURLFromDefaults {
    // Verify if the current URL is login page, only then we will reload the URL from defaults
    NSString *currentURL = self.webView.URL.absoluteString;
    if (currentURL != nil && [currentURL containsString:@"Login.aspx"]) {

        [self loadWebViewWhenViewIsActive];
    }
}

#pragma mark - MainMenuControllerDelegate

- (void)didSelectApplicationFromMenu {
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.webView loadURL:[NSURL URLWithString:self.applicationURL] shouldSetLastURL:YES];
}

#pragma mark - WebActionResponderDelegate

- (void)performActionBasedOnJavascript:(NSString *)javascript {
    if ([NSString isStringEmpty:javascript]) {
        return;
    }
    [self.webView evaluateJavaScript:javascript completionHandler:nil];
}

- (void)performShowAppMenuAction {
    [(InactivityApplication *)[UIApplication sharedApplication] disableIdleTimer];

    // Open the main App menu view.
    ApplicationsController *controller = [ApplicationsController createMainMenuViewController];
    controller.delegate                = self;
    controller.modalPresentationStyle  = UIModalPresentationFullScreen;
    [self.navigationController presentViewController:controller animated:YES completion:nil];
}

#pragma mark - WebViewMainViewDelegate

- (void)displayWebSettingsErrorPage {
    UINavigationController *navigationController = (UINavigationController *)[WebServerSiteViewController createContainingNavigationController];
    WebServerSiteViewController *controller      = (WebServerSiteViewController *)[navigationController topViewController];
    controller.delegate                          = self;
    __weak typeof(self) weakSelf                 = self;
    navigationController.modalPresentationStyle  = UIModalPresentationFullScreen;
    // Dispatch since this can't be done from viewDidLoad
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [weakSelf presentViewController:navigationController animated:NO completion:nil];
    }];
}

- (void)updateUIForPage:(NSString *)page withURL:(NSString *)URL {
    if ([NSString isStringEmpty:page]) {
        return;
    }

    // Set the navigation bar elements with a default title, if title element is not found.
    [self.navigationBar parseItemsWithTitle:[MainViewUtils getPageNameFromURL:URL] fromHTML:page];

    // Set the dropDownMenu cell attributes
    [self.dropDownMenu parseItemsFromHTML:page];

    // Initialize and add bottom bar buttons. Do not display the scan button if it is a password page.
    [self.bottomBar parseItemsWithScan:![MainViewUtils isPasswordPage:URL] fromHTML:page];
}

/**
 * Convenience method where information comes from the web page
 */
- (void)presentAlertController:(UIAlertController *)controller withActionTitles:(NSArray *)actions andInfo:(NSDictionary *)info {
    if (controller == NULL) {
        return;
    }

    __weak MainViewController *weakSelf = self;

    // Ok button action.
    UIAlertAction *firstAction = [UIAlertAction
        actionWithTitle:actions[0]
                  style:UIAlertActionStyleCancel
                handler:^(UIAlertAction *_Nonnull action) {
                    if (![info objectForKey:kKey_Response_OK] || ![info objectForKey:kKey_Response_ServerError]) {
                        return;
                    }

                    NSString *response = [info objectForKey:kKey_Response_OK] != NULL ? [info objectForKey:kKey_Response_OK] : @"";
                    BOOL isError       = [info objectForKey:kKey_Response_ServerError] != NULL ? [[info objectForKey:kKey_Response_ServerError] boolValue] : NO;
                    [weakSelf alertActionResponse:response withServerError:isError];
                }];
    [controller addAction:firstAction];

    // Cancel Button Action
    if (actions.count >= 2) {
        UIAlertAction *secondAction = [UIAlertAction
            actionWithTitle:actions[1]
                      style:UIAlertActionStyleDefault
                    handler:^(UIAlertAction *_Nonnull action) {
                        if (![info objectForKey:kKey_Response_Cancel] || ![info objectForKey:kKey_Response_ServerError]) {
                            return;
                        }

                        NSString *response = [info objectForKey:kKey_Response_Cancel] != NULL ? [info objectForKey:kKey_Response_Cancel] : @"";
                        BOOL isError       = [info objectForKey:kKey_Response_ServerError] != NULL ? [[info objectForKey:kKey_Response_ServerError] boolValue] : NO;
                        [weakSelf alertActionResponse:response withServerError:isError];
                    }];
        [controller addAction:secondAction];
    }

    [self presentAlertController:controller];
}

/**
 * Generic method where the UIAlertController could be any controller type
 * to properly handle alert queueing
 */
- (void)presentAlertController:(UIAlertController *)controller {
    // If the scanner view is not yet dismissed, just queue the alert.
    // The alert will be presented in the completion block for dismissing the scanner view.
    if ([[UIViewController topmostViewController] conformsToProtocol:@protocol(CEAScannerViewController)]) {
        CernLogInfo(@"The scanner view has not yet dismissed to present the alert: %@", controller);
        [self.queuedAlerts addObject:controller];
        return;
    }

    [[UIViewController topmostViewController] presentViewController:controller animated:YES completion:nil];
}

#pragma mark - Alert Helpers

- (void)presentTopMostQueuedAlert {
    // Verify that the queue is not empty.
    if (self.queuedAlerts.count <= 0) {
        return;
    }
    [self presentQueuedAlertController:self.queuedAlerts.firstObject];
}

- (void)presentQueuedAlertController:(UIViewController *)controller {
    // If queued up controller is not a kind of alert, then return.
    if (controller == NULL || ![controller isKindOfClass:[UIAlertController class]]) {
        return;
    }

    // Keep presenting alerts till the queue is empty.
    __weak MainViewController *weakSelf = self;
    [[UIViewController topmostViewController] presentViewController:controller
                                                           animated:YES
                                                         completion:^{
                                                             [weakSelf.queuedAlerts removeObject:controller];
                                                             [weakSelf presentTopMostQueuedAlert];
                                                         }];
}

- (void)alertActionResponse:(NSString *)response withServerError:(BOOL)isError {
    // If it is a server error, display the server settings page and return.
    if (isError) {
        [self displayWebSettingsErrorPage];
        return;
    }

    // If response is empty, return.
    if ([NSString isStringEmpty:response]) {
        return;
    }

    // If response is a particular URL, go to that URL.
    if ([response rangeOfString:@"http"].location != NSNotFound) {
        [self.webView loadURL:[NSURL URLWithString:response] shouldSetLastURL:FALSE];
        return;
    }

    // If response is an action, perform the particular action.
    [self performActionBasedOnJavascript:response];
}

#pragma mark - Barcode Scanner Delegates
- (void)driver:(id<CEADeviceDriver>)driver connectFailedWithError:(NSError *)error {
    CernLogError(@"Unable to start barcode scanner: %@", error.userInfo[CEAErrorMessageKey]);
    CEADeviceDriverError errorCode = error.code;

    UIAlertController *controller;

    switch (errorCode) {
    case CEALicenseInvalid: {
        controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseInvalid];
        break;
    }
    case CEANetworkNotAvailable: {
        controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_NetworkUnavailable];
        break;
    }
    case CEALicenseServerNotAvailable: {
        controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseServerUnavailable];
        break;
    }
    case CEALicenseExpired: {
        controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_LicenseExpired];
        break;
    }
    // The next three fall under general error
    case CEALicenseMismatch:
    case CEALicenseNotFound:
    case CEALicenseCountExceeded: {
        controller = [AlertViewUtils alertForBarcodeScannerConnectionError:kScannerConnection_GeneralError];
        break;
    }
    }

    if (nil == controller) {
        CernLogError(@"Unhandled error when attempting to present scanner connection error");
        return;
    }

    NSString *dismissActionTitle = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.ACTION.SCANNER.DISMISS",
                                                                     kTable_Localization,
                                                                     [NSBundle mainBundle],
                                                                     @"Dismiss",
                                                                     @"Action title to dismiss the error");

    UIAlertAction *dismissAction = [UIAlertAction actionWithTitle:dismissActionTitle style:UIAlertActionStyleDefault handler:nil];

    [controller addAction:dismissAction];

    [self presentAlertController:controller];
}

- (void)driver:(id<CEADeviceDriver>)driver disconnectFailedWithError:(NSError *)error {
    CernLogInfo(@"%@ was unable to disconnect", [driver.class accessoryName]);
}

- (void)driverDidConnect:(id<CEADeviceDriver>)driver {
    CernLogInfo(@"%@ connected successfully", [self.barcodeScanner.class accessoryName]);
    [[CEAScannerFactory getSharedInstance] installScanner:self.barcodeScanner];
    self.barcodeScanner.barcodeScannerDelegate = self;
    self.barcodeScanner.scannerViewPresenter   = self;
}

- (void)driverDidDisconnect:(id<CEADeviceDriver>)driver {
    CernLogInfo(@"%@ disconnected successfully", [driver.class accessoryName]);
}

- (void)barcodeScanner:(id<CEABarcodeScanner>)scanner presentScannerView:(UIViewController<CEAScannerViewController> *)scannerViewController {
    [[UIViewController topmostViewController] presentViewController:scannerViewController animated:YES completion:nil];
}

- (void)barcodeScanner:(id<CEABarcodeScanner>)scanner dismissScannerView:(UIViewController<CEAScannerViewController> *)scannerViewController {
    __weak MainViewController *weakSelf = self;
    [scannerViewController dismissViewControllerAnimated:YES
                                              completion:^{
                                                  [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                                                      CernLogInfo(@"Presenting queued alerts : %@", weakSelf.queuedAlerts);
                                                      [weakSelf presentTopMostQueuedAlert];
                                                  }];
                                              }];
}

- (void)barcodeScanner:(id<CEABarcodeScanner>)scanner didScanBarcodes:(NSArray<CernBarcode *> *)barcodes {
    [self processBarcode:barcodes.firstObject];
}

@end
