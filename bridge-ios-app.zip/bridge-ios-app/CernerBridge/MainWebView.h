//
//  MainWebView.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <WebKit/WebKit.h>

@protocol WebViewNavigationBarDelegate;
@protocol WebViewMainViewDelegate;

@interface MainWebView : WKWebView

/**
 * The delegate associated with the WebView - NavigationBar protocol.
 **/
@property (nonatomic, weak) id<WebViewNavigationBarDelegate> webViewNavigationBarDelegate;
/**
 * The delegate associated with the WebView - MainView Contoller protocol.
 **/
@property (nonatomic, weak) id<WebViewMainViewDelegate> webViewMainViewDelegate;
/**
 * The application URL i.e URL of the selected application.
 * (Transfusion / Specimen/ milk-related applications / Baby Match).
 **/
@property (nonatomic, strong) NSString *applicationURL;

/**
 * Initializes the web view and corresponding delegates.
 **/
- (void)initialize;
/**
 * Unloads the web view and corresponding delegates.
 **/
- (void)unload;
/**
 * Verifies if the web server and web site settings have been set.
 *
 * @return BOOL YES if settings have been set, else NO.
 **/
- (BOOL)checkWebSettingsExist;
/**
 * Loads the given URL in the web view and saves it, if required.
 **/
- (void)loadURL:(NSURL *)URL shouldSetLastURL:(BOOL)shouldSet;

@end
