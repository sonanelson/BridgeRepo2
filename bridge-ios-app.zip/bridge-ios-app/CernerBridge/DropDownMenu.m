//
//  DropDownTableView.m
//  CernerBridge
//
//  Created by Gore,Divya on 10/11/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "DropDownMenu.h"
#import "BridgeCommonConstants.h"
#import "MainNavigationBar.h"

// Utils Headers
#import "HTMLElement+TypeHelper.h"
#import "HTMLParser+XPathHelper.h"
#import "NSString+Additions.h"
#import "UIColor+BridgeColors.h"
#import "UIFont+BridgeFonts.h"

@interface DropDownMenu () <UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate, NavigationBarDropDownMenuDelegate>

/**
 * Enum for defining all the dropdown menu row options.
 **/
typedef NS_ENUM(NSInteger, DropDownMenuRow) {
    kDropDownMenuRow_Help   = 0,
    kDropDownMenuRow_Logout = 1
};
/*
 * A boolean that indicates whether logout can happen from a given page.
 */
@property (nonatomic, assign) BOOL canLogout;
/**
* The ID of the help cell.
*/
@property (nonatomic, strong) NSString *helpID;
/**
 * The title of the help cell.
 */
@property (nonatomic, strong) NSString *helpTitle;
/**
 * The title of the logout cell.
 */
@property (nonatomic, strong) NSString *logoutTitle;
/**
* The ID of the logout cell.
*/
@property (nonatomic, strong) NSString *logoutID;
@end

@implementation DropDownMenu

#pragma mark LifeCycle Methods

- (void)awakeFromNib {
    [super awakeFromNib];

    // Delegate
    self.delegate   = self;
    self.dataSource = self;

    // Variables
    [self resetCellAttributesToDefaults];

    // Properties
    self.hidden          = true;
    self.backgroundColor = [UIColor colorWithWhite:0.0f alpha:0.5f];

    // Gesture Regonizer
    [self addTapGesture];
}

#pragma mark Getsure Recognizer Delegate and Methods

- (void)addTapGesture {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    tap.numberOfTapsRequired    = 1;
    tap.delegate                = self;
    [self addGestureRecognizer:tap];
}

- (void)handleTap:(UITapGestureRecognizer *)tap {
    BOOL isDropDownMenuHidden = self.hidden;
    if (isDropDownMenuHidden) {
        return;
    }

    CGPoint location  = [tap locationInView:self];
    NSIndexPath *path = [self indexPathForRowAtPoint:location];

    if (!path) {
        [self shouldHide:true andReload:false];
        return;
    }

    [self tableView:self didSelectRowAtIndexPath:path];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

#pragma mark General Methods

- (void)resetCellAttributesToDefaults {
    self.canLogout   = false;
    self.helpID      = @"";
    self.logoutID    = @"";
    self.helpTitle   = NSLocalizedStringWithDefaultValue(@"MENU.HELP",
                                                       kTable_Localization,
                                                       [NSBundle mainBundle],
                                                       @"Help",
                                                       @"Help menu option in the drop down menu list.");
    self.logoutTitle = NSLocalizedStringWithDefaultValue(@"MENU.LOGOUT",
                                                         kTable_Localization,
                                                         [NSBundle mainBundle],
                                                         @"Logout",
                                                         @"Logout menu option in the drop down menu list.");
}

- (void)setCellAttributesFromHTML:(HTMLElement *)element {
    if (element == NULL) {
        return;
    }

    if ([element isOfTypeLogout]) {
        self.canLogout   = true;
        self.logoutID    = element.elementID;
        self.logoutTitle = element.text;
        return;
    }

    self.helpID    = element.elementID;
    self.helpTitle = element.properties[@"text"];
}

- (void)parseItemsFromHTML:(NSString *)HTML {
    // Clean up cell attributes set on the page before.
    [self resetCellAttributesToDefaults];

    // Parse the drop down menu elements from the current page and
    // set the drop down menu cell attributes based on that.
    NSArray<HTMLElement *> *elements = [HTMLParser getDropDownMenuElementsFromHTML:HTML];
    for (HTMLElement *element in elements) {
        [self setCellAttributesFromHTML:element];
    }
}

- (void)shouldHide:(BOOL)hide andReload:(BOOL)reload {
    self.hidden = hide;

    if (reload) {
        [self reloadData];
    }
}

- (NSInteger)numberOfItemsInMenu {
    NSInteger numberOfItems = self.canLogout ? 1 : 0;
    numberOfItems           = self.helpID.length > 0 ? numberOfItems + 1 : numberOfItems;
    return numberOfItems;
}

#pragma mark NavigationBarDropDownMenuDelegate Methods

- (void)performActionBasedOnNavigationBarButtonClick:(NavigationBarButtonTag)tag {
    switch (tag) {
    case kNavBarButton_Menu: // App Menu
    case kNavBarButton_Left: // Left Bar Button Item
        // If the menu is still visible when you click the left nav bar, we  need to hide the menu.
        // If the menu is already hidden then you dont need to do anything.
        if (self.hidden) {
            return;
        }
        [self shouldHide:true andReload:false];
        break;

    case kNavBarButton_Right: // Right Bar Button Item
        // If there are no items in the menu, then return.
        if ([self numberOfItemsInMenu] == 0) {
            return;
        }

        // Hide or show menu depending upon previous state.
        [self shouldHide:!self.hidden andReload:(self.hidden ? true : false)];
        break;

    default:
        CernLogError(@"Invalid navigation bar button tag.");
        break;
    }
}

#pragma mark UITableView DataSource and Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self numberOfItemsInMenu];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"DropDownMenuViewCell";
    UITableViewCell *cell           = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    if (cell == NULL) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }

    cell.textLabel.font = [UIFont defaultTitleFont];
    [cell.textLabel setTextColor:[UIColor defaultTextColor]];

    switch (indexPath.row) {
    case kDropDownMenuRow_Help: // Help row
        cell.textLabel.text = self.helpTitle;
        break;
    case kDropDownMenuRow_Logout: // Logout row
        cell.textLabel.text = self.logoutTitle;
        break;
    default:
        CernLogError(@"Invalid row in dropdown menu.");
        break;
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *javascript = nil;
    switch (indexPath.row) {
    case kDropDownMenuRow_Help: // Help row
        self.hidden = true;
        javascript  = [NSString stringWithFormat:kHelpScript, self.helpID];
        break;

    case kDropDownMenuRow_Logout: // Logout row
        self.hidden = true;
        if (self.logoutID != nil && self.logoutID.length > 0) {
            javascript = [NSString stringWithFormat:kClickScript, self.logoutID];
        } else {
            // Old method, in case we want to bring back the double-dare.
            NSString *title = NSLocalizedStringWithDefaultValue(@"ALERT.LOGOUT.TITLE",
                                                                kTable_Localization,
                                                                [NSBundle mainBundle],
                                                                @"Logout",
                                                                @"Title for the logout alert.");

            NSString *message = NSLocalizedStringWithDefaultValue(@"ALERT.LOGOUT.MESSAGE",
                                                                  kTable_Localization,
                                                                  [NSBundle mainBundle],
                                                                  @"Are you sure you want to logout of your account?",
                                                                  @"Message for the logout alert.");

            javascript = [NSString stringWithFormat:@"confirm('%@<br><br>%@<br>%@');", self.applicationURL, title, message];
        }
        break;
    default:
        CernLogError(@"Invalid row selected in dropdown menu.");
        break;
    }
    [self.actionDelegate performActionBasedOnJavascript:javascript];
}

@end
