//
//  DropDownTableView.h
//  CernerBridge
//
//  Created by Gore,Divya on 10/11/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement.h"
#import <UIKit/UIKit.h>

// Delegates
#import "NavigationBarDropDownMenuDelegate.h"
#import "WebActionResponderDelegate.h"

/**
 * Table to display Menu with avilable options.
 */
@interface DropDownMenu : UITableView <NavigationBarDropDownMenuDelegate>

/**
 * The delegate associated with the web action responder prootcol.
 */
@property (nonatomic, weak) id<WebActionResponderDelegate> actionDelegate;

/**
 * The URL associated with the application.
 */
@property (nonatomic, strong) NSString *applicationURL;

/**
 * A method that decides if the menu should be hidden and reloaded and takes appropriate action.
 */
- (void)shouldHide:(BOOL)hide andReload:(BOOL)reload;

/**
* The number of items that are present in the menu.
*
* @return The number of items present in the menu tableview.
*/
- (NSInteger)numberOfItemsInMenu;

/**
 *  Parses all the required drop down menu elements from the current HTML.
 **/
- (void)parseItemsFromHTML:(NSString *)HTML;

@end
