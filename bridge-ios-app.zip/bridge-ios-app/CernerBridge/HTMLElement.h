//
//  HTMLElement.h
//  HTMLParserTester
//
//  Created by Shoemake,Andrew on 9/13/18.
//  Copyright © 2018 DWx CareAware Connect. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HTMLElement : NSObject

/**
 * The type of HTMLElement.
 */
@property (nonatomic, readonly) NSString *elementType;
/**
 * The properties of the HTMLElement.
 */
@property (nonatomic, readonly) NSDictionary<NSString *, NSString *> *properties;
/**
 * The text of the HTMLElement.
 */
@property (nonatomic, readonly) NSString *text;
/**
 * The ID of the HTMLElement.
 */
@property (nonatomic, readonly) NSString *elementID;

/**
 * Initialization method from the HTMLElement.
 *
 * @return HTMLElement An instance of the HTMLElement.
 */
- (instancetype)initWithElementType:(NSString *)elementType properties:(NSDictionary<NSString *, NSString *> *)properties text:(NSString *)text;

@end
