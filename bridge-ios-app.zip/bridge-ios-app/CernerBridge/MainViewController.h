//
//  MainViewController.h
//  TabView
//
//  Created by Bechtold,Brian on 10/15/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "ApplicationsController.h"
#import "MainNavigationViewController.h"
#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController
/**
 * Enum for all Supported Bridge Applications.
 */
typedef enum {
    TRANSFUSION = 0,
    SPECIMEN    = 1,
    MILK        = 2,
    BABYMATCH   = 3,
    DONORMILK   = 4,
    MEDADMIN    = 5
} Application;

/**
 * Creates the MainViewController and returns the Navigation Controller that contains it.
 *
 * @return The MainNavigationViewController that contains the MainViewController (it's topViewController)
 */
+ (MainNavigationViewController *)createContainingNavigationController;

/**
 * Creates the MainViewController and returns the same.
 *
 * @return The MainViewController.
 **/
+ (instancetype)createMainViewController;

/**
 * Logout automatically if application is inactive for a specified time.
 */
- (void)autoLogout;

/**
 * Reload the webview from the user defaults if the current url is pointing to the login page
 */
- (void)reloadURLFromDefaults;

@end
