//
//  WebServerSiteViewController.h
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 8/20/15.
//  Copyright (c) 2015 Bechtold,Brian. All rights reserved.
//

#import "WebServerSiteViewControllerDelegate.h"
#import <UIKit/UIKit.h>

@interface WebServerSiteViewController : UIViewController

/**
 * The delagate associated with the Website View Controller Delegate.
 */
@property (weak, nonatomic) id<WebServerSiteViewControllerDelegate> delegate;

/**
 * Creates the WebServerSiteViewController and returns the Navigation Controller that contains it.
 *
 * @return The Navigation Controller that contains the WebServerSiteViewController (it's topViewController)
 */
+ (UINavigationController *)createContainingNavigationController;

@end
