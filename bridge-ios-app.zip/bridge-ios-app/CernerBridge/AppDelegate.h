//
//  AppDelegate.h
//  TabView
//
//  Created by Bechtold,Brian on 10/15/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
/**
 * An instance of the main application window.
 */
@property (strong, nonatomic) UIWindow *window;
@end
