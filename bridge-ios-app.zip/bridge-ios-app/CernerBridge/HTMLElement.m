//
//  HTMLElement.m
//  HTMLParserTester
//
//  Created by Shoemake,Andrew on 9/13/18.
//  Copyright © 2018 DWx CareAware Connect. All rights reserved.
//

#import "HTMLElement.h"

@interface HTMLElement ()

@property (nonatomic, readwrite) NSString *text;

@end

@implementation HTMLElement

- (instancetype)initWithElementType:(NSString *)elementType properties:(NSDictionary *)properties text:(NSString *)text {
    if (self = [super init]) {
        _elementType = elementType;
        _properties  = properties;
        _text        = text;
    }
    return self;
}

- (NSString *)elementID {
    return self.properties[@"id"];
}

- (NSString *)text {
    if (_text != nil) {
        return _text;
    }
    // return the metadata of text or value if actual text is nil
    return _properties[@"text"] ?: _properties[@"value"];
}

- (NSString *)description {
    return [NSString stringWithFormat:@"ElementType: %@\nProperties: %@\nText: %@", self.elementType, [self proertiesDescription], self.text];
}

- (NSString *)proertiesDescription {
    NSMutableString *desc = [NSMutableString string];
    for (NSString *key in self.properties.allKeys) {
        [desc appendFormat:@"%@=%@ ", key, self.properties[key]];
    }
    return desc;
}

@end
