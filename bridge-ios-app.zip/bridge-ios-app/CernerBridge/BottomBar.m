//
//  BottomBar.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "BottomBar.h"
#import "BridgeCommonConstants.h"

// Utils Headers
#import "HTMLElement+TypeHelper.h"
#import "HTMLParser+XPathHelper.h"
#import "MainViewUtils.h"
#import "NSString+Additions.h"
#import "UIButton+AdditionalAttributes.h"
#import "UIColor+BridgeColors.h"
#import "UIFont+BridgeFonts.h"

#import <CernScanningLibrary/CEABarcodeScanner.h>
#import <CernScanningLibrary/CEAScannerFactory.h>

@interface BottomBar ()
// Enums
/**
 * Enum for defining Bottom Bar Items (Buttons).
 **/
typedef NS_ENUM(NSInteger, BottomBarItems) {
    kBottomBarItem_Left  = 0,
    kBottomBarItem_Scan  = 1,
    kBottomBarItem_Right = 2
};

// IBOutlets
/**
 * IBOutlet for the left (Patient/ Cancel/ Exit) button.
 */
@property (nonatomic, strong) IBOutlet UIButton *leftButton;
/**
 * IBOutlet for the right (Menu/ Continue/ Confirm) button.
 */
@property (nonatomic, strong) IBOutlet UIButton *scanButton;
/**
 * IBOutlet for the scan button.
 */
@property (nonatomic, strong) IBOutlet UIButton *rightButton;
/**
 * IBOutlet for the height constraint.
 */
@property (nonatomic, strong) IBOutlet NSLayoutConstraint *heightConstraint;

// Strings
/**
 * The ID for the left button.
 */
@property (nonatomic, strong) NSString *leftButtonID;
/**
 * The ID for the right button.
 */
@property (nonatomic, strong) NSString *rightButtonID;
/**
 * The text of the left button.
 */
@property (nonatomic, strong) NSString *leftButtonText;
/**
 * The text of the right button.
 */
@property (nonatomic, strong) NSString *rightButtonText;
/**
 * The text of the scan button.
 */
@property (nonatomic, strong) NSString *scanButtonText;

// BOOLs
/**
 * Bool that determines if scan button should be enabled, based on if the page is scannable.
 */
@property (nonatomic, assign) BOOL shouldEnableScanTab;
/**
 * Bool that specifies if the patient button should be active, enabled and displayed.
 */
@property (nonatomic, assign) BOOL showPatientsActive;
/**
 * Bool that specifies if the menu button should be active, enabled and displayed.
 */
@property (nonatomic, assign) BOOL showMenuActive;
/**
 * Bool that specifies if the continue button should be active, enabled and displayed.
 */
@property (nonatomic, assign) BOOL showContinue;
/**
 * Bool that specifies if the cancel button should be active, enabled and displayed.
 */
@property (nonatomic, assign) BOOL showCancel;

@end

// Defaults
static CGFloat kDefaultTopInset = 20.0f;

// Images
static NSString *const kImage_Confirm  = @"confirmIcon";
static NSString *const kImage_Scan     = @"scanIcon";
static NSString *const kImage_Patient  = @"patientIcon";
static NSString *const kImage_MenuList = @"menuListIcon";
static NSString *const kImage_Cancel   = @"cancelIcon";

@implementation BottomBar

- (void)awakeFromNib {
    [super awakeFromNib];

    self.backgroundColor = [UIColor bottomBarColor];
    self.tintColor       = [UIColor defaultTextColor];
    self.hidden          = true;

    [self adjustHeightForFullScreen];
    [self resetToDefaults];
}

- (void)adjustHeightForFullScreen {
    CGFloat topInset = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.top;
    // The top Inset is greater than 20  if the phone is full screen i.e. for screens like iPhoneX.
    if (topInset <= kDefaultTopInset) {
        return;
    }

    self.heightConstraint.constant += topInset - kDefaultTopInset;
}

- (void)resetToDefaults {
    self.leftButtonText  = NSLocalizedStringWithDefaultValue(@"BOTTOMBAR.DEFAULT.LEFT.TITLE",
                                                            kTable_Localization,
                                                            [NSBundle mainBundle],
                                                            @"Patient ID",
                                                            @"Default title for left button in bottom bar.");
    self.rightButtonText = NSLocalizedStringWithDefaultValue(@"BOTTOMBAR.DEFAULT.RIGHT.TITLE",
                                                             kTable_Localization,
                                                             [NSBundle mainBundle],
                                                             @"Menu",
                                                             @"Default title for right button in bottom bar.");
    self.scanButtonText  = NSLocalizedStringWithDefaultValue(@"BOTTOMBAR.DEFAULT.SCAN.TITLE",
                                                            kTable_Localization,
                                                            [NSBundle mainBundle],
                                                            @"Scan",
                                                            @"Default title for scan button in bottom bar.");

    self.showContinue        = false;
    self.showCancel          = false;
    self.showPatientsActive  = false;
    self.showMenuActive      = false;
    self.shouldEnableScanTab = false;
}

- (void)parseItemsWithScan:(BOOL)shouldScan fromHTML:(NSString *)HTML {
    // Clean up all the variables set on the earlier page.
    [self resetToDefaults];

    // Parse the bottom bar elements from the current page and
    // set the bottom bar button attributes based on that.
    NSArray<HTMLElement *> *elements = [HTMLParser getBottomBarElementsFromHTML:HTML];
    for (HTMLElement *element in elements) {
        [self setButtonAttributesFromHTML:element];
    }

    // Adjust UI of the bottom bar buttons based on the newly set button attributes.
    [self setUIAttributesForButtonsWithScan:shouldScan];
}

- (void)setButtonAttributesFromHTML:(HTMLElement *)element {
    // Should enable scan button
    if ([element isOfTypeScan]) {
        self.shouldEnableScanTab = true;
        // This indicates the client is connected to a valid Bridge server
        // we can now setup scanning
        [self.scannerInitializer setupScanning];
    }

    // Should show Patients button
    if ([element isOfTypePatient]) {
        self.showPatientsActive = true;
        self.leftButtonID       = element.elementID;
        self.leftButtonText     = element.text;
        return;
    }

    // Should show Menu button
    if ([element isOfTypeHome]) {
        self.showMenuActive  = true;
        self.rightButtonID   = element.elementID;
        self.rightButtonText = element.text;
        return;
    }

    // Should show cancel button
    if ([element isOfTypeCancel]) {
        self.leftButtonID   = element.elementID;
        self.leftButtonText = element.text;
        self.showCancel     = true;
        return;
    }

    // Should show continue button
    if ([element isOfTypeContinue]) {
        self.rightButtonID   = element.elementID;
        self.rightButtonText = element.text;
        self.showContinue    = true;
        return;
    }
}

- (BOOL)isMainBar {
    // The bottom bar with cancel / exit and continue is NOT the main bottom bar.
    return (!self.showCancel && !self.showContinue);
}

- (BOOL)shouldEnableLeftButton {
    // Buttons should always be enabled if it is not the main bottom bar.
    // If it is the main bottom bar, the left button should only be enabled if show Patients is active.
    return (![self isMainBar] || self.showPatientsActive);
}

- (BOOL)shouldEnableRightButton {
    // Buttons should always be enabled if it is not the main bottom bar.
    // If it is the main bottom bar, the right button should only be enabled if show Menu is active.
    return (![self isMainBar] || self.showMenuActive);
}

- (BOOL)shouldHideBottomBar {
    self.hidden = false;
    // If no tab is active, then we dont need to show the tabbar.
    if ((!self.showContinue && !self.showCancel && !self.showPatientsActive && !self.showMenuActive && ![self shouldEnableScanTab])) {
        self.hidden = true;
    }
    return self.hidden;
}

- (void)setButton:(UIButton *)button withImage:(NSString *)imageName title:(NSString *)title enabled:(BOOL)enabled tag:(BottomBarItems)tag {

    // Update button attributes
    UIImage *image = [UIImage imageNamed:imageName];
    [button setImage:image forState:UIControlStateNormal];
    [button setTitle:title forState:UIControlStateNormal];
    [button setEnabled:enabled];
    [button setTag:tag];
    [button.titleLabel setFont:[UIFont bottomBarFont]];
    UIColor *titleColor = [self isMainBar] ? [button titleColorForMainBottomBar] : [button titleColorForSecondaryBottomBar:(tag == kBottomBarItem_Left)];
    [button setTitleColor:titleColor forState:UIControlStateNormal];
    [button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateHighlighted];

    [button setTintColor:titleColor];
    button.adjustsImageWhenHighlighted = TRUE;

    // Add Insets
    [button centerContentWithImageOnTopOfSize:image.size title:title andFont:[UIFont bottomBarFont]];
}

- (void)setUIAttributesForButtonsWithScan:(BOOL)shouldScan {
    if ([self shouldHideBottomBar]) {
        return;
    }

    // Show/ Hide duplicate elements on the current page based on different IDs.
    [self makeVisibleInWebpage];
    [self shouldHideNonScanTabs:NO];

    // Left Button
    NSString *imageName = self.showCancel ? kImage_Cancel : kImage_Patient;
    [self setButton:self.leftButton withImage:imageName title:self.leftButtonText enabled:[self shouldEnableLeftButton] tag:kBottomBarItem_Left];

    // Right Button
    imageName = self.showContinue ? kImage_Confirm : kImage_MenuList;
    [self setButton:self.rightButton withImage:imageName title:self.rightButtonText enabled:[self shouldEnableRightButton] tag:kBottomBarItem_Right];

    // If only the Scan button is enabled, then hide the other 2 disabled buttons.
    [self shouldHideNonScanTabs:(([self shouldEnableScanTab] || shouldScan) ? ![self shouldEnableLeftButton] : NO)];

    // Scan Button
    if (!shouldScan) {
        [self.scanButton setHidden:YES];
        return;
    }
    [self.scanButton setHidden:NO];
    imageName = kImage_Scan;
    [self setButton:self.scanButton withImage:imageName title:self.scanButtonText enabled:[self shouldEnableScanTab] tag:kBottomBarItem_Scan];
}

- (void)shouldHideNonScanTabs:(BOOL)hide {
    // If only the scan button is enabled, just the scan button is visible.
    // If only one tab apart from the scan tab is visible, all tabs are shown with the disabled tabs grayed out.
    [self.leftButton setHidden:hide];
    [self.rightButton setHidden:hide];
}

- (void)adjustVisibilityOfLeftButton {
    // Show or hide the left button in the bottom bar based on the left button ID.
    if (self.leftButtonID.length <= 0) {
        return;
    }
    [self.actionDelegate performActionBasedOnJavascript:[NSString stringWithFormat:kVisibilityScript, self.leftButtonID]];
}

- (void)adjustVisibilityOfRightButton {
    // Show or hide the right button in the bottom bar based on the right button ID.
    if (self.rightButtonID.length <= 0) {
        return;
    }
    [self.actionDelegate performActionBasedOnJavascript:[NSString stringWithFormat:kVisibilityScript, self.rightButtonID]];
}

- (void)makeVisibleInWebpage {
    // When we show the buttons in the bottom bar, we need to hide the duplicate buttons visible on the webpage.
    [self adjustVisibilityOfLeftButton];
    [self adjustVisibilityOfRightButton];
}

- (IBAction)performActionBasedOnButtonClick:(UIButton *)sender {
    NSString *itemClicked = @"";
    switch (sender.tag) {
    case kBottomBarItem_Left: // Patient / Cancel or Exit
        itemClicked = self.leftButtonID;
        break;
    case kBottomBarItem_Scan: // Scan
    {
        id<CEABarcodeScanner> barcodeScanner = [[CEAScannerFactory getSharedInstance] getInstalledBarcodeScanner];
        if (nil != barcodeScanner) {
            [barcodeScanner presentView];
            return;
        }
        if (self.scannerInitializer == nil || ![self.scannerInitializer respondsToSelector:@selector(setupScanning)]) {
            CernLogError(@"Unable to initialize scanning!");
            return;
        }
        [self.scannerInitializer setupScanning];
        // Return instead of break so no JS script is run
        return;
    }
    case kBottomBarItem_Right: // Menu / Confirm or Continue
        itemClicked = self.rightButtonID;
        break;
    default:
        CernLogError(@"Invalid bottom bar button clicked.");
        break;
    }

    // Open the page corresponding to the tab click.
    NSString *javascript = [NSString stringWithFormat:kClickScript, itemClicked];
    [self.actionDelegate performActionBasedOnJavascript:javascript];
}

@end
