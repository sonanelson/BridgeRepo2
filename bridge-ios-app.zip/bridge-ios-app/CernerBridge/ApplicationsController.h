//
//  MainMenuController.h
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 10/26/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "MainMenuControllerDelegate.h"
#import <UIKit/UIKit.h>

@interface ApplicationsController : UITableViewController

/**
 * The delagate associated with the Main Menu Controller Delegate.
 */
@property (weak, nonatomic) id<MainMenuControllerDelegate> delegate;

/**
 * Creates the MainMenuController and returns the same.
 *
 * @return The MainMenuController.
 */
+ (instancetype)createMainMenuViewController;

@end
