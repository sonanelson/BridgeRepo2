//
//  WebViewNavigationBarDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Protocol for Navigation Bar actions corresponding to Webview taps, clicks and actions..
 */
@protocol WebViewNavigationBarDelegate <NSObject>

/**
 * Show or hide the visibility of the Menu Icon on the navigation bar.
 */
- (void)adjustVisibilityOfAppMenuIcon:(BOOL)shouldHide;

@end
