//
//  WebViewMainViewDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Protocol for Main View Controller actions corresponding to Webview taps, clicks and actions..
 */
@protocol WebViewMainViewDelegate <NSObject>

/**
 * Display the web server and web site settings page.
 */
- (void)displayWebSettingsErrorPage;

/**
 * Update the UI elements based on the given URL on the given page.
 */
- (void)updateUIForPage:(NSString *)page withURL:(NSString *)URL;

/**
 * Presents the given alert controller containing actions with the given titles and other information provided.
 * Other information includes responses for button clicks and kind of errors, if any.
 */
- (void)presentAlertController:(UIAlertController *)controller withActionTitles:(NSArray *)actions andInfo:(NSDictionary *)info;

@end
